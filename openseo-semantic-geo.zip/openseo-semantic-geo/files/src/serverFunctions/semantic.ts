import { createServerFn } from "@tanstack/react-start";
import { requireProjectContext } from "@/serverFunctions/middleware";
import {
  geoLlmSchema,
  geoProbeSchema,
  semanticAfterPublishSchema,
  semanticBriefSchema,
  semanticCannibalizationSchema,
  semanticFactCheckSchema,
  semanticGenerateSchema,
  semanticLinksSchema,
  semanticLoadPageSchema,
  semanticRephraseSchema,
} from "@/types/schemas/semantic";
import {
  geoSiteCheckSchema,
  saveGeoStateSchema,
  saveSemanticDocumentSchema,
  semanticDocumentRefSchema,
  semanticProjectSchema,
  semanticPublishSchema,
} from "@/types/schemas/semantic-documents";
import { SemanticDocumentService } from "@/server/features/semantic/services/SemanticDocumentService";
import { GeoService } from "@/server/features/semantic/services/GeoService";
import { SemanticAiService } from "@/server/features/semantic/services/SemanticAiService";
import { SemanticGscService } from "@/server/features/semantic/services/SemanticGscService";
import { SemanticGenerateService } from "@/server/features/semantic/services/SemanticGenerateService";
import { SemanticLinksService } from "@/server/features/semantic/services/SemanticLinksService";
import { SemanticService } from "@/server/features/semantic/services/SemanticService";
import { resolveMarket } from "@/shared/keyword-locations";

export const getSemanticBrief = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticBriefSchema)
  .handler(async ({ data, context }) =>
    SemanticService.getBrief(
      {
        projectId: context.projectId,
        keyword: data.keyword,
        ...resolveMarket(data, context.project),
      },
      context,
    ),
  );

export const loadSemanticPage = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticLoadPageSchema)
  .handler(async ({ data }) => SemanticService.loadPage(data.url));

export const listSemanticDocuments = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticProjectSchema)
  .handler(async ({ context }) =>
    SemanticDocumentService.list(context.projectId),
  );

export const getSemanticDocument = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticDocumentRefSchema)
  .handler(async ({ data, context }) =>
    SemanticDocumentService.get(context.projectId, data.id),
  );

export const saveSemanticDocument = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(saveSemanticDocumentSchema)
  .handler(async ({ data, context }) => {
    const { projectId: _projectId, id, ...fields } = data;
    return SemanticDocumentService.save({
      projectId: context.projectId,
      id,
      createdBy: context.userEmail,
      fields,
    });
  });

export const setSemanticDocumentPublished = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticPublishSchema)
  .handler(async ({ data, context }) =>
    SemanticDocumentService.setPublished({
      projectId: context.projectId,
      id: data.id,
      published: data.published,
    }),
  );

export const deleteSemanticDocument = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticDocumentRefSchema)
  .handler(async ({ data, context }) => {
    await SemanticDocumentService.remove(context.projectId, data.id);
    return { ok: true as const };
  });

export const rephraseSemanticPassage = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticRephraseSchema)
  .handler(async ({ data, context }) =>
    SemanticAiService.rephrase({
      projectId: context.projectId,
      text: data.text,
      context: data.context,
      keyword: data.keyword,
    }),
  );

export const factCheckSemanticDocument = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticFactCheckSchema)
  .handler(async ({ data, context }) =>
    SemanticAiService.factCheck({
      projectId: context.projectId,
      html: data.html,
      title: data.title,
      keyword: data.keyword,
    }),
  );

export const suggestSemanticOutgoingLinks = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticLinksSchema)
  .handler(async ({ data, context }) =>
    SemanticLinksService.outgoing({
      projectId: context.projectId,
      languageCode: context.project.languageCode,
      title: data.title,
      keyword: data.keyword,
      html: data.html,
      currentUrl: data.pageUrl,
    }),
  );

export const suggestSemanticIncomingLinks = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticLinksSchema)
  .handler(async ({ data, context }) =>
    SemanticLinksService.incoming({
      projectId: context.projectId,
      languageCode: context.project.languageCode,
      title: data.title,
      keyword: data.keyword,
      html: data.html,
      targetUrl: data.pageUrl,
    }),
  );

export const getSemanticCannibalization = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticCannibalizationSchema)
  .handler(async ({ data, context }) =>
    SemanticGscService.cannibalization({
      projectId: context.projectId,
      keyword: data.keyword,
    }),
  );

export const getSemanticAfterPublish = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticAfterPublishSchema)
  .handler(async ({ data, context }) =>
    SemanticGscService.afterPublish({
      projectId: context.projectId,
      pageUrl: data.pageUrl,
      publishedAt: data.publishedAt,
      keyword: data.keyword,
    }),
  );

export const saveGeoDocumentState = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(saveGeoStateSchema)
  .handler(async ({ data, context }) =>
    SemanticDocumentService.saveGeoState({
      projectId: context.projectId,
      id: data.id,
      checks: data.checks,
      live: data.live,
      llm: data.llm,
      score: data.score,
      llmScore: data.llmScore,
    }),
  );

export const probeGeoPage = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(geoProbeSchema)
  .handler(async ({ data }) => GeoService.probeLive(data.url));

export const analyzeGeoWithLlm = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(geoLlmSchema)
  .handler(async ({ data, context }) =>
    GeoService.analyzeLlm({
      html: data.html,
      title: data.title,
      keyword: data.keyword,
      ...resolveMarket(data, context.project),
    }),
  );

export const getGeoSiteState = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticProjectSchema)
  .handler(async ({ context }) => GeoService.siteState(context.projectId));

export const setGeoSiteCheck = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(geoSiteCheckSchema)
  .handler(async ({ data, context }) => {
    await GeoService.setSiteCheck({
      projectId: context.projectId,
      checkId: data.checkId,
      done: data.done,
    });
    return { ok: true as const };
  });

export const generateSemanticContent = createServerFn({ method: "POST" })
  .middleware(requireProjectContext)
  .validator(semanticGenerateSchema)
  .handler(async ({ data, context }) =>
    SemanticGenerateService.generate({
      projectId: context.projectId,
      kind: data.kind,
      html: data.html,
      title: data.title,
      keyword: data.keyword,
      terms: data.terms,
      headings: data.headings,
    }),
  );
