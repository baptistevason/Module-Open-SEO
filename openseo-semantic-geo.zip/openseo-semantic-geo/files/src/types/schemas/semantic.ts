import { z } from "zod";

export const semanticBriefSchema = z.object({
  projectId: z.string().min(1),
  keyword: z.string().trim().min(2).max(200),
  locationCode: z.number().int().positive().optional(),
  languageCode: z.string().min(2).max(8).optional(),
});

export const semanticLoadPageSchema = z.object({
  projectId: z.string().min(1),
  url: z.string().trim().min(4).max(2000),
});

export const semanticRephraseSchema = z.object({
  projectId: z.string().min(1),
  text: z.string().max(4_000),
  context: z.string().max(6_000),
  keyword: z.string().trim().max(200),
});

export const semanticFactCheckSchema = z.object({
  projectId: z.string().min(1),
  html: z.string().max(400_000),
  title: z.string().max(300),
  keyword: z.string().trim().max(200),
});

export const semanticLinksSchema = z.object({
  projectId: z.string().min(1),
  html: z.string().max(400_000),
  title: z.string().max(300),
  keyword: z.string().trim().max(200),
  // The draft's own URL, excluded from the candidates.
  pageUrl: z.string().trim().max(2000),
});

export const geoProbeSchema = z.object({
  projectId: z.string().min(1),
  url: z.string().trim().min(4).max(2000),
});

export const geoLlmSchema = z.object({
  projectId: z.string().min(1),
  html: z.string().max(400_000),
  title: z.string().max(300),
  keyword: z.string().trim().max(200),
  locationCode: z.number().int().positive().optional(),
  languageCode: z.string().min(2).max(8).optional(),
});

export const semanticCannibalizationSchema = z.object({
  projectId: z.string().min(1),
  keyword: z.string().trim().min(2).max(200),
});

export const semanticAfterPublishSchema = z.object({
  projectId: z.string().min(1),
  pageUrl: z.string().trim().max(2000),
  publishedAt: z.string().min(10).max(40),
  keyword: z.string().trim().max(200),
});

export const semanticGenerateSchema = z.object({
  projectId: z.string().min(1),
  kind: z.enum(["faq", "blurb", "meta", "outline"]),
  html: z.string().max(400_000),
  title: z.string().max(300),
  keyword: z.string().trim().max(200),
  terms: z.array(z.string().max(120)).max(40),
  headings: z.array(z.string().max(200)).max(40),
});
