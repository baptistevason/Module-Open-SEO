import { z } from "zod";

export const SEMANTIC_MAX_HTML_CHARS = 400_000;
export const SEMANTIC_MAX_DOCUMENTS_PER_PROJECT = 300;
export const SEMANTIC_MAX_BRIEF_CHARS = 200_000;

/** A library row: everything except the (large) body. */
export type SemanticDocumentSummary = {
  id: string;
  title: string;
  keyword: string;
  slug: string;
  pageUrl: string;
  /** Optimization score at the last save (0-100), null until scored. */
  score: number | null;
  /** When it was marked as pushed to production, null while a draft. */
  publishedAt: string | null;
  /** GEO score of the page (0-100) and LLM score (0-20) at the last GEO save. */
  geoScore: number | null;
  geoLlmScore: number | null;
  geoAnalyzedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type SemanticDocument = SemanticDocumentSummary & {
  projectId: string;
  titleTag: string;
  metaDescription: string;
  contentHtml: string;
  /** JSON of the last SERP analysis, null before the first one. */
  brief: string | null;
  /** Country and language targeted; null = the project's market. */
  locationCode: number | null;
  languageCode: string | null;
  /** GEO state, JSON text: hand ticks, published-page facts, LLM analysis. */
  geoChecks: string | null;
  geoLive: string | null;
  geoLlm: string | null;
};

export const semanticDocumentFieldsSchema = z.object({
  title: z.string().trim().max(300),
  keyword: z.string().trim().max(200),
  titleTag: z.string().max(300),
  metaDescription: z.string().max(600),
  slug: z.string().trim().max(200),
  pageUrl: z.string().trim().max(2000),
  contentHtml: z.string().max(SEMANTIC_MAX_HTML_CHARS),
  score: z.number().int().min(0).max(100).nullable(),
  brief: z.string().max(SEMANTIC_MAX_BRIEF_CHARS).nullable(),
  locationCode: z.number().int().positive().nullable().optional(),
  languageCode: z.string().min(2).max(8).nullable().optional(),
});

export const saveSemanticDocumentSchema = semanticDocumentFieldsSchema.extend({
  projectId: z.string().min(1),
  // Present to update a draft, absent to create one.
  id: z.string().min(1).optional(),
});

export const semanticDocumentRefSchema = z.object({
  projectId: z.string().min(1),
  id: z.string().min(1),
});

export const semanticPublishSchema = z.object({
  projectId: z.string().min(1),
  id: z.string().min(1),
  // false takes the content back out of production.
  published: z.boolean(),
});

export const saveGeoStateSchema = z.object({
  projectId: z.string().min(1),
  id: z.string().min(1),
  checks: z
    .record(z.string().max(60), z.boolean())
    .refine((value) => Object.keys(value).length <= 200),
  live: z.string().max(60_000).nullable(),
  llm: z.string().max(120_000).nullable(),
  score: z.number().int().min(0).max(100),
  llmScore: z.number().int().min(0).max(20).nullable(),
});

export const geoSiteCheckSchema = z.object({
  projectId: z.string().min(1),
  checkId: z.string().min(1).max(60),
  done: z.boolean(),
});

export const semanticProjectSchema = z.object({
  projectId: z.string().min(1),
});
