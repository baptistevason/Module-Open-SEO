import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  pgTable,
  text,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { projects } from "./app.schema";

// Timestamps are stored as *text* (same column shape as the SQLite schema); see
// the note in pg/app.schema.ts.
const isoNow = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;

// Postgres mirror of the semantic_documents table. Column notes: see
// ../semantic.schema.ts.
export const semanticDocuments = pgTable(
  "semantic_documents",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    keyword: text("keyword").notNull().default(""),
    titleTag: text("title_tag").notNull().default(""),
    metaDescription: text("meta_description").notNull().default(""),
    slug: text("slug").notNull().default(""),
    contentHtml: text("content_html").notNull().default(""),
    pageUrl: text("page_url").notNull().default(""),
    score: integer("score"),
    brief: text("brief"),
    locationCode: integer("location_code"),
    languageCode: text("language_code"),
    geoChecks: text("geo_checks"),
    geoLive: text("geo_live"),
    geoLlm: text("geo_llm"),
    geoScore: integer("geo_score"),
    geoLlmScore: integer("geo_llm_score"),
    geoAnalyzedAt: text("geo_analyzed_at"),
    publishedAt: text("published_at"),
    createdBy: text("created_by").notNull(),
    createdAt: text("created_at").notNull().default(isoNow),
    updatedAt: text("updated_at").notNull().default(isoNow),
  },
  (table) => [
    index("semantic_documents_project_updated_idx").on(
      table.projectId,
      table.updatedAt,
    ),
  ],
);

// Postgres mirror of geo_site_checks. Column notes: see ../semantic.schema.ts.
export const geoSiteChecks = pgTable(
  "geo_site_checks",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    checkId: text("check_id").notNull(),
    done: boolean("done").notNull().default(false),
    updatedAt: text("updated_at").notNull().default(isoNow),
  },
  (table) => [
    uniqueIndex("geo_site_checks_project_check_idx").on(
      table.projectId,
      table.checkId,
    ),
  ],
);
