import {
  index,
  integer,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
import { projects } from "./app.schema";

// ============================================================================
// Sémantique: drafts edited in the semantic optimization workspace. The body
// is sanitized HTML produced by the editor; the SEO fields are kept beside it
// so the keyword zones (title tag, meta, slug) can be analysed on reopening.
// ============================================================================

export const semanticDocuments = sqliteTable(
  "semantic_documents",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    // Working name shown in the library (usually the H1).
    title: text("title").notNull(),
    keyword: text("keyword").notNull().default(""),
    titleTag: text("title_tag").notNull().default(""),
    metaDescription: text("meta_description").notNull().default(""),
    slug: text("slug").notNull().default(""),
    contentHtml: text("content_html").notNull().default(""),
    // The published page this draft was loaded from or will replace, if any.
    pageUrl: text("page_url").notNull().default(""),
    // Optimization score (0-100) at the last save; null until first scored.
    score: integer("score"),
    // JSON of the last SERP analysis (lexical field), kept with the draft so
    // it is still there when the content is reopened; null before the first one.
    brief: text("brief"),
    // Country and language of the SERP this content targets; null = the project's.
    locationCode: integer("location_code"),
    languageCode: text("language_code"),
    // GEO module state of this content. All JSON text, null until used.
    // geo_checks: controls ticked by hand (id -> true). geo_live: facts read
    // from the published page. geo_llm: last LLM analysis.
    geoChecks: text("geo_checks"),
    geoLive: text("geo_live"),
    geoLlm: text("geo_llm"),
    // Page GEO score (0-100) and LLM score (0-20) at the last GEO save.
    geoScore: integer("geo_score"),
    geoLlmScore: integer("geo_llm_score"),
    geoAnalyzedAt: text("geo_analyzed_at"),
    // When the draft was marked as pushed to production; null while a draft.
    publishedAt: text("published_at"),
    createdBy: text("created_by").notNull(),
    createdAt: text("created_at")
      .notNull()
      .default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`),
    updatedAt: text("updated_at")
      .notNull()
      .default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`),
  },
  // The library lists a project's drafts, most recently edited first.
  (table) => [
    index("semantic_documents_project_updated_idx").on(
      table.projectId,
      table.updatedAt,
    ),
  ],
);

// Site-level GEO controls ticked by hand (external sources, measurement…).
export const geoSiteChecks = sqliteTable(
  "geo_site_checks",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    checkId: text("check_id").notNull(),
    done: integer("done", { mode: "boolean" }).notNull().default(false),
    updatedAt: text("updated_at")
      .notNull()
      .default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`),
  },
  (table) => [
    uniqueIndex("geo_site_checks_project_check_idx").on(
      table.projectId,
      table.checkId,
    ),
  ],
);
