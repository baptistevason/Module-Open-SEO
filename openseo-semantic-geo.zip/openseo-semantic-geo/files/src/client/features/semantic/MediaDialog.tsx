import { useState } from "react";
import { Button } from "@/client/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/client/components/ui/dialog";
import { Input } from "@/client/components/ui/input";

export type MediaKind = "image" | "video";

const COPY: Record<
  MediaKind,
  { title: string; description: string; urlLabel: string; placeholder: string }
> = {
  image: {
    title: "Insérer une image",
    description:
      "Indiquez l’adresse de l’image (déjà hébergée, par exemple dans la médiathèque de votre site) et décrivez-la : le texte alternatif sert au référencement, à l’accessibilité et aux moteurs génératifs.",
    urlLabel: "Adresse de l’image",
    placeholder: "https://exemple.fr/images/schema.webp",
  },
  video: {
    title: "Insérer une vidéo YouTube",
    description:
      "Collez l’adresse de la vidéo YouTube. Elle est intégrée avec le domaine sans cookies.",
    urlLabel: "Adresse de la vidéo",
    placeholder: "https://www.youtube.com/watch?v=…",
  },
};

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function isYoutubeUrl(value: string): boolean {
  if (!isHttpUrl(value)) return false;
  const host = new URL(value).hostname.replace(/^www\./, "");
  return (
    host === "youtu.be" ||
    host.endsWith("youtube.com") ||
    host.endsWith("youtube-nocookie.com")
  );
}

/** Asks for the address (and the alt text of an image) before inserting a media. */
export function MediaDialog({
  kind,
  onSubmit,
  onClose,
}: {
  kind: MediaKind;
  onSubmit: (value: { src: string; alt: string }) => void;
  onClose: () => void;
}) {
  const copy = COPY[kind];
  const [src, setSrc] = useState("");
  const [alt, setAlt] = useState("");
  const [error, setError] = useState<string | null>(null);

  const submit = () => {
    const url = src.trim();
    if (kind === "video" ? !isYoutubeUrl(url) : !isHttpUrl(url)) {
      setError(
        kind === "video"
          ? "Saisissez une adresse YouTube valide."
          : "Saisissez une adresse d’image valide (https://…).",
      );
      return;
    }
    if (kind === "image" && alt.trim().length < 3) {
      setError("Décrivez l’image : le texte alternatif est obligatoire.");
      return;
    }
    onSubmit({ src: url, alt: alt.trim() });
  };

  return (
    <Dialog open onOpenChange={(open) => (open ? undefined : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{copy.title}</DialogTitle>
          <DialogDescription>{copy.description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <label className="block space-y-1">
            <span className="text-xs font-medium">{copy.urlLabel}</span>
            <Input
              value={src}
              onChange={(event) => setSrc(event.target.value)}
              placeholder={copy.placeholder}
              autoFocus
            />
          </label>
          {kind === "image" ? (
            <label className="block space-y-1">
              <span className="text-xs font-medium">
                Texte alternatif (décrit ce que montre l’image)
              </span>
              <Input
                value={alt}
                onChange={(event) => setAlt(event.target.value)}
                placeholder="Schéma du collier de dressage monté sur un chien"
              />
            </label>
          ) : null}
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button type="button" onClick={submit}>
            Insérer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
