export function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString("fr-FR", {
    dateStyle: "long",
    timeStyle: "short",
  });
}

export function describeDates(
  updatedAt: string | null,
  publishedAt: string | null,
): string {
  if (!updatedAt) return "Nouveau contenu";
  const modified = `Modifié le ${formatDateTime(updatedAt)}`;
  return publishedAt
    ? `${modified} · en production depuis le ${formatDateTime(publishedAt)}`
    : modified;
}
