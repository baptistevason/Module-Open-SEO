import { useMemo } from "react";
import { CopyButton } from "@/client/components/CopyButton";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import {
  analyzeGeo,
  buildArticleSchema,
  buildFaqSchema,
  wrapJsonLd,
} from "@/shared/semantic/geo";

function SchemaBlock({
  title,
  hint,
  code,
  copyLabel,
}: {
  title: string;
  hint: string;
  code: string | null;
  copyLabel: string;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium">{title}</span>
        {code ? (
          <CopyButton
            value={wrapJsonLd(code)}
            successMessage={`${title} copié`}
            label={copyLabel}
          />
        ) : null}
      </div>
      {code ? (
        <details>
          <summary className="cursor-pointer text-xs text-muted-foreground">
            {hint}
          </summary>
          <pre className="mt-1.5 max-h-48 overflow-auto rounded-md bg-muted p-2 text-[11px] leading-snug">
            {code}
          </pre>
        </details>
      ) : (
        <p className="text-xs text-muted-foreground">{hint}</p>
      )}
    </div>
  );
}

/**
 * Ready-to-paste JSON-LD: FAQPage built from the question headings of the
 * content, and an Article block from the SEO fields.
 */
export function SchemaCard({
  html,
  title,
  description,
  pageUrl,
  publishedAt,
  updatedAt,
}: {
  html: string;
  title: string;
  description: string;
  pageUrl: string;
  publishedAt: string | null;
  updatedAt: string | null;
}) {
  const faqSchema = useMemo(() => {
    const { faq } = analyzeGeo(html);
    return faq.length > 0 ? buildFaqSchema(faq) : null;
  }, [html]);
  const articleSchema = useMemo(
    () =>
      title.trim()
        ? buildArticleSchema({
            headline: title.trim(),
            description: description.trim(),
            url: pageUrl.trim(),
            datePublished: publishedAt,
            dateModified: updatedAt,
          })
        : null,
    [title, description, pageUrl, publishedAt, updatedAt],
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Schema.org (JSON-LD)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <SchemaBlock
          title="FAQPage"
          hint={
            faqSchema
              ? "Voir le code"
              : "Aucune question détectée : formulez des sous-titres en question (se terminant par « ? ») suivis de leur réponse."
          }
          code={faqSchema}
          copyLabel="Copier le schema FAQPage"
        />
        <SchemaBlock
          title="Article"
          hint={
            articleSchema
              ? "Voir le code"
              : "Renseignez le titre pour générer le schema Article."
          }
          code={articleSchema}
          copyLabel="Copier le schema Article"
        />
        <p className="text-xs italic text-muted-foreground">
          À coller dans la page (balise script). L&apos;auteur n&apos;est pas
          inclus : ajoutez-le si vous avez une fiche auteur.
        </p>
      </CardContent>
    </Card>
  );
}
