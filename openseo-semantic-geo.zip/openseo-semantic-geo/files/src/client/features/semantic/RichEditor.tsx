import { useEffect, useState } from "react";
import { EditorContent, useEditor, type Editor } from "@tiptap/react";
import { Image } from "@tiptap/extension-image";
import { Youtube } from "@tiptap/extension-youtube";
import { StarterKit } from "@tiptap/starter-kit";
import {
  Bold,
  Check,
  Clapperboard,
  Copy,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Italic,
  Link2,
  Link2Off,
  List,
  ListOrdered,
  Pilcrow,
  Redo2,
  RemoveFormatting,
  Sparkles,
  Undo2,
} from "lucide-react";
import { Button } from "@/client/components/ui/button";
import { MediaDialog, type MediaKind } from "./MediaDialog";

type ToolbarProps = {
  editor: Editor;
  onMedia: (kind: MediaKind) => void;
  /** When absent, the Reformuler button is not shown. */
  onRephrase?: () => void;
  rephrasing?: boolean;
};

function ToolButton({
  label,
  active = false,
  onClick,
  children,
}: {
  label: string;
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <Button
      type="button"
      size="icon-sm"
      variant={active ? "secondary" : "ghost"}
      title={label}
      aria-label={label}
      aria-pressed={active}
      // Keep the editor selection alive while clicking a toolbar button.
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
    >
      {children}
    </Button>
  );
}

function setLink(editor: Editor) {
  const href: unknown = editor.getAttributes("link").href;
  const previous = typeof href === "string" ? href : "";
  const url = window.prompt("Adresse du lien (https://…)", previous);
  if (url === null) return;
  if (url.trim() === "") {
    editor.chain().focus().extendMarkRange("link").unsetLink().run();
    return;
  }
  editor
    .chain()
    .focus()
    .extendMarkRange("link")
    .setLink({ href: url.trim() })
    .run();
}

function Toolbar({ editor, onMedia, onRephrase, rephrasing }: ToolbarProps) {
  return (
    <div className="flex flex-wrap items-center gap-1 border-b bg-muted/40 p-1.5">
      <ToolButton
        label="Titre H1"
        active={editor.isActive("heading", { level: 1 })}
        onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
      >
        <Heading1 />
      </ToolButton>
      <ToolButton
        label="Titre H2"
        active={editor.isActive("heading", { level: 2 })}
        onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
      >
        <Heading2 />
      </ToolButton>
      <ToolButton
        label="Titre H3"
        active={editor.isActive("heading", { level: 3 })}
        onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
      >
        <Heading3 />
      </ToolButton>
      <ToolButton
        label="Paragraphe"
        active={editor.isActive("paragraph")}
        onClick={() => editor.chain().focus().setParagraph().run()}
      >
        <Pilcrow />
      </ToolButton>
      <span className="mx-1 h-5 w-px bg-border" />
      <ToolButton
        label="Gras"
        active={editor.isActive("bold")}
        onClick={() => editor.chain().focus().toggleBold().run()}
      >
        <Bold />
      </ToolButton>
      <ToolButton
        label="Italique"
        active={editor.isActive("italic")}
        onClick={() => editor.chain().focus().toggleItalic().run()}
      >
        <Italic />
      </ToolButton>
      <span className="mx-1 h-5 w-px bg-border" />
      <ToolButton
        label="Liste à puces"
        active={editor.isActive("bulletList")}
        onClick={() => editor.chain().focus().toggleBulletList().run()}
      >
        <List />
      </ToolButton>
      <ToolButton
        label="Liste numérotée"
        active={editor.isActive("orderedList")}
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
      >
        <ListOrdered />
      </ToolButton>
      <span className="mx-1 h-5 w-px bg-border" />
      <ToolButton
        label="Lien"
        active={editor.isActive("link")}
        onClick={() => setLink(editor)}
      >
        <Link2 />
      </ToolButton>
      <ToolButton
        label="Retirer le lien"
        onClick={() => editor.chain().focus().unsetLink().run()}
      >
        <Link2Off />
      </ToolButton>
      <span className="mx-1 h-5 w-px bg-border" />
      <ToolButton label="Insérer une image" onClick={() => onMedia("image")}>
        <ImagePlus />
      </ToolButton>
      <ToolButton
        label="Insérer une vidéo YouTube"
        onClick={() => onMedia("video")}
      >
        <Clapperboard />
      </ToolButton>
      <ToolButton
        label="Effacer la mise en forme"
        onClick={() =>
          editor.chain().focus().unsetAllMarks().clearNodes().run()
        }
      >
        <RemoveFormatting />
      </ToolButton>
      <span className="mx-1 h-5 w-px bg-border" />
      <ToolButton
        label="Annuler"
        onClick={() => editor.chain().focus().undo().run()}
      >
        <Undo2 />
      </ToolButton>
      <ToolButton
        label="Rétablir"
        onClick={() => editor.chain().focus().redo().run()}
      >
        <Redo2 />
      </ToolButton>
      {onRephrase ? (
        <>
          <span className="mx-1 h-5 w-px bg-border" />
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={rephrasing}
            onMouseDown={(event) => event.preventDefault()}
            onClick={onRephrase}
            title="Sélectionnez un passage, puis demandez 3 reformulations"
          >
            <Sparkles /> Reformuler
          </Button>
        </>
      ) : null}
      <CopyContentButton editor={editor} />
    </div>
  );
}

/** Copies the whole text as rich HTML (headings, lists, links) plus plain text. */
async function copyContent(editor: Editor): Promise<boolean> {
  const html = editor.getHTML();
  const text = editor.getText({ blockSeparator: "\n\n" });
  try {
    await navigator.clipboard.write([
      new ClipboardItem({
        "text/html": new Blob([html], { type: "text/html" }),
        "text/plain": new Blob([text], { type: "text/plain" }),
      }),
    ]);
    return true;
  } catch {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  }
}

function CopyContentButton({ editor }: { editor: Editor }) {
  const [state, setState] = useState<"idle" | "copied" | "failed">("idle");
  const handleClick = () => {
    void copyContent(editor).then((ok) => {
      setState(ok ? "copied" : "failed");
      window.setTimeout(() => setState("idle"), 2000);
    });
  };
  return (
    <Button
      type="button"
      size="sm"
      variant="outline"
      className="ml-auto"
      onMouseDown={(event) => event.preventDefault()}
      onClick={handleClick}
      title="Copie le texte avec sa mise en forme (titres, listes, liens)"
    >
      {state === "copied" ? <Check className="text-success" /> : <Copy />}
      {state === "copied"
        ? "Copié"
        : state === "failed"
          ? "Copie impossible"
          : "Copier le texte"}
    </Button>
  );
}

export type RichEditorProps = {
  /** Initial HTML; the editor is the source of truth afterwards. */
  initialHtml: string;
  onChange: (html: string) => void;
  onReady: (editor: Editor) => void;
  onRephrase?: () => void;
  rephrasing?: boolean;
};

export function RichEditor({
  initialHtml,
  onChange,
  onReady,
  onRephrase,
  rephrasing,
}: RichEditorProps) {
  const [media, setMedia] = useState<MediaKind | null>(null);
  const editor = useEditor({
    // The page is server-rendered: build the editor on the client only.
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
        link: { openOnClick: false, autolink: false },
        codeBlock: false,
        code: false,
        strike: false,
        horizontalRule: false,
      }),
      // Images by address; the alt text is asked for when inserting.
      Image.configure({ inline: false, allowBase64: false }),
      Youtube.configure({
        nocookie: true,
        controls: true,
        width: 640,
        height: 360,
      }),
    ],
    content: initialHtml,
    editorProps: {
      attributes: {
        class:
          "semantic-editor min-h-[28rem] max-w-none px-5 py-4 text-[15px] outline-none",
        spellcheck: "true",
      },
    },
    onUpdate: ({ editor: current }) => onChange(current.getHTML()),
  });

  useEffect(() => {
    if (editor) onReady(editor);
  }, [editor, onReady]);

  return (
    <div className="overflow-hidden rounded-lg border bg-background">
      {editor ? (
        <Toolbar
          editor={editor}
          onMedia={setMedia}
          onRephrase={onRephrase}
          rephrasing={rephrasing}
        />
      ) : null}
      <EditorContent editor={editor} />
      {media && editor ? (
        <MediaDialog
          kind={media}
          onClose={() => setMedia(null)}
          onSubmit={({ src, alt }) => {
            if (media === "image") {
              editor.chain().focus().setImage({ src, alt }).run();
            } else {
              editor.chain().focus().setYoutubeVideo({ src }).run();
            }
            setMedia(null);
          }}
        />
      ) : null}
    </div>
  );
}
