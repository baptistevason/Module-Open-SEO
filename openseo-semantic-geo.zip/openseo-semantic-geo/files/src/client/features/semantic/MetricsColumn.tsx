import type { Editor } from "@tiptap/react";
import type { BriefComparison, DraftAnalysis } from "@/shared/semantic/analyze";
import type { TargetRow } from "@/shared/semantic/targets";
import type { SemanticBrief } from "@/shared/semantic/types";
import { ReadabilityCard } from "./ReadabilityCard";
import { TargetsCard } from "./TargetsCard";
import { AiAssistantCard } from "./AiAssistantCard";
import { CannibalizationCard } from "./CannibalizationCard";
import { GeoCard } from "./GeoCard";
import { LexicalFieldCard } from "./LexicalFieldCard";
import { ResultsCard } from "./ResultsCard";
import { SchemaCard } from "./SchemaCard";
import { AiPanelsColumn } from "./AiPanelsColumn";
import type { DraftPayload } from "./AiPanels";
import {
  BenchmarkCard,
  CompetitorsCard,
  SubtopicsCard,
} from "./SemanticBriefPanels";
import { PhrasesCard, StructureCard, TopWordsCard } from "./SemanticPanels";

/** The right-hand column: targets and lexical field first, then metrics and AI tools. */
export function MetricsColumn({
  projectId,
  analysis,
  brief,
  comparison,
  targetView,
  languageCode,
  subtopics,
  keyword,
  editorRoot,
  deferredHtml,
  draft,
  meta,
  publishedAt,
  updatedAt,
  editor,
  onApplyTitle,
  onApplyMeta,
}: {
  projectId: string;
  analysis: DraftAnalysis;
  brief: SemanticBrief | null;
  comparison: BriefComparison | null;
  targetView: {
    rows: TargetRow[];
    sections: { heading: string; words: number }[];
    imagesMissingAlt: number;
  } | null;
  languageCode: string;
  subtopics: { heading: string; domain: string }[];
  keyword: string;
  editorRoot: HTMLElement | null;
  deferredHtml: string;
  draft: DraftPayload;
  meta: string;
  publishedAt: string | null;
  updatedAt: string | null;
  editor: Editor | null;
  onApplyTitle: (title: string) => void;
  onApplyMeta: (meta: string) => void;
}) {
  const missingTerms = comparison
    ? comparison.missingTerms.slice(0, 25).map((t) => t.term)
    : [];
  const competitorHeadings = brief
    ? [...new Set(brief.pages.flatMap((p) => p.h2))].slice(0, 25)
    : [];
  return (
    <div className="min-w-0 space-y-4">
      {brief && comparison ? (
        <>
          {targetView && brief.targets ? (
            <TargetsCard
              rows={targetView.rows}
              targets={brief.targets}
              pagesRead={brief.pagesRead}
              imagesMissingAlt={targetView.imagesMissingAlt}
              sections={targetView.sections}
            />
          ) : (
            <BenchmarkCard
              words={analysis.totalWords}
              h2={analysis.structure.h2}
              h3={analysis.structure.h3}
              images={analysis.structure.images}
              brief={brief}
            />
          )}
          <LexicalFieldCard
            comparison={comparison}
            pagesRead={brief.pagesRead}
          />
        </>
      ) : null}
      <CannibalizationCard
        projectId={projectId}
        keyword={keyword}
        pageUrl={draft.pageUrl}
      />
      {publishedAt ? (
        <ResultsCard
          projectId={projectId}
          pageUrl={draft.pageUrl}
          publishedAt={publishedAt}
          keyword={keyword}
        />
      ) : null}
      <AiAssistantCard
        projectId={projectId}
        html={draft.html}
        title={draft.title}
        keyword={keyword}
        terms={missingTerms}
        headings={competitorHeadings}
        editor={editor}
        onApplyTitle={onApplyTitle}
        onApplyMeta={onApplyMeta}
      />
      {brief ? (
        <>
          <SubtopicsCard subtopics={subtopics} />
          <CompetitorsCard brief={brief} />
        </>
      ) : null}
      <GeoCard html={deferredHtml} />
      <ReadabilityCard
        html={deferredHtml}
        languageCode={languageCode}
        top={brief?.readability}
      />
      <TopWordsCard analysis={analysis} />
      <PhrasesCard analysis={analysis} />
      <StructureCard analysis={analysis} />
      <AiPanelsColumn
        projectId={projectId}
        editorRoot={editorRoot}
        html={deferredHtml}
        analysis={analysis}
        draft={draft}
      />
      <SchemaCard
        html={deferredHtml}
        title={draft.title}
        description={meta}
        pageUrl={draft.pageUrl}
        publishedAt={publishedAt}
        updatedAt={updatedAt}
      />
    </div>
  );
}
