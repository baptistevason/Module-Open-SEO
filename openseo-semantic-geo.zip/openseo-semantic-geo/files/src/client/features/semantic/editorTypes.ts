import type { SeoFields } from "./SeoFieldsCard";

export type Fields = SeoFields;

export const EMPTY_FIELDS: Fields = {
  title: "",
  keyword: "",
  metaDescription: "",
  slug: "",
  pageUrl: "",
};

/** A rephrase request in progress: the selection it replaces and the options. */
export type Rephrase = {
  status: string;
  options: string[];
  from: number;
  to: number;
};
