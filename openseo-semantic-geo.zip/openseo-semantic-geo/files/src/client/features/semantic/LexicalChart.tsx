import { useMemo, useState } from "react";
import { Button } from "@/client/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { termBands, zoneFor, type Zone } from "@/shared/semantic/bands";
import type { BriefComparison } from "@/shared/semantic/analyze";
import type { SemanticTermKind } from "@/shared/semantic/types";
import { ZONE_FILL, ZONE_STROKE } from "./lexicalColors";
import { LexicalScorePanel } from "./LexicalScorePanel";

type Filter = "all" | SemanticTermKind;

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "Tous" },
  { key: "word", label: "1 mot" },
  { key: "bigram", label: "2 mots" },
  { key: "trigram", label: "3 mots" },
];
const LIMITS = [30, 50, 80];
const DEFAULT_LIMIT = 40;

const ZONES: { zone: Zone; label: string }[] = [
  { zone: "over", label: "Suroptimisation" },
  { zone: "strong", label: "Optimisation forte" },
  { zone: "normal", label: "Optimisation normale" },
  { zone: "under", label: "Sous-optimisation" },
];

// Geometry, in SVG pixels.
const COL_W = 30;
const LEFT = 58;
const RIGHT = 12;
const TOP = 12;
const PLOT_H = 220;
const ROW_H = 16;
const LABELS_H = 124;

type Column = {
  term: string;
  yours: number;
  from: number;
  to: number;
  strongTo: number;
  top: number;
  zone: Zone;
  max: number;
  median: number;
  pages: number;
};

/** A closed band between two boundaries (fractions of the scale), edge to edge. */
function pathFor(xs: number[], upper: number[], lower: number[]): string {
  const left = LEFT;
  const right = LEFT + xs.length * COL_W;
  const y = (fraction: number) => TOP + PLOT_H * (1 - fraction);
  const last = xs.length - 1;
  const forward = [
    `M ${left} ${y(upper[0])}`,
    ...xs.map((x, i) => `L ${x} ${y(upper[i])}`),
    `L ${right} ${y(upper[last])}`,
    `L ${right} ${y(lower[last])}`,
  ];
  const backward: string[] = [];
  for (let i = last; i >= 0; i--) backward.push(`L ${xs[i]} ${y(lower[i])}`);
  return [...forward, ...backward, `L ${left} ${y(lower[0])}`, "Z"].join(" ");
}

function rangeLabel(column: Column): string {
  return column.from === column.to
    ? String(column.from)
    : `${column.from}-${column.to}`;
}

/**
 * Where the content stands on each term of the lexical field, against the
 * pages that rank: the coloured zones come from how many times those pages use
 * the term, the black line is the content. Same idea as the SOSEO charts of
 * the semantic tools: stay in the green zone, avoid the red one.
 */
export function LexicalChart({ comparison }: { comparison: BriefComparison }) {
  const [filter, setFilter] = useState<Filter>("all");
  const [limit, setLimit] = useState(DEFAULT_LIMIT);
  const [hovered, setHovered] = useState<number | null>(null);

  const columns = useMemo<Column[]>(() => {
    const terms = comparison.terms.filter(
      (t) => filter === "all" || t.kind === filter,
    );
    terms.sort((a, b) => b.pages - a.pages || b.avgCount - a.avgCount);
    return terms.slice(0, limit).map((t) => {
      const bands = termBands(t);
      return {
        term: t.term,
        yours: t.yours,
        ...bands,
        zone: zoneFor(t.yours, bands),
        max: t.max,
        median: t.median,
        pages: t.pages,
      };
    });
  }, [comparison, filter, limit]);

  const counts = useMemo(() => {
    const tally: Record<Zone, number> = {
      under: 0,
      normal: 0,
      strong: 0,
      over: 0,
    };
    for (const column of columns) tally[column.zone]++;
    return tally;
  }, [columns]);

  if (columns.length === 0) {
    return null;
  }

  const xs = columns.map((_, i) => LEFT + COL_W * (i + 0.5));
  const width = LEFT + columns.length * COL_W + RIGHT;
  const rowsY = TOP + PLOT_H + 6;
  const height = rowsY + ROW_H * 2 + LABELS_H;
  const y = (fraction: number) => TOP + PLOT_H * (1 - fraction);
  const fractions = {
    from: columns.map((c) => c.from / c.top),
    to: columns.map((c) => c.to / c.top),
    strong: columns.map((c) => c.strongTo / c.top),
    zero: columns.map(() => 0),
    one: columns.map(() => 1),
  };
  const bandPaths: { zone: Zone; color: string; d: string }[] = [
    {
      zone: "under",
      color: ZONE_FILL.under,
      d: pathFor(xs, fractions.from, fractions.zero),
    },
    {
      zone: "normal",
      color: ZONE_FILL.normal,
      d: pathFor(xs, fractions.to, fractions.from),
    },
    {
      zone: "strong",
      color: ZONE_FILL.strong,
      d: pathFor(xs, fractions.strong, fractions.to),
    },
    {
      zone: "over",
      color: ZONE_FILL.over,
      d: pathFor(xs, fractions.one, fractions.strong),
    },
  ];
  const line = columns
    .map(
      (c, i) =>
        `${i === 0 ? "M" : "L"} ${xs[i]} ${y(Math.min(c.yours, c.top) / c.top)}`,
    )
    .join(" ");
  const active = hovered === null ? null : columns[hovered];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Champ lexical : fréquence recommandée</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <LexicalScorePanel lexical={comparison.lexical} />
        <div className="flex flex-wrap items-center gap-1.5">
          {FILTERS.map(({ key, label }) => (
            <Button
              key={key}
              type="button"
              size="xs"
              variant={filter === key ? "secondary" : "ghost"}
              onClick={() => setFilter(key)}
            >
              {label}
            </Button>
          ))}
          <span className="mx-1 h-4 w-px bg-border" />
          {LIMITS.map((value) => (
            <Button
              key={value}
              type="button"
              size="xs"
              variant={limit === value ? "secondary" : "ghost"}
              onClick={() => setLimit(value)}
            >
              Top {value}
            </Button>
          ))}
        </div>

        <p className="text-xs text-muted-foreground">
          {counts.under} en sous-optimisation · {counts.normal} dans la
          fourchette · {counts.strong} en optimisation forte · {counts.over} en
          suroptimisation
        </p>

        <div className="overflow-x-auto">
          <svg
            width={width}
            height={height}
            viewBox={`0 0 ${width} ${height}`}
            role="img"
            aria-label="Position du contenu sur chaque terme du champ lexical"
            className="text-foreground"
            onMouseLeave={() => setHovered(null)}
          >
            {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
              <g key={tick}>
                <line
                  x1={LEFT}
                  x2={width - RIGHT}
                  y1={y(tick)}
                  y2={y(tick)}
                  stroke="currentColor"
                  strokeOpacity={0.08}
                />
                <text
                  x={LEFT - 6}
                  y={y(tick) + 3}
                  textAnchor="end"
                  fontSize={10}
                  fill="currentColor"
                  opacity={0.55}
                >
                  {Math.round(tick * 100)}
                </text>
              </g>
            ))}
            <text
              transform={`translate(12 ${TOP + PLOT_H / 2}) rotate(-90)`}
              textAnchor="middle"
              fontSize={11}
              fill="currentColor"
              opacity={0.6}
            >
              Optimisation
            </text>

            {bandPaths.map((band) => (
              <path
                key={band.zone}
                d={band.d}
                fill={band.color}
                opacity={0.9}
              />
            ))}

            {active ? (
              <rect
                x={LEFT + COL_W * (hovered ?? 0)}
                y={TOP}
                width={COL_W}
                height={PLOT_H}
                fill="currentColor"
                opacity={0.08}
              />
            ) : null}

            <path
              d={line}
              fill="none"
              stroke="currentColor"
              strokeWidth={1.5}
            />
            {columns.map((c, i) => (
              <circle
                key={c.term}
                cx={xs[i]}
                cy={y(Math.min(c.yours, c.top) / c.top)}
                r={3.5}
                fill={ZONE_STROKE[c.zone]}
                stroke="currentColor"
                strokeWidth={1}
              />
            ))}

            <text
              x={LEFT - 6}
              y={rowsY + 11}
              textAnchor="end"
              fontSize={10}
              fill="currentColor"
              opacity={0.6}
            >
              Cible
            </text>
            <text
              x={LEFT - 6}
              y={rowsY + ROW_H + 11}
              textAnchor="end"
              fontSize={10}
              fill="currentColor"
              opacity={0.6}
            >
              Vous
            </text>
            {columns.map((c, i) => (
              <g key={`${c.term}-values`}>
                <text
                  x={xs[i]}
                  y={rowsY + 11}
                  textAnchor="middle"
                  fontSize={10}
                  fill="currentColor"
                  opacity={0.75}
                >
                  {rangeLabel(c)}
                </text>
                <text
                  x={xs[i]}
                  y={rowsY + ROW_H + 11}
                  textAnchor="middle"
                  fontSize={10}
                  fontWeight={600}
                  fill={ZONE_STROKE[c.zone]}
                >
                  {c.yours}
                </text>
                <text
                  transform={`translate(${xs[i] + 3} ${rowsY + ROW_H * 2 + 8}) rotate(-60)`}
                  textAnchor="end"
                  fontSize={11}
                  fill="currentColor"
                >
                  {c.term}
                </text>
              </g>
            ))}

            {columns.map((c, i) => (
              <rect
                key={`${c.term}-hit`}
                x={LEFT + COL_W * i}
                y={TOP}
                width={COL_W}
                height={height - TOP}
                fill="transparent"
                onMouseEnter={() => setHovered(i)}
              >
                <title>
                  {`${c.term} : ${c.yours}× dans votre contenu, cible ${rangeLabel(c)}×`}
                </title>
              </rect>
            ))}
          </svg>
        </div>

        <p className="min-h-5 text-sm">
          {active ? (
            <>
              <span className="font-medium">« {active.term} »</span> : votre
              contenu {active.yours}× · cible {rangeLabel(active)}× · médiane
              des concurrents {active.median}× · maximum {active.max}× (présent
              sur {active.pages} pages)
            </>
          ) : (
            <span className="text-muted-foreground">
              Survolez un mot pour voir le nombre de fois recommandé.
            </span>
          )}
        </p>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
          {ZONES.map(({ zone, label }) => (
            <span key={zone} className="inline-flex items-center gap-1.5">
              <span
                className="inline-block size-3 rounded-sm"
                style={{ backgroundColor: ZONE_FILL[zone] }}
              />
              {label}
            </span>
          ))}
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-0.5 w-4 bg-foreground" />
            Votre contenu
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
