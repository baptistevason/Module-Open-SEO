import { Check, Loader2, Search, X } from "lucide-react";
import { Badge } from "@/client/components/ui/badge";
import { Button } from "@/client/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { Input } from "@/client/components/ui/input";
import type {
  DraftAnalysis,
  ScorePart,
  ZonePresence,
} from "@/shared/semantic/analyze";
import { MarketPicker, type Market } from "./MarketPicker";
import type { BriefScoreTarget } from "@/shared/semantic/types";

const number = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });

function scoreTone(score: number) {
  if (score >= 80) return "text-success";
  if (score >= 55) return "text-amber-500";
  return "text-destructive";
}

export function ScoreCard({
  score,
  parts,
  hasBrief,
  target,
}: {
  score: number;
  parts: ScorePart[];
  hasBrief: boolean;
  /** Scores of the ranking pages, measured with the same method. */
  target?: BriefScoreTarget;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Score d&apos;optimisation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-end gap-2">
          <span className={`text-5xl font-semibold ${scoreTone(score)}`}>
            {score}
          </span>
          <span className="pb-1.5 text-sm text-muted-foreground">/ 100</span>
        </div>
        {target ? (
          <p className="text-xs text-muted-foreground">
            Les pages de la page 1 obtiennent entre{" "}
            <span className="font-semibold">{target.min}</span> et{" "}
            <span className="font-semibold">{target.max}</span> avec la même
            méthode (médiane{" "}
            <span className="font-semibold">{target.median}</span>).{" "}
            {score >= target.median
              ? "Vous êtes au niveau de la médiane ou au-dessus."
              : `Visez au moins ${target.median} pour rejoindre la médiane.`}
          </p>
        ) : null}
        {!hasBrief ? (
          <p className="text-xs text-muted-foreground">
            Score sur le texte seul. Lancez l&apos;analyse de la SERP pour le
            comparer aux pages qui se positionnent.
          </p>
        ) : null}
        <ul className="space-y-2.5">
          {parts.map((part) => (
            <li key={part.key} title={part.hint}>
              <div className="flex justify-between text-xs">
                <span>{part.label}</span>
                <span className="tabular-nums text-muted-foreground">
                  {part.points} / {part.max}
                </span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${(part.points / part.max) * 100}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

function ZoneBadge({ label, value }: { label: string; value: ZonePresence }) {
  if (value === 2) {
    return (
      <Badge variant="success">
        <Check /> {label}
      </Badge>
    );
  }
  if (value === 1) {
    return (
      <Badge variant="outline" title="Les mots sont là mais dispersés">
        ~ {label}
      </Badge>
    );
  }
  return (
    <Badge variant="destructive">
      <X /> {label}
    </Badge>
  );
}

export function KeywordCard({
  analysis,
  keyword,
  onKeywordChange,
  onAnalyzeSerp,
  serpPending,
  market,
  onMarketChange,
}: {
  analysis: DraftAnalysis;
  keyword: string;
  onKeywordChange: (value: string) => void;
  onAnalyzeSerp: () => void;
  serpPending: boolean;
  market: Market;
  onMarketChange: (market: Market) => void;
}) {
  const kw = analysis.keyword;
  const clamped = Math.min(kw.density, 4);
  const inRange = kw.density >= 0.5 && kw.density <= 2.5;
  const zones: [string, ZonePresence][] = [
    ["H1", kw.zones.h1],
    ["Balise title", kw.zones.titleTag],
    ["Méta description", kw.zones.meta],
    ["Slug", kw.zones.slug],
    ["1er paragraphe", kw.zones.firstParagraph],
    ["H2", kw.zones.h2],
    ["H3", kw.zones.h3],
  ];
  return (
    <Card>
      <CardHeader>
        <CardTitle>Mot-clé cible</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            value={keyword}
            onChange={(event) => onKeywordChange(event.target.value)}
            placeholder="Mot-clé à analyser"
            aria-label="Mot-clé à analyser"
          />
          <Button
            type="button"
            size="icon"
            variant="outline"
            title="Analyser la SERP (consomme des crédits, résultat gardé 12 h)"
            aria-label="Analyser la SERP"
            disabled={keyword.trim().length < 2 || serpPending}
            onClick={onAnalyzeSerp}
          >
            {serpPending ? <Loader2 className="animate-spin" /> : <Search />}
          </Button>
        </div>
        <MarketPicker market={market} onChange={onMarketChange} />
        {kw.value ? (
          <>
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-semibold tabular-nums">
                  {number.format(kw.density)} %
                </span>
                <span className="text-xs text-muted-foreground">
                  {kw.occurrences} occurrence{kw.occurrences > 1 ? "s" : ""}
                </span>
              </div>
              <div className="relative mt-2 h-2 rounded-full bg-muted">
                <div
                  className="absolute inset-y-0 rounded-full bg-success/25"
                  style={{ left: "12.5%", width: "50%" }}
                />
                <div
                  className={`absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-background ${
                    inRange ? "bg-success" : "bg-amber-500"
                  }`}
                  style={{ left: `${(clamped / 4) * 100}%` }}
                />
              </div>
              <p className="mt-1.5 text-xs text-muted-foreground">
                Zone idéale : 0,5 % à 2,5 %.
              </p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {zones.map(([label, value]) => (
                <ZoneBadge key={label} label={label} value={value} />
              ))}
            </div>
          </>
        ) : (
          <p className="text-xs italic text-muted-foreground">
            Saisissez un mot-clé pour lancer l&apos;analyse.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function Row({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "warn" | "good";
}) {
  const color =
    tone === "warn"
      ? "text-destructive"
      : tone === "good"
        ? "text-success"
        : "font-semibold";
  return (
    <div className="flex items-baseline justify-between gap-3 border-b py-1.5 text-sm last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className={`text-right tabular-nums ${color}`}>{value}</span>
    </div>
  );
}

export function StructureCard({ analysis }: { analysis: DraftAnalysis }) {
  const s = analysis.structure;
  return (
    <Card>
      <CardHeader>
        <CardTitle>Structure &amp; lisibilité</CardTitle>
      </CardHeader>
      <CardContent>
        <Row label="Mots" value={String(analysis.totalWords)} />
        <Row
          label="Temps de lecture"
          value={`~${analysis.readingMinutes} min`}
        />
        <Row
          label="Longueur moyenne des phrases"
          value={`${Math.round(analysis.avgSentence)} mots${
            analysis.avgSentence > 24 ? " (phrases longues)" : ""
          }`}
          tone={analysis.avgSentence > 24 ? "warn" : undefined}
        />
        <Row
          label="Phrases de plus de 30 mots"
          value={String(analysis.longSentences)}
          tone={analysis.longSentences > 0 ? "warn" : "good"}
        />
        <Row label="Balises H2 / H3" value={`${s.h2} / ${s.h3}`} />
        <Row label="Paragraphes" value={String(s.paragraphs)} />
        <Row
          label="Paragraphes trop longs (>100 mots)"
          value={String(s.longParagraphs)}
          tone={s.longParagraphs > 0 ? "warn" : "good"}
        />
        <Row label="Listes / tableaux" value={`${s.lists} / ${s.tables}`} />
        {s.h1 !== 1 ? (
          <p className="mt-2 text-xs text-amber-500">
            {s.h1 === 0 ? "Aucun H1" : `${s.h1} H1`} : visez un seul titre
            principal (H1).
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}

type Counted = { label: string; count: number; pct?: number };

function BarList({ rows }: { rows: Counted[] }) {
  const max = Math.max(1, ...rows.map((row) => row.count));
  return (
    <ul className="space-y-2">
      {rows.map((row) => (
        <li key={row.label}>
          <div className="flex justify-between gap-2 text-sm">
            <span className="truncate">{row.label}</span>
            <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
              {row.count} ×
              {row.pct !== undefined ? ` · ${number.format(row.pct)} %` : ""}
            </span>
          </div>
          <div className="mt-1 h-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary"
              style={{ width: `${(row.count / max) * 100}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export function TopWordsCard({ analysis }: { analysis: DraftAnalysis }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Mots les plus cités</CardTitle>
      </CardHeader>
      <CardContent>
        {analysis.topWords.length === 0 ? (
          <p className="text-xs text-muted-foreground">
            Pas encore assez de texte.
          </p>
        ) : (
          <BarList
            rows={analysis.topWords.map((w) => ({
              label: w.word,
              count: w.count,
              pct: w.pct,
            }))}
          />
        )}
      </CardContent>
    </Card>
  );
}

export function PhrasesCard({ analysis }: { analysis: DraftAnalysis }) {
  const groups: [string, Counted[]][] = [
    [
      "2 mots",
      analysis.topBigrams.map((b) => ({ label: b.phrase, count: b.count })),
    ],
    [
      "3 mots",
      analysis.topTrigrams.map((t) => ({ label: t.phrase, count: t.count })),
    ],
  ];
  return (
    <Card>
      <CardHeader>
        <CardTitle>Expressions fréquentes</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {groups.map(([title, rows]) => (
          <div key={title}>
            <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              {title}
            </div>
            {rows.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                Aucune expression répétée.
              </p>
            ) : (
              <BarList rows={rows} />
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
