import { CloudOff, Loader2, Rocket, Save } from "lucide-react";
import { Button } from "@/client/components/ui/button";

/** Save and "push to production" buttons of the editor header. */
export function EditorActions({
  saving,
  onSave,
  publishedAt,
  canPublish,
  publishing,
  onTogglePublished,
}: {
  saving: boolean;
  onSave: () => void;
  publishedAt: string | null;
  /** Only a saved draft can be marked as pushed to production. */
  canPublish: boolean;
  publishing: boolean;
  onTogglePublished: () => void;
}) {
  const live = publishedAt !== null;
  return (
    <>
      <Button
        type="button"
        variant="outline"
        disabled={!canPublish || publishing}
        onClick={onTogglePublished}
        title={
          canPublish
            ? "Garde la trace de la date de mise en production dans l’historique"
            : "Enregistrez d’abord le contenu"
        }
      >
        {publishing ? (
          <Loader2 className="animate-spin" />
        ) : live ? (
          <CloudOff />
        ) : (
          <Rocket />
        )}
        {live ? "Retirer de la prod" : "Marquer en prod"}
      </Button>
      <Button type="button" onClick={onSave} disabled={saving}>
        {saving ? <Loader2 className="animate-spin" /> : <Save />}
        Enregistrer
      </Button>
    </>
  );
}
