import { useMemo, useState } from "react";
import { Badge } from "@/client/components/ui/badge";
import { Button } from "@/client/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { CopyButton } from "@/client/components/CopyButton";
import type {
  BriefComparison,
  TermComparison,
} from "@/shared/semantic/analyze";
import type { SemanticTermKind } from "@/shared/semantic/types";

type Filter = "all" | SemanticTermKind;

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "Tous" },
  { key: "word", label: "1 mot" },
  { key: "bigram", label: "2 mots" },
  { key: "trigram", label: "3 mots" },
];

const number = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });

function matchesFilter(term: TermComparison, filter: Filter): boolean {
  return filter === "all" || term.kind === filter;
}

// Green background: the word is in the text. Red background: it is missing.
const COVERED_CLASS =
  "border-green-600/40 bg-green-500/25 text-green-800 dark:text-green-200";
const MISSING_CLASS =
  "border-red-600/40 bg-red-500/25 text-red-800 dark:text-red-200";

function TermChip({
  term,
  pagesRead,
  covered,
}: {
  term: TermComparison;
  pagesRead: number;
  covered: boolean;
}) {
  const detail = covered
    ? `Vous : ${term.yours}× · page 1 : ~${number.format(term.avgCount)}× sur ${term.pages}/${pagesRead} pages`
    : `Présent sur ${term.pages}/${pagesRead} pages, ~${number.format(term.avgCount)}× par page`;
  return (
    <Badge
      variant="outline"
      title={detail}
      className={`h-auto max-w-full gap-1 px-2 py-0.5 text-xs whitespace-normal ${
        covered ? COVERED_CLASS : MISSING_CLASS
      }`}
    >
      <span className="break-words">{term.term}</span>
      <span className="tabular-nums opacity-60">
        {covered ? `${term.yours}×` : `${term.pages}/${pagesRead}`}
      </span>
    </Badge>
  );
}

/**
 * The vocabulary shared by the pages that rank, compared with the draft.
 * Compact on purpose: terms are chips, filterable by number of words, and the
 * missing ones can be copied in one click.
 */
export function LexicalFieldCard({
  comparison,
  pagesRead,
}: {
  comparison: BriefComparison;
  pagesRead: number;
}) {
  const [filter, setFilter] = useState<Filter>("all");

  const { missing, covered } = useMemo(
    () => ({
      missing: comparison.missingTerms.filter((t) => matchesFilter(t, filter)),
      covered: comparison.terms.filter(
        (t) => t.covered && matchesFilter(t, filter),
      ),
    }),
    [comparison, filter],
  );
  const coveredTotal = comparison.terms.length - comparison.missingTerms.length;
  const countFor = (key: Filter) =>
    comparison.terms.filter((t) => matchesFilter(t, key)).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Champ lexical</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-muted-foreground">
          {coveredTotal} / {comparison.terms.length} termes couverts. Un terme
          est listé s&apos;il revient sur plusieurs des {pagesRead} pages lues.
        </p>
        <div className="flex flex-wrap gap-1">
          {FILTERS.map(({ key, label }) => (
            <Button
              key={key}
              type="button"
              size="xs"
              variant={filter === key ? "secondary" : "ghost"}
              onClick={() => setFilter(key)}
            >
              {label} ({countFor(key)})
            </Button>
          ))}
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium">
              À intégrer ({missing.length})
            </span>
            {missing.length > 0 ? (
              <CopyButton
                value={missing.map((t) => t.term).join(", ")}
                successMessage="Termes absents copiés"
                label="Copier les termes absents"
              />
            ) : null}
          </div>
          {missing.length === 0 ? (
            <p className="text-sm text-success">
              Rien d&apos;absent dans cette sélection.
            </p>
          ) : (
            <div className="flex max-h-56 flex-wrap gap-1 overflow-y-auto pr-1">
              {missing.map((term) => (
                <TermChip
                  key={term.term}
                  term={term}
                  pagesRead={pagesRead}
                  covered={false}
                />
              ))}
            </div>
          )}
        </div>

        {covered.length > 0 ? (
          <details open>
            <summary className="cursor-pointer text-xs font-medium">
              Déjà couverts ({covered.length})
            </summary>
            <div className="mt-1.5 flex max-h-40 flex-wrap gap-1 overflow-y-auto pr-1">
              {covered.map((term) => (
                <TermChip
                  key={term.term}
                  term={term}
                  pagesRead={pagesRead}
                  covered
                />
              ))}
            </div>
          </details>
        ) : null}
      </CardContent>
    </Card>
  );
}
