import {
  useCallback,
  useDeferredValue,
  useMemo,
  useRef,
  useState,
} from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import type { Editor } from "@tiptap/react";
import { Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { BackLink, PageHeader } from "@/client/components/PageHeader";
import { QueryError } from "@/client/components/QueryState";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import {
  getSemanticBrief,
  getSemanticDocument,
  loadSemanticPage,
  saveSemanticDocument,
  setSemanticDocumentPublished,
} from "@/serverFunctions/semantic";
import {
  analyzeDraft,
  compareWithBrief,
  scoreDraft,
  uncoveredSubtopics,
} from "@/shared/semantic/analyze";
import { parseStoredBrief } from "@/shared/semantic/brief-schema";
import type { SemanticBrief } from "@/shared/semantic/types";
import type { SemanticDocument } from "@/types/schemas/semantic-documents";
import { describeDates } from "./dates";
import { EditorActions } from "./EditorActions";
import { LexicalChart } from "./LexicalChart";
import { EditorTopPanel } from "./EditorTopPanel";
import { MetricsColumn } from "./MetricsColumn";
import { EMPTY_FIELDS, type Fields } from "./editorTypes";
import { SeoFieldsCard } from "./SeoFieldsCard";
import { RephrasePanel } from "./AiPanels";
import { RichEditor } from "./RichEditor";
import { useDocumentMarket } from "./useDocumentMarket";
import { useRephrase } from "./useRephrase";
import { useTargetView } from "./useTargetView";
import { WordCountBar } from "./WordCountBar";

export function SemanticEditorPage({
  projectId,
  documentId,
}: {
  projectId: string;
  documentId: string;
}) {
  // A content started from /new keeps the same workspace after its first save
  // (the URL then switches to the new id): recreating it would lose the
  // analysis and the editor state.
  const [startedAs] = useState(documentId);
  const startedNew = startedAs === "new";
  const isNew = startedNew || documentId === "new";
  const documentQuery = useQuery({
    queryKey: ["semantic-document", projectId, documentId],
    queryFn: () => getSemanticDocument({ data: { projectId, id: documentId } }),
    enabled: !isNew,
    // The editor owns the content after loading: never refetch under it.
    staleTime: Number.POSITIVE_INFINITY,
  });

  if (!isNew && documentQuery.isError) {
    return (
      <QueryError
        error={documentQuery.error}
        fallback="Impossible de charger ce contenu."
        onRetry={() => void documentQuery.refetch()}
      />
    );
  }
  if (!isNew && !documentQuery.data) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Chargement…
      </p>
    );
  }
  return (
    <EditorWorkspace
      key={startedNew ? "new" : documentId}
      projectId={projectId}
      document={startedNew ? null : (documentQuery.data ?? null)}
    />
  );
}

function EditorWorkspace({
  projectId,
  document,
}: {
  projectId: string;
  document: SemanticDocument | null;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [fields, setFields] = useState<Fields>(
    document
      ? {
          title: document.title,
          keyword: document.keyword,
          metaDescription: document.metaDescription,
          slug: document.slug,
          pageUrl: document.pageUrl,
        }
      : EMPTY_FIELDS,
  );
  const [html, setHtml] = useState(document?.contentHtml ?? "");
  const [savedId, setSavedId] = useState(document?.id ?? null);
  const [updatedAt, setUpdatedAt] = useState(document?.updatedAt ?? null);
  const [publishedAt, setPublishedAt] = useState(document?.publishedAt ?? null);
  const [importUrl, setImportUrl] = useState("");
  const [brief, setBrief] = useState<SemanticBrief | null>(() =>
    parseStoredBrief(document?.brief),
  );
  const [market, setMarket] = useDocumentMarket(projectId, document, brief);
  const languageCode = market.languageCode;
  const [editor, setEditor] = useState<Editor | null>(null);
  const rephraser = useRephrase(projectId, fields.keyword, editor);
  const initialHtml = useRef(document?.contentHtml ?? "");

  const update = (patch: Partial<Fields>) =>
    setFields((current) => ({ ...current, ...patch }));
  const handleReady = useCallback(
    (instance: Editor) => setEditor(instance),
    [],
  );
  const editorRoot = editor ? editor.view.dom : null;

  const deferredHtml = useDeferredValue(html);
  const deferredFields = useDeferredValue(fields);
  const analysis = useMemo(
    () =>
      analyzeDraft({
        title: deferredFields.title,
        meta: deferredFields.metaDescription,
        slug: deferredFields.slug,
        html: deferredHtml,
        keyword: deferredFields.keyword,
        languageCode,
      }),
    [deferredFields, deferredHtml, languageCode],
  );
  // The last SERP analysis stays on screen while the text or the keyword
  // changes; it is only replaced by a new analysis.
  const comparison = useMemo(
    () => (brief ? compareWithBrief(analysis, brief) : null),
    [analysis, brief],
  );
  const score = useMemo(
    () => scoreDraft(analysis, brief, comparison),
    [analysis, brief, comparison],
  );
  const subtopics = useMemo(
    () => (brief ? uncoveredSubtopics(analysis, brief) : []),
    [analysis, brief],
  );
  const targetView = useTargetView(
    brief,
    deferredHtml,
    deferredFields.pageUrl,
    analysis.totalWords,
  );
  const wordsRow = targetView?.rows.find((row) => row.key === "words");

  const saveMutation = useMutation({
    mutationFn: () =>
      saveSemanticDocument({
        data: {
          projectId,
          id: savedId ?? undefined,
          title: fields.title,
          keyword: fields.keyword,
          titleTag: fields.title,
          metaDescription: fields.metaDescription,
          slug: fields.slug,
          pageUrl: fields.pageUrl,
          contentHtml: html,
          score: score.score,
          brief: brief ? JSON.stringify(brief) : null,
          locationCode: market.locationCode,
          languageCode: market.languageCode,
        },
      }),
    onSuccess: (saved) => {
      setUpdatedAt(saved.updatedAt);
      void queryClient.invalidateQueries({
        queryKey: ["semantic-documents", projectId],
      });
      // Reopening the content must read what was just saved, not a cached copy.
      queryClient.removeQueries({
        queryKey: ["semantic-document", projectId],
      });
      if (!savedId) {
        setSavedId(saved.id);
        void navigate({
          to: "/p/$projectId/semantic/$documentId",
          params: { projectId, documentId: saved.id },
          replace: true,
        });
      }
    },
  });

  const publishMutation = useMutation({
    mutationFn: () =>
      setSemanticDocumentPublished({
        data: { projectId, id: savedId ?? "", published: publishedAt === null },
      }),
    onSuccess: (result) => {
      setPublishedAt(result.publishedAt);
      void queryClient.invalidateQueries({
        queryKey: ["semantic-documents", projectId],
      });
    },
  });

  const briefMutation = useMutation({
    mutationFn: () =>
      getSemanticBrief({
        data: {
          projectId,
          keyword: fields.keyword.trim(),
          locationCode: market.locationCode,
          languageCode: market.languageCode,
        },
      }),
    onSuccess: (result) => {
      if (result.ok) setBrief(result.brief);
    },
  });

  const importMutation = useMutation({
    mutationFn: () =>
      loadSemanticPage({ data: { projectId, url: importUrl.trim() } }),
    onSuccess: (page) => {
      if (!page.ok || !editor) return;
      editor.commands.setContent(page.html);
      setHtml(editor.getHTML());
      update({
        title: fields.title || page.title,
        pageUrl: fields.pageUrl || importUrl.trim(),
      });
    },
  });

  const staleBrief =
    brief !== null &&
    (brief.keyword !== deferredFields.keyword.trim().toLowerCase() ||
      brief.locationCode !== market.locationCode ||
      brief.languageCode !== market.languageCode);
  const briefFailure =
    briefMutation.data && !briefMutation.data.ok
      ? briefMutation.data.message
      : null;
  const importFailure =
    importMutation.data && !importMutation.data.ok
      ? importMutation.data.message
      : null;

  return (
    <div className="space-y-5">
      <PageHeader
        backLink={
          <BackLink to="/p/$projectId/semantic" params={{ projectId }}>
            Bibliothèque
          </BackLink>
        }
        title="Optimisation SEO"
        description={describeDates(updatedAt, publishedAt)}
        actions={
          <EditorActions
            saving={saveMutation.isPending}
            onSave={() => saveMutation.mutate()}
            publishedAt={publishedAt}
            canPublish={savedId !== null}
            publishing={publishMutation.isPending}
            onTogglePublished={() => publishMutation.mutate()}
          />
        }
      />
      {saveMutation.isError ? (
        <Alert variant="destructive">
          <AlertDescription>
            {getStandardErrorMessage(
              saveMutation.error,
              "L’enregistrement a échoué.",
            )}
          </AlertDescription>
        </Alert>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_26rem]">
        <div className="min-w-0 space-y-4">
          <EditorTopPanel
            analysis={analysis}
            score={score}
            brief={brief}
            keyword={fields.keyword}
            onKeywordChange={(keyword) => update({ keyword })}
            market={market}
            onMarketChange={setMarket}
            onAnalyzeSerp={() => briefMutation.mutate()}
            serpPending={briefMutation.isPending}
            serpError={
              briefFailure ??
              (briefMutation.isError
                ? getStandardErrorMessage(
                    briefMutation.error,
                    "L’analyse de la SERP a échoué.",
                  )
                : null)
            }
            stale={staleBrief}
          />
          <SeoFieldsCard
            fields={fields}
            onChange={update}
            importUrl={importUrl}
            onImportUrlChange={setImportUrl}
            onImport={() => importMutation.mutate()}
            importing={importMutation.isPending}
            canImport={editor !== null}
            importError={
              importFailure ??
              (importMutation.isError
                ? getStandardErrorMessage(
                    importMutation.error,
                    "Impossible de charger cette page.",
                  )
                : null)
            }
          />

          {rephraser.rephrase ? (
            <RephrasePanel
              status={rephraser.rephrase.status}
              options={rephraser.rephrase.options}
              onPick={rephraser.apply}
              onClose={rephraser.close}
            />
          ) : null}
          <RichEditor
            initialHtml={initialHtml.current}
            onChange={setHtml}
            onReady={handleReady}
            onRephrase={rephraser.request}
            rephrasing={rephraser.pending}
          />
          {wordsRow ? <WordCountBar row={wordsRow} /> : null}
          {comparison ? <LexicalChart comparison={comparison} /> : null}
        </div>

        <MetricsColumn
          projectId={projectId}
          analysis={analysis}
          brief={brief}
          comparison={comparison}
          targetView={targetView}
          languageCode={languageCode}
          subtopics={subtopics}
          keyword={fields.keyword}
          editorRoot={editorRoot}
          deferredHtml={deferredHtml}
          draft={{
            html,
            title: fields.title,
            keyword: fields.keyword,
            pageUrl: fields.pageUrl,
          }}
          meta={fields.metaDescription}
          editor={editor}
          onApplyTitle={(value) => update({ title: value })}
          onApplyMeta={(value) => update({ metaDescription: value })}
          publishedAt={publishedAt}
          updatedAt={updatedAt}
        />
      </div>
    </div>
  );
}
