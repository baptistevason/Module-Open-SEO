import type { TextMatch } from "@/shared/semantic/style-review";

// Maps the editor DOM to plain text (blocks separated by a newline) and back,
// so offsets found in the text can become highlight ranges. Highlights use the
// CSS Custom Highlight API: nothing is added to the editor DOM or saved HTML.

const BLOCK_SELECTOR =
  "p, li, h1, h2, h3, h4, h5, h6, td, th, blockquote, figcaption";

type Segment = { node: Text; start: number };

export type EditorTextMap = {
  text: string;
  segments: Segment[];
  /** Heading ranges, excluded from sentence-rhythm statistics. */
  skipRanges: TextMatch[];
};

export function buildTextMap(root: HTMLElement): EditorTextMap {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const segments: Segment[] = [];
  const skipRanges: TextMatch[] = [];
  let text = "";
  let lastBlock: Element | null = null;

  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (!(node instanceof Text)) continue;
    const block = node.parentElement?.closest(BLOCK_SELECTOR) ?? root;
    if (block !== lastBlock && text.length > 0) text += "\n";
    lastBlock = block;
    const start = text.length;
    segments.push({ node, start });
    text += node.data;
    if (/^H[1-6]$/.test(block.tagName)) {
      skipRanges.push({ start, end: text.length });
    }
  }
  return { text, segments, skipRanges };
}

function offsetToPoint(segments: Segment[], offset: number) {
  for (let i = segments.length - 1; i >= 0; i--) {
    const segment = segments[i];
    if (offset >= segment.start) {
      return {
        node: segment.node,
        offset: Math.min(offset - segment.start, segment.node.data.length),
      };
    }
  }
  return null;
}

export function matchesToRanges(
  segments: Segment[],
  matches: TextMatch[],
): Range[] {
  const ranges: Range[] = [];
  for (const match of matches) {
    const a = offsetToPoint(segments, match.start);
    const b = offsetToPoint(segments, match.end);
    if (!a || !b) continue;
    const range = document.createRange();
    range.setStart(a.node, a.offset);
    range.setEnd(b.node, b.offset);
    ranges.push(range);
  }
  return ranges;
}

function highlightsSupported(): boolean {
  return typeof CSS !== "undefined" && "highlights" in CSS;
}

export function setHighlight(name: string, ranges: Range[]): void {
  if (!highlightsSupported()) {
    // Older browsers: select the first occurrence instead.
    const selection = window.getSelection();
    if (ranges.length > 0 && selection) {
      selection.removeAllRanges();
      selection.addRange(ranges[0]);
    }
  } else {
    CSS.highlights.delete(name);
    if (ranges.length > 0) CSS.highlights.set(name, new Highlight(...ranges));
  }
  const element = ranges[0]?.startContainer.parentElement;
  element?.scrollIntoView({ block: "center", behavior: "smooth" });
}

export function clearHighlight(name: string): void {
  if (highlightsSupported()) CSS.highlights.delete(name);
}

/** Offsets of every occurrence of `quote` in the text (case-insensitive). */
export function findQuote(text: string, quote: string): TextMatch[] {
  const needle = quote.trim().toLowerCase();
  if (!needle) return [];
  const haystack = text.toLowerCase();
  const out: TextMatch[] = [];
  let from = haystack.indexOf(needle);
  while (from !== -1) {
    out.push({ start: from, end: from + needle.length });
    from = haystack.indexOf(needle, from + needle.length);
  }
  return out;
}
