import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import type { SemanticBrief } from "@/shared/semantic/types";

const number = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });

export function SubtopicsCard({
  subtopics,
}: {
  subtopics: { heading: string; domain: string }[];
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Sous-sujets absents de votre texte</CardTitle>
      </CardHeader>
      <CardContent>
        {subtopics.length === 0 ? (
          <p className="text-sm text-success">
            Les sous-titres des concurrents sont couverts.
          </p>
        ) : (
          <>
            <p className="mb-2 text-xs text-muted-foreground">
              Titres H2 des pages du top dont vos mots ne couvrent pas le sujet.
              Reformulez-les à votre manière, sans les recopier.
            </p>
            <ul className="space-y-1.5 text-sm">
              {subtopics.map((s) => (
                <li key={s.heading}>
                  {s.heading}{" "}
                  <span className="text-xs text-muted-foreground">
                    ({s.domain})
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export function CompetitorsCard({ brief }: { brief: SemanticBrief }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Pages lues</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-1.5 text-sm">
          {brief.pages.map((page) => (
            <li key={page.url} className="flex justify-between gap-2">
              <a
                href={page.url}
                target="_blank"
                rel="noreferrer noopener"
                className="truncate hover:underline"
                title={page.title}
              >
                {page.rank}. {page.domain}
              </a>
              <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                {page.words} mots · {page.h2Count} H2
              </span>
            </li>
          ))}
        </ul>
        {brief.pagesRead < brief.pagesRequested ? (
          <p className="mt-2 text-xs text-muted-foreground">
            {brief.pagesRequested - brief.pagesRead} page(s) illisible(s)
            (blocage robots ou contenu en JavaScript), ignorée(s).
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}

function Tile({
  label,
  yours,
  target,
}: {
  label: string;
  yours: number;
  target: number | null;
}) {
  return (
    <div className="rounded-lg border p-2.5">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-lg font-semibold tabular-nums">
        {number.format(yours)}
      </div>
      {target !== null ? (
        <div className="text-xs text-muted-foreground">
          page 1 : {number.format(target)}
        </div>
      ) : null}
    </div>
  );
}

export function BenchmarkCard({
  words,
  h2,
  h3,
  images,
  brief,
}: {
  words: number;
  h2: number;
  h3: number;
  images: number;
  brief: SemanticBrief;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Face à la page 1</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          <Tile label="Mots" yours={words} target={brief.medianWords} />
          <Tile label="H2" yours={h2} target={brief.avgH2} />
          <Tile label="H3" yours={h3} target={brief.avgH3} />
          <Tile label="Images" yours={images} target={brief.avgImages} />
        </div>
      </CardContent>
    </Card>
  );
}
