import { useEffect, useMemo, useState } from "react";
import { Eye } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import type { DraftAnalysis } from "@/shared/semantic/analyze";
import { reviewStyle, type TextMatch } from "@/shared/semantic/style-review";
import {
  buildTextMap,
  clearHighlight,
  matchesToRanges,
  setHighlight,
} from "./editorText";

const HIGHLIGHT = "style-review";

type RowProps = {
  id: string;
  label: string;
  value: string;
  tone?: "warn" | "good";
  hint?: string;
  matches?: TextMatch[];
  active: boolean;
  onToggle: (id: string, matches: TextMatch[]) => void;
};

function StyleRow({
  id,
  label,
  value,
  tone,
  hint,
  matches,
  active,
  onToggle,
}: RowProps) {
  const clickable = Boolean(matches && matches.length > 0);
  const color =
    tone === "warn"
      ? "text-destructive"
      : tone === "good"
        ? "text-success"
        : "";
  const content = (
    <>
      <span className="text-left">{label}</span>
      <span
        className={`flex shrink-0 items-center gap-1 font-semibold tabular-nums ${color}`}
      >
        {value}
        {clickable ? <Eye className="size-3.5" /> : null}
      </span>
    </>
  );
  const className = `flex w-full items-baseline justify-between gap-3 border-b py-1.5 text-sm last:border-0 ${
    active ? "bg-amber-500/10" : ""
  }`;
  if (!clickable) {
    return (
      <div className={className} title={hint}>
        {content}
      </div>
    );
  }
  return (
    <button
      type="button"
      className={`${className} cursor-pointer hover:bg-muted/50`}
      title={hint}
      onClick={() => onToggle(id, matches ?? [])}
    >
      {content}
    </button>
  );
}

/**
 * Writing-tic, connector and rhythm review of the editor text. Clicking a row
 * highlights its passages in the editor (CSS Custom Highlight API).
 */
export function StyleReviewCard({
  editorRoot,
  html,
  analysis,
}: {
  editorRoot: HTMLElement | null;
  /** Re-runs the review whenever the content changes. */
  html: string;
  analysis: DraftAnalysis;
}) {
  const [activeKey, setActiveKey] = useState<string | null>(null);

  // Offsets go stale as soon as the text changes.
  useEffect(() => {
    setActiveKey(null);
    clearHighlight(HIGHLIGHT);
  }, [html]);
  useEffect(() => () => clearHighlight(HIGHLIGHT), []);

  const review = useMemo(() => {
    if (!editorRoot) return null;
    const map = buildTextMap(editorRoot);
    return { review: reviewStyle(map.text, { skipRanges: map.skipRanges }) };
    // `html` is the change signal: the DOM is read, not the string.
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, [editorRoot, html]);

  if (!review || !editorRoot) return null;
  const { rhythm, tics, connectors, connectorLimit } = review.review;

  const toggle = (id: string, matches: TextMatch[]) => {
    if (activeKey === id) {
      setActiveKey(null);
      clearHighlight(HIGHLIGHT);
      return;
    }
    setActiveKey(id);
    const map = buildTextMap(editorRoot);
    setHighlight(HIGHLIGHT, matchesToRanges(map.segments, matches));
  };
  const common = { active: false, onToggle: toggle };
  const row = (props: Omit<RowProps, "active" | "onToggle">) => (
    <StyleRow
      key={props.id}
      {...props}
      active={activeKey === props.id}
      onToggle={common.onToggle}
    />
  );

  const rows: React.ReactNode[] = [];
  if (rhythm.sentences < 5) {
    rows.push(
      row({
        id: "none",
        label: "Rythme des phrases",
        value: "texte trop court",
      }),
    );
  } else {
    const variety =
      rhythm.cv >= 0.5
        ? { text: "varié", tone: "good" as const }
        : rhythm.cv >= 0.35
          ? { text: "correct", tone: undefined }
          : { text: "monotone", tone: "warn" as const };
    rows.push(
      row({
        id: "cv",
        label: "Rythme des phrases",
        value: variety.text,
        tone: variety.tone,
        hint: `Variation de longueur : ${Math.round(rhythm.cv * 100)} % (au-dessus de 50 %, le rythme est vivant)`,
      }),
      row({
        id: "runs",
        label: "Séries de phrases de même longueur",
        value: String(rhythm.flatRuns.length),
        tone: rhythm.flatRuns.length > 0 ? "warn" : "good",
        matches: rhythm.flatRuns,
        hint: "4 phrases ou plus d’affilée à ±3 mots près",
      }),
      row({
        id: "short",
        label: "Phrases courtes (≤ 8 mots)",
        value: `${Math.round(rhythm.shortShare * 100)} %`,
        tone: rhythm.shortShare < 0.1 ? "warn" : undefined,
        hint: "Quelques phrases très courtes donnent du relief",
      }),
    );
  }

  if (tics.length === 0) {
    rows.push(
      row({
        id: "tics",
        label: "Tics d’écriture",
        value: "aucun",
        tone: "good",
      }),
    );
  } else {
    for (const tic of tics) {
      rows.push(
        row({
          id: `tic-${tic.id}`,
          label: tic.label,
          value: String(tic.count),
          tone: "warn",
          matches: tic.matches,
          hint: tic.hint,
        }),
      );
    }
  }

  const overused = connectors.filter((c) => c.overused);
  if (overused.length === 0) {
    rows.push(
      row({
        id: "connectors",
        label: "Connecteurs répétés",
        value: "aucun",
        tone: "good",
      }),
    );
  } else {
    for (const c of overused) {
      rows.push(
        row({
          id: `conn-${c.word}`,
          label: `« ${c.word} » répété`,
          value: String(c.count),
          tone: "warn",
          matches: c.matches,
          hint: `Plus de ${connectorLimit - 1} fois : enchaîner par le sens plutôt que par un mot de liaison`,
        }),
      );
    }
  }

  const { lists, threeItemLists } = analysis.structure;
  if (lists >= 3) {
    rows.push(
      row({
        id: "triads",
        label: "Listes à 3 points",
        value: `${threeItemLists} / ${lists}`,
        tone: threeItemLists / lists >= 0.6 ? "warn" : undefined,
        hint: "Varier le nombre d’éléments selon le contenu réel",
      }),
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Relecture de style</CardTitle>
      </CardHeader>
      <CardContent>
        {rows}
        <p className="mt-3 text-xs italic text-muted-foreground">
          Cliquez une ligne pour surligner les passages dans l&apos;éditeur.
          Sélectionnez un passage puis « Reformuler » pour obtenir 3
          propositions.
        </p>
      </CardContent>
    </Card>
  );
}
