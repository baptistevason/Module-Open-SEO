import { useState } from "react";
import { useProjectMarket } from "@/client/features/projects/useProjectMarket";
import type { SemanticBrief } from "@/shared/semantic/types";
import type { Market } from "./MarketPicker";

/**
 * Country and language targeted by a content: the one picked, else the one
 * saved with the content, else the one of its last SERP analysis, else the
 * project's.
 */
export function useDocumentMarket(
  projectId: string,
  saved: { locationCode: number | null; languageCode: string | null } | null,
  brief: SemanticBrief | null,
): [Market, (market: Market) => void] {
  const projectMarket = useProjectMarket(projectId);
  const [picked, setPicked] = useState<Market | null>(null);
  const fromDocument =
    saved?.locationCode != null && saved.languageCode
      ? { locationCode: saved.locationCode, languageCode: saved.languageCode }
      : null;
  const fromBrief = brief
    ? { locationCode: brief.locationCode, languageCode: brief.languageCode }
    : null;
  const market: Market = picked ??
    fromDocument ??
    fromBrief ??
    projectMarket ?? { locationCode: 2250, languageCode: "fr" };
  return [market, setPicked];
}
