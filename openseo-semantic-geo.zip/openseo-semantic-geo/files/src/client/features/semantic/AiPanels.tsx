import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { ExternalLink, Loader2, X } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { Badge } from "@/client/components/ui/badge";
import { Button } from "@/client/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import {
  factCheckSemanticDocument,
  suggestSemanticIncomingLinks,
  suggestSemanticOutgoingLinks,
} from "@/serverFunctions/semantic";
import type {
  FactCheckClaim,
  FactStatus,
  IncomingLinkSuggestion,
  OutgoingLink,
} from "@/shared/semantic/types";

export type DraftPayload = {
  html: string;
  title: string;
  keyword: string;
  pageUrl: string;
};

function Failure({ message }: { message: string }) {
  return (
    <Alert variant="destructive">
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  );
}

const STATUS_LABEL: Record<
  FactStatus,
  {
    label: string;
    variant: "success" | "destructive" | "outline" | "secondary";
  }
> = {
  confirme: { label: "Confirmé", variant: "success" },
  a_sourcer: { label: "À sourcer", variant: "outline" },
  incorrect: { label: "Incorrect", variant: "destructive" },
  obsolete: { label: "Obsolète", variant: "destructive" },
  non_verifiable: { label: "Non vérifiable", variant: "secondary" },
};

function ClaimRow({
  claim,
  onLocate,
}: {
  claim: FactCheckClaim;
  onLocate: (quote: string) => void;
}) {
  const status = STATUS_LABEL[claim.status];
  return (
    <li className="space-y-1 border-b py-2.5 text-sm last:border-0">
      <div className="flex items-start justify-between gap-2">
        <Badge variant={status.variant}>{status.label}</Badge>
        {claim.found ? (
          <button
            type="button"
            className="text-xs text-muted-foreground hover:underline"
            onClick={() => onLocate(claim.quote)}
          >
            Repérer dans le texte
          </button>
        ) : null}
      </div>
      <p className="italic">« {claim.quote} »</p>
      {claim.explanation ? (
        <p className="text-xs text-muted-foreground">{claim.explanation}</p>
      ) : null}
      {claim.source ? (
        <a
          href={claim.source.url}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
        >
          {claim.source.title} <ExternalLink className="size-3" />
        </a>
      ) : null}
      {claim.suggestion ? (
        <p className="rounded-md bg-muted p-2 text-xs">
          <span className="font-medium">Reformulation proposée : </span>
          {claim.suggestion}
        </p>
      ) : null}
    </li>
  );
}

export function FactCheckCard({
  projectId,
  draft,
  onLocate,
}: {
  projectId: string;
  draft: DraftPayload;
  onLocate: (quote: string) => void;
}) {
  const mutation = useMutation({
    mutationFn: () =>
      factCheckSemanticDocument({
        data: {
          projectId,
          html: draft.html,
          title: draft.title,
          keyword: draft.keyword,
        },
      }),
  });
  const result = mutation.data;
  const claims = result?.ok ? result.claims : [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Vérification des faits</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button
          type="button"
          variant="outline"
          className="w-full"
          disabled={mutation.isPending}
          onClick={() => mutation.mutate()}
        >
          {mutation.isPending ? <Loader2 className="animate-spin" /> : null}
          Vérifier les chiffres et affirmations
        </Button>
        <p className="text-xs italic text-muted-foreground">
          Chiffres, dates, études et réglementation vérifiés sur le web (environ
          1 à 3 minutes).
        </p>
        {mutation.isError ? (
          <Failure
            message={getStandardErrorMessage(
              mutation.error,
              "La vérification a échoué.",
            )}
          />
        ) : null}
        {result && !result.ok ? <Failure message={result.message} /> : null}
        {result?.ok ? (
          claims.length === 0 ? (
            <p className="text-sm text-success">
              Aucune affirmation vérifiable relevée.
            </p>
          ) : (
            <ul>
              {claims.map((claim) => (
                <ClaimRow key={claim.quote} claim={claim} onLocate={onLocate} />
              ))}
            </ul>
          )
        ) : null}
      </CardContent>
    </Card>
  );
}

function OutgoingList({ links }: { links: OutgoingLink[] }) {
  if (links.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Aucune page du site n&apos;est assez proche de ce sujet pour un lien
        naturel.
      </p>
    );
  }
  return (
    <ul className="space-y-2.5">
      {links.map((link) => (
        <li key={link.url} className="space-y-0.5 text-sm">
          <div className="font-medium">« {link.anchor} »</div>
          <a
            href={link.url}
            target="_blank"
            rel="noreferrer noopener"
            className="block truncate text-xs text-primary hover:underline"
          >
            {link.title}
          </a>
          {link.reason ? (
            <p className="text-xs text-muted-foreground">{link.reason}</p>
          ) : null}
        </li>
      ))}
    </ul>
  );
}

function IncomingList({
  suggestions,
}: {
  suggestions: IncomingLinkSuggestion[];
}) {
  if (suggestions.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Aucune page existante ne devrait pointer vers ce contenu pour le moment.
      </p>
    );
  }
  return (
    <ul className="space-y-3">
      {suggestions.map((s) => (
        <li key={s.url} className="space-y-1 text-sm">
          <a
            href={s.url}
            target="_blank"
            rel="noreferrer noopener"
            className="block truncate text-xs font-medium text-primary hover:underline"
          >
            {s.title}
          </a>
          <p className="text-xs text-muted-foreground line-through">
            {s.sentence}
          </p>
          <p className="text-xs">{s.newSentence}</p>
          {!s.found ? (
            <p className="text-xs text-amber-500">
              Phrase introuvable telle quelle sur la page : à vérifier.
            </p>
          ) : null}
          {s.reason ? (
            <p className="text-xs text-muted-foreground">{s.reason}</p>
          ) : null}
        </li>
      ))}
    </ul>
  );
}

type Direction = "outgoing" | "incoming";

export function LinksCard({
  projectId,
  draft,
}: {
  projectId: string;
  draft: DraftPayload;
}) {
  const [direction, setDirection] = useState<Direction | null>(null);
  const input = {
    projectId,
    html: draft.html,
    title: draft.title,
    keyword: draft.keyword,
    pageUrl: draft.pageUrl,
  };
  const outgoing = useMutation({
    mutationFn: () => suggestSemanticOutgoingLinks({ data: input }),
  });
  const incoming = useMutation({
    mutationFn: () => suggestSemanticIncomingLinks({ data: input }),
  });
  const active = direction === "outgoing" ? outgoing : incoming;
  const pending = outgoing.isPending || incoming.isPending;

  const run = (next: Direction) => {
    setDirection(next);
    (next === "outgoing" ? outgoing : incoming).mutate();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Maillage interne</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant={direction === "outgoing" ? "secondary" : "outline"}
            disabled={pending}
            onClick={() => run("outgoing")}
          >
            Liens sortants
          </Button>
          <Button
            type="button"
            variant={direction === "incoming" ? "secondary" : "outline"}
            disabled={pending}
            onClick={() => run("incoming")}
          >
            Liens entrants
          </Button>
        </div>
        <p className="text-xs italic text-muted-foreground">
          Sortants : pages à citer dans ce contenu. Entrants : pages existantes
          à modifier pour pointer vers lui. S&apos;appuie sur le dernier Site
          Audit du projet.
        </p>
        {pending ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Analyse en cours…
          </p>
        ) : null}
        {active.isError ? (
          <Failure
            message={getStandardErrorMessage(
              active.error,
              "L’analyse du maillage a échoué.",
            )}
          />
        ) : null}
        {active.data && !active.data.ok ? (
          <Failure message={active.data.message} />
        ) : null}
        {!pending && direction === "outgoing" && outgoing.data?.ok ? (
          <OutgoingList links={outgoing.data.links} />
        ) : null}
        {!pending && direction === "incoming" && incoming.data?.ok ? (
          <IncomingList suggestions={incoming.data.suggestions} />
        ) : null}
      </CardContent>
    </Card>
  );
}

export function RephrasePanel({
  status,
  options,
  onPick,
  onClose,
}: {
  status: string;
  options: string[];
  onPick: (option: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="space-y-2 rounded-lg border bg-muted/30 p-3">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm text-muted-foreground">{status}</p>
        <Button
          type="button"
          size="icon-xs"
          variant="ghost"
          aria-label="Fermer"
          onClick={onClose}
        >
          <X />
        </Button>
      </div>
      {options.map((option) => (
        <button
          key={option}
          type="button"
          className="block w-full rounded-md border bg-background p-2.5 text-left text-sm hover:border-primary"
          onClick={() => onPick(option)}
        >
          {option}
        </button>
      ))}
    </div>
  );
}
