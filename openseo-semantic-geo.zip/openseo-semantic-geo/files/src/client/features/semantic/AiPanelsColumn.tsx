import type { DraftAnalysis } from "@/shared/semantic/analyze";
import { FactCheckCard, LinksCard, type DraftPayload } from "./AiPanels";
import {
  buildTextMap,
  findQuote,
  matchesToRanges,
  setHighlight,
} from "./editorText";
import { StyleReviewCard } from "./StyleReviewCard";

/** Fact check, internal links and style review: the cards under the metrics. */
export function AiPanelsColumn({
  projectId,
  editorRoot,
  html,
  analysis,
  draft,
}: {
  projectId: string;
  editorRoot: HTMLElement | null;
  html: string;
  analysis: DraftAnalysis;
  draft: DraftPayload;
}) {
  const locate = (quote: string) => {
    if (!editorRoot) return;
    const map = buildTextMap(editorRoot);
    setHighlight(
      "fact-check",
      matchesToRanges(map.segments, findQuote(map.text, quote)),
    );
  };

  return (
    <>
      <FactCheckCard projectId={projectId} draft={draft} onLocate={locate} />
      <LinksCard projectId={projectId} draft={draft} />
      <StyleReviewCard
        editorRoot={editorRoot}
        html={html}
        analysis={analysis}
      />
    </>
  );
}
