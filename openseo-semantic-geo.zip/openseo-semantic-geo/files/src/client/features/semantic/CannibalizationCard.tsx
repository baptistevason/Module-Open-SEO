import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { getSemanticCannibalization } from "@/serverFunctions/semantic";
import type { CannibalPage } from "@/shared/semantic/types";

const DEBOUNCE_MS = 700;
const MIN_KEYWORD_CHARS = 3;
/** A page counts as already ranking from this position and these impressions. */
const RANKING_MAX_POSITION = 20;
const RANKING_MIN_IMPRESSIONS = 10;

const number = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });

function normalizeUrl(url: string): string {
  return url
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\/(www\.)?/, "")
    .replace(/\/$/, "");
}

function pathOf(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.pathname}${parsed.search}` || "/";
  } catch {
    return url;
  }
}

function PageRow({ page, own }: { page: CannibalPage; own: boolean }) {
  return (
    <li className="flex items-baseline justify-between gap-3 text-sm">
      <a
        href={page.page}
        target="_blank"
        rel="noreferrer noopener"
        className="min-w-0 truncate text-primary hover:underline"
        title={page.page}
      >
        {pathOf(page.page)}
        {own ? " (cette page)" : ""}
      </a>
      <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
        pos. {number.format(page.position)} · {page.impressions} imp. ·{" "}
        {page.clicks} clics
      </span>
    </li>
  );
}

/**
 * Before writing: does the site already rank on this keyword? Uses Search
 * Console (3 months). Prefer updating the page that ranks over a new one that
 * would compete with it.
 */
export function CannibalizationCard({
  projectId,
  keyword,
  pageUrl,
}: {
  projectId: string;
  keyword: string;
  pageUrl: string;
}) {
  const [debounced, setDebounced] = useState(keyword.trim());
  useEffect(() => {
    const timer = window.setTimeout(
      () => setDebounced(keyword.trim()),
      DEBOUNCE_MS,
    );
    return () => window.clearTimeout(timer);
  }, [keyword]);

  const enabled = debounced.length >= MIN_KEYWORD_CHARS;
  const query = useQuery({
    queryKey: ["semantic-cannibalization", projectId, debounced.toLowerCase()],
    queryFn: () =>
      getSemanticCannibalization({ data: { projectId, keyword: debounced } }),
    enabled,
    staleTime: 5 * 60 * 1000,
  });

  const data = query.data;
  const ownKey = pageUrl.trim() ? normalizeUrl(pageUrl) : null;
  const pages = data?.connected ? data.pages : [];
  const own = ownKey
    ? pages.find((p) => normalizeUrl(p.page) === ownKey)
    : undefined;
  const others = pages.filter((p) => normalizeUrl(p.page) !== ownKey);
  const competing = others.filter(
    (p) =>
      p.position <= RANKING_MAX_POSITION &&
      p.impressions >= RANKING_MIN_IMPRESSIONS,
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pages déjà positionnées</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {!enabled ? (
          <p className="text-xs text-muted-foreground">
            Saisissez un mot-clé : Search Console indique si une page du site se
            positionne déjà dessus.
          </p>
        ) : null}
        {enabled && query.isFetching ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Lecture de Search
            Console…
          </p>
        ) : null}
        {query.isError ? (
          <Alert variant="destructive">
            <AlertDescription>
              Impossible de lire Search Console pour le moment.
            </AlertDescription>
          </Alert>
        ) : null}
        {data && !data.connected ? (
          <p className="text-sm text-muted-foreground">
            Search Console n&apos;est pas connecté à ce projet.{" "}
            <Link
              to="/p/$projectId/search-performance"
              params={{ projectId }}
              className="text-primary hover:underline"
            >
              Connecter
            </Link>
          </p>
        ) : null}
        {data?.connected && !query.isFetching ? (
          <>
            {competing.length > 0 ? (
              <Alert>
                <AlertDescription>
                  {competing.length === 1
                    ? "Une page du site se positionne déjà"
                    : `${competing.length} pages du site se positionnent déjà`}{" "}
                  sur ce mot-clé : mettez à jour la meilleure plutôt que de
                  créer un contenu concurrent.
                </AlertDescription>
              </Alert>
            ) : null}
            {own ? (
              <p className="text-sm">
                Cette page se positionne déjà sur ce mot-clé (position{" "}
                {number.format(own.position)}) : vous optimisez un contenu
                existant.
              </p>
            ) : null}
            {pages.length === 0 ? (
              <p className="text-sm text-success">
                Aucune page du site ne reçoit d&apos;impressions sur ce mot-clé
                (3 derniers mois) : pas de risque de cannibalisation.
              </p>
            ) : (
              <ul className="space-y-1.5">
                {pages.map((page) => (
                  <PageRow
                    key={page.page}
                    page={page}
                    own={ownKey !== null && normalizeUrl(page.page) === ownKey}
                  />
                ))}
              </ul>
            )}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}
