import { CircleAlert, CircleCheck, CircleX } from "lucide-react";
import type { LexicalScore, LexicalStatus } from "@/shared/semantic/bands";
import { STATUS_LABEL, STATUS_STROKE } from "./lexicalColors";

const STATUS_ICON = {
  optimized: CircleCheck,
  under: CircleAlert,
  over: CircleX,
} satisfies Record<LexicalStatus, typeof CircleCheck>;

const STATUS_HELP: Record<LexicalStatus, string> = {
  optimized:
    "Les mots du champ lexical sont employés comme sur les pages qui se positionnent.",
  under:
    "Des mots manquent ou ne sont pas assez répétés : visez les fourchettes « Cible ».",
  over: "Trop de mots dépassent le maximum observé sur les pages qui se positionnent : réduisez-les.",
};

function Tile({
  label,
  value,
  reco,
  status,
}: {
  label: string;
  value: string;
  reco: string;
  status: LexicalStatus;
}) {
  const Icon = STATUS_ICON[status];
  return (
    <div className="flex items-center gap-3 rounded-lg border px-3 py-2">
      <div>
        <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </div>
        <div className="text-xs text-muted-foreground">{reco}</div>
      </div>
      <span
        className="text-2xl font-semibold tabular-nums"
        style={{ color: STATUS_STROKE[status] }}
      >
        {value}
      </span>
      <Icon
        className="size-6"
        style={{ color: STATUS_STROKE[status] }}
        aria-hidden
      />
    </div>
  );
}

/**
 * Score of the lexical field with one of three states: optimised (green),
 * under-optimised (orange), over-optimised (red), like the SOSEO / DSEO pair
 * of the semantic tools.
 */
export function LexicalScorePanel({ lexical }: { lexical: LexicalScore }) {
  const color = STATUS_STROKE[lexical.status];
  const overStatus: LexicalStatus =
    lexical.overCount > lexical.overTolerance ? "over" : "optimized";
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-3">
        <Tile
          label="Optimisation"
          value={String(lexical.score)}
          reco={`objectif ${lexical.target}+`}
          status={lexical.status === "optimized" ? "optimized" : "under"}
        />
        <Tile
          label="Suroptimisation"
          value={String(lexical.overCount)}
          reco={`reco 0 - ${lexical.overTolerance}`}
          status={overStatus}
        />
        <span
          className="rounded-full px-3 py-1 text-sm font-semibold text-white"
          style={{ backgroundColor: color }}
        >
          {STATUS_LABEL[lexical.status]}
        </span>
      </div>
      <p className="text-xs text-muted-foreground">
        {STATUS_HELP[lexical.status]}
      </p>
    </div>
  );
}
