import { Alert, AlertDescription } from "@/client/components/ui/alert";
import type { DraftAnalysis, ScorePart } from "@/shared/semantic/analyze";
import type { SemanticBrief } from "@/shared/semantic/types";
import type { Market } from "./MarketPicker";
import { KeywordCard, ScoreCard } from "./SemanticPanels";

/** Above the editor: target keyword, country and language, and the score. */
export function EditorTopPanel({
  analysis,
  score,
  brief,
  keyword,
  onKeywordChange,
  market,
  onMarketChange,
  onAnalyzeSerp,
  serpPending,
  serpError,
  stale,
}: {
  analysis: DraftAnalysis;
  score: { score: number; parts: ScorePart[]; hasBrief: boolean };
  brief: SemanticBrief | null;
  keyword: string;
  onKeywordChange: (value: string) => void;
  market: Market;
  onMarketChange: (market: Market) => void;
  onAnalyzeSerp: () => void;
  serpPending: boolean;
  serpError: string | null;
  stale: boolean;
}) {
  return (
    <div className="space-y-3">
      {serpError ? (
        <Alert variant="destructive">
          <AlertDescription>{serpError}</AlertDescription>
        </Alert>
      ) : null}
      {stale ? (
        <Alert>
          <AlertDescription>
            Le mot-clé, le pays ou la langue ont changé depuis la dernière
            analyse de la SERP : relancez-la pour comparer votre texte au bon
            top.
          </AlertDescription>
        </Alert>
      ) : null}
      <div className="grid items-start gap-4 lg:grid-cols-2">
        <KeywordCard
          analysis={analysis}
          keyword={keyword}
          onKeywordChange={onKeywordChange}
          onAnalyzeSerp={onAnalyzeSerp}
          serpPending={serpPending}
          market={market}
          onMarketChange={onMarketChange}
        />
        <ScoreCard
          score={score.score}
          parts={score.parts}
          hasBrief={score.hasBrief}
          target={brief?.scoreTarget}
        />
      </div>
    </div>
  );
}
