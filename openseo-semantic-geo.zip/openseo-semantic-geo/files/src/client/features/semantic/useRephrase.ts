import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import type { Editor } from "@tiptap/react";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import { rephraseSemanticPassage } from "@/serverFunctions/semantic";
import type { Rephrase } from "./editorTypes";

/** Rephrasing of the selected passage in the editor, with its panel state. */
export function useRephrase(
  projectId: string,
  keyword: string,
  editor: Editor | null,
) {
  const [rephrase, setRephrase] = useState<Rephrase | null>(null);
  const rephraseMutation = useMutation({
    mutationFn: (input: { text: string; context: string }) =>
      rephraseSemanticPassage({
        data: { projectId, keyword, ...input },
      }),
  });

  const requestRephrase = () => {
    if (!editor) return;
    const { from, to, empty, $from } = editor.state.selection;
    if (empty) {
      setRephrase({
        status:
          "Sélectionnez d’abord une phrase ou un paragraphe dans l’éditeur.",
        options: [],
        from,
        to,
      });
      return;
    }
    const text = editor.state.doc.textBetween(from, to, " ");
    setRephrase({ status: "Reformulation en cours…", options: [], from, to });
    rephraseMutation.mutate(
      { text, context: $from.parent.textContent },
      {
        onSuccess: (result) =>
          setRephrase({
            status: result.ok
              ? "Cliquez une proposition pour remplacer la sélection (Annuler pour revenir)."
              : result.message,
            options: result.ok ? result.options : [],
            from,
            to,
          }),
        onError: (error) =>
          setRephrase({
            status: getStandardErrorMessage(
              error,
              "La reformulation a échoué.",
            ),
            options: [],
            from,
            to,
          }),
      },
    );
  };

  const applyRephrase = (option: string) => {
    if (!editor || !rephrase) return;
    editor
      .chain()
      .focus()
      .insertContentAt({ from: rephrase.from, to: rephrase.to }, option)
      .run();
    setRephrase(null);
  };

  return {
    rephrase,
    close: () => setRephrase(null),
    request: requestRephrase,
    apply: applyRephrase,
    pending: rephraseMutation.isPending,
  };
}
