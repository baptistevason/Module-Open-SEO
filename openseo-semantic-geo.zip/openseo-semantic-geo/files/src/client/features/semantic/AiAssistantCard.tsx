import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import type { Editor } from "@tiptap/react";
import { Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { Button } from "@/client/components/ui/button";
import { Checkbox } from "@/client/components/ui/checkbox";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { CopyButton } from "@/client/components/CopyButton";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import { generateSemanticContent } from "@/serverFunctions/semantic";
import { countWords } from "@/shared/semantic/geo";
import {
  faqToHtml,
  faqToText,
  outlineToHtml,
  paragraphToHtml,
  type GenerateKind,
  type GeneratedContent,
} from "@/shared/semantic/generate";

const ACTIONS: { kind: GenerateKind; label: string; hint: string }[] = [
  {
    kind: "faq",
    label: "Générer une FAQ",
    hint: "6 questions et réponses courtes",
  },
  {
    kind: "blurb",
    label: "Introduction GEO",
    hint: "3 versions de 40 à 80 mots",
  },
  { kind: "meta", label: "Title et méta", hint: "3 propositions de chaque" },
  { kind: "outline", label: "Plan de l’article", hint: "Sections H2 et H3" },
];

function insertAtEnd(editor: Editor, html: string) {
  editor.chain().focus("end").insertContent(html).run();
}

/** Right after the first H1, or at the very top when there is none. */
function insertAfterTitle(editor: Editor, html: string) {
  let position = 0;
  let found = false;
  editor.state.doc.descendants((node, pos) => {
    if (found) return false;
    if (node.type.name === "heading" && node.attrs.level === 1) {
      position = pos + node.nodeSize;
      found = true;
      return false;
    }
    return true;
  });
  editor.chain().focus().insertContentAt(position, html).run();
}

function OptionButton({
  text,
  suffix,
  onPick,
}: {
  text: string;
  suffix: string;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      className="block w-full rounded-md border bg-background p-2.5 text-left text-sm hover:border-primary"
      onClick={onPick}
    >
      {text}
      <span className="mt-1 block text-xs text-muted-foreground">{suffix}</span>
    </button>
  );
}

type ResultProps = {
  content: GeneratedContent;
  editor: Editor | null;
  onApplyTitle: (title: string) => void;
  onApplyMeta: (meta: string) => void;
  onNotice: (message: string) => void;
};

function FaqResult({
  content,
  editor,
  onNotice,
}: ResultProps & { content: Extract<GeneratedContent, { kind: "faq" }> }) {
  const [skipped, setSkipped] = useState<Set<number>>(new Set());
  const chosen = content.items.filter((_, i) => !skipped.has(i));
  return (
    <div className="space-y-3">
      <ul className="space-y-2.5">
        {content.items.map((item, i) => (
          <li key={item.question} className="flex gap-2 text-sm">
            <Checkbox
              checked={!skipped.has(i)}
              onCheckedChange={(value) =>
                setSkipped((current) => {
                  const next = new Set(current);
                  if (value) next.delete(i);
                  else next.add(i);
                  return next;
                })
              }
              aria-label={`Inclure : ${item.question}`}
            />
            <div className="min-w-0">
              <div className="font-medium">{item.question}</div>
              <p className="text-xs text-muted-foreground">{item.answer}</p>
            </div>
          </li>
        ))}
      </ul>
      <div className="flex flex-wrap gap-2">
        <Button
          size="sm"
          disabled={!editor || chosen.length === 0}
          onClick={() => {
            if (!editor) return;
            insertAtEnd(editor, faqToHtml(chosen));
            onNotice(
              "FAQ insérée à la fin du texte. Le schema FAQPage se met à jour dans la carte Schema.org.",
            );
          }}
        >
          Insérer dans le texte
        </Button>
        <CopyButton
          value={faqToText(chosen)}
          successMessage="FAQ copiée"
          label="Copier la FAQ"
          size="sm"
        />
      </div>
    </div>
  );
}

function ContentResult(props: ResultProps) {
  const { content, editor, onApplyTitle, onApplyMeta, onNotice } = props;
  if (content.kind === "faq") return <FaqResult {...props} content={content} />;
  if (content.kind === "blurb") {
    return (
      <div className="space-y-2">
        {content.options.map((option) => (
          <OptionButton
            key={option}
            text={option}
            suffix={`${countWords(option)} mots · cliquer pour insérer sous le titre`}
            onPick={() => {
              if (!editor) return;
              insertAfterTitle(editor, paragraphToHtml(option));
              onNotice(
                "Introduction insérée sous le titre. Supprimez l’ancienne si besoin.",
              );
            }}
          />
        ))}
      </div>
    );
  }
  if (content.kind === "meta") {
    return (
      <div className="space-y-3">
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Titres
          </div>
          {content.titles.map((title) => (
            <OptionButton
              key={title}
              text={title}
              suffix={`${title.length} caractères · cliquer pour appliquer`}
              onPick={() => {
                onApplyTitle(title);
                onNotice("Titre appliqué.");
              }}
            />
          ))}
        </div>
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Méta descriptions
          </div>
          {content.descriptions.map((meta) => (
            <OptionButton
              key={meta}
              text={meta}
              suffix={`${meta.length} caractères · cliquer pour appliquer`}
              onPick={() => {
                onApplyMeta(meta);
                onNotice("Méta description appliquée.");
              }}
            />
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-3">
      <ul className="space-y-2 text-sm">
        {content.sections.map((section) => (
          <li key={section.h2}>
            <div className="font-medium">{section.h2}</div>
            {section.h3.length > 0 ? (
              <ul className="list-disc pl-5 text-xs text-muted-foreground">
                {section.h3.map((h3) => (
                  <li key={h3}>{h3}</li>
                ))}
              </ul>
            ) : null}
          </li>
        ))}
      </ul>
      <Button
        size="sm"
        disabled={!editor}
        onClick={() => {
          if (!editor) return;
          insertAtEnd(editor, outlineToHtml(content.sections));
          onNotice(
            "Plan inséré à la fin du texte, avec un paragraphe vide à remplir sous chaque titre.",
          );
        }}
      >
        Insérer le plan dans le texte
      </Button>
    </div>
  );
}

/**
 * AI writing helpers of the editor: FAQ, GEO introduction, title and meta
 * description, outline. Each result is previewed, then inserted or applied.
 */
export function AiAssistantCard({
  projectId,
  html,
  title,
  keyword,
  terms,
  headings,
  editor,
  onApplyTitle,
  onApplyMeta,
}: {
  projectId: string;
  html: string;
  title: string;
  keyword: string;
  terms: string[];
  headings: string[];
  editor: Editor | null;
  onApplyTitle: (title: string) => void;
  onApplyMeta: (meta: string) => void;
}) {
  const [content, setContent] = useState<GeneratedContent | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, setPending] = useState<GenerateKind | null>(null);

  const mutation = useMutation({
    mutationFn: (kind: GenerateKind) =>
      generateSemanticContent({
        data: { projectId, kind, html, title, keyword, terms, headings },
      }),
    onMutate: (kind) => {
      setPending(kind);
      setNotice(null);
    },
    onSuccess: (result) => {
      if (result.ok) setContent(result.content);
    },
    onSettled: () => setPending(null),
  });

  const failure =
    mutation.data && !mutation.data.ok
      ? mutation.data.message
      : mutation.isError
        ? getStandardErrorMessage(mutation.error, "La génération a échoué.")
        : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Assistant IA</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {ACTIONS.map(({ kind, label, hint }) => (
            <Button
              key={kind}
              type="button"
              variant={content?.kind === kind ? "secondary" : "outline"}
              className="h-auto flex-col items-start gap-0.5 whitespace-normal py-2 text-left"
              disabled={pending !== null}
              onClick={() => mutation.mutate(kind)}
            >
              <span className="flex items-center gap-1.5 text-sm">
                {pending === kind ? <Loader2 className="animate-spin" /> : null}
                {label}
              </span>
              <span className="text-xs font-normal text-muted-foreground">
                {hint}
              </span>
            </Button>
          ))}
        </div>
        <p className="text-xs italic text-muted-foreground">
          Les textes s’appuient sur votre contenu, votre mot-clé et le champ
          lexical analysé. Relisez toujours avant de publier : aucun chiffre ni
          source n’est inventé volontairement, mais vérifiez-les.
        </p>
        {failure ? (
          <Alert variant="destructive">
            <AlertDescription>{failure}</AlertDescription>
          </Alert>
        ) : null}
        {notice ? (
          <Alert>
            <AlertDescription>{notice}</AlertDescription>
          </Alert>
        ) : null}
        {content ? (
          <ContentResult
            content={content}
            editor={editor}
            onApplyTitle={onApplyTitle}
            onApplyMeta={onApplyMeta}
            onNotice={setNotice}
          />
        ) : null}
      </CardContent>
    </Card>
  );
}
