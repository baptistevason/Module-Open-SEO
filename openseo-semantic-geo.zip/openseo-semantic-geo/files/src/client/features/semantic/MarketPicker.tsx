import { LocationSelect } from "@/client/components/LocationSelect";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/client/components/ui/select";
import {
  SERP_LANGUAGE_OPTIONS,
  getLanguageCode,
} from "@/shared/keyword-locations";

export type Market = { locationCode: number; languageCode: string };

/**
 * Country and language of the SERP to analyse. Changing the country snaps the
 * language to that country's own; the language can then be set apart (a French
 * site targeting Belgium, an English page for France…).
 */
export function MarketPicker({
  market,
  onChange,
}: {
  market: Market;
  onChange: (market: Market) => void;
}) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      <label className="space-y-1">
        <span className="text-xs font-medium text-muted-foreground">
          Pays cible
        </span>
        <LocationSelect
          value={market.locationCode}
          onChange={(locationCode) =>
            onChange({
              locationCode,
              languageCode: getLanguageCode(locationCode),
            })
          }
        />
      </label>
      <label className="space-y-1">
        <span className="text-xs font-medium text-muted-foreground">
          Langue
        </span>
        <Select
          items={SERP_LANGUAGE_OPTIONS.map((l) => ({
            value: l.code,
            label: l.label,
          }))}
          value={market.languageCode}
          onValueChange={(languageCode) => {
            if (languageCode) onChange({ ...market, languageCode });
          }}
        >
          <SelectTrigger className="w-full" aria-label="Langue de la SERP">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SERP_LANGUAGE_OPTIONS.map((language) => (
              <SelectItem key={language.code} value={language.code}>
                {language.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </label>
    </div>
  );
}
