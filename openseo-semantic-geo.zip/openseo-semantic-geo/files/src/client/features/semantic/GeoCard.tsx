import { useMemo } from "react";
import { CircleAlert, CircleCheck, CircleX } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { analyzeGeo, type GeoStatus } from "@/shared/semantic/geo";

const STATUS_STYLE: Record<
  GeoStatus,
  { icon: typeof CircleCheck; color: string }
> = {
  ok: { icon: CircleCheck, color: "text-success" },
  warn: { icon: CircleAlert, color: "text-amber-500" },
  fail: { icon: CircleX, color: "text-destructive" },
};

/**
 * GEO readiness: whether AI answer engines can easily quote the content.
 * Heuristics only (no promise of citation), recomputed live from the editor.
 */
export function GeoCard({ html }: { html: string }) {
  const geo = useMemo(() => analyzeGeo(html), [html]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Optimisation GEO{" "}
          <span className="text-sm font-normal text-muted-foreground">
            {geo.passed} / {geo.total}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {geo.checks.map((check) => {
            const { icon: Icon, color } = STATUS_STYLE[check.status];
            return (
              <li key={check.id} className="flex gap-2.5 text-sm">
                <Icon
                  className={`mt-0.5 size-4 shrink-0 ${color}`}
                  aria-hidden
                />
                <div className="min-w-0 space-y-0.5">
                  <div className="font-medium">{check.label}</div>
                  <p className="text-xs text-muted-foreground">
                    {check.detail}
                  </p>
                  {check.items && check.items.length > 0 ? (
                    <ul className="list-disc pl-4 text-xs text-muted-foreground">
                      {check.items.map((item) => (
                        <li key={item} className="break-words">
                          {item}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
        <p className="mt-3 text-xs italic text-muted-foreground">
          Ces contrôles repèrent les habitudes qui rendent un passage facile à
          citer par une IA ; ils ne garantissent pas une citation.
        </p>
      </CardContent>
    </Card>
  );
}
