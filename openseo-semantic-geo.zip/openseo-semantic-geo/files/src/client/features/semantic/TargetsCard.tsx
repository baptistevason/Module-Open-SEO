import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import type { BriefMetricKey, BriefTargets } from "@/shared/semantic/types";
import type { TargetRow, TargetStatus } from "@/shared/semantic/targets";

const number = new Intl.NumberFormat("fr-FR");

const LABEL: Record<BriefMetricKey, string> = {
  words: "Mots",
  h2: "Titres H2",
  h3: "Titres H3",
  paragraphs: "Paragraphes",
  images: "Images",
  videos: "Vidéos",
  tables: "Tableaux",
  lists: "Listes",
  bold: "Mots en gras",
  internalLinks: "Liens internes",
  externalLinks: "Liens externes",
};

// Metrics where being above the range is not a problem by itself.
const MEDIA: BriefMetricKey[] = ["images", "videos", "tables", "lists"];

const STATUS_STYLE: Record<TargetStatus, string> = {
  below: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  within: "bg-green-500/20 text-green-800 dark:text-green-200",
  above: "bg-sky-500/15 text-sky-700 dark:text-sky-300",
};

function statusText(row: TargetRow): string {
  if (row.status === "below") return `Il manque ${number.format(row.missing)}`;
  if (row.status === "within") return "Dans la cible";
  return "Au-dessus";
}

function rangeText(row: TargetRow): string {
  return row.low === row.high
    ? number.format(row.low)
    : `${number.format(row.low)} à ${number.format(row.high)}`;
}

function LengthHeadline({
  row,
  targets,
  pagesRead,
}: {
  row: TargetRow;
  targets: BriefTargets;
  pagesRead: number;
}) {
  const scale = Math.max(row.high * 1.3, row.yours, 1);
  const percent = (value: number) => `${Math.min(100, (value / scale) * 100)}%`;
  return (
    <div className="space-y-2">
      <div>
        <div className="text-2xl font-semibold tabular-nums">
          {rangeText(row)} mots
        </div>
        <p className="text-xs text-muted-foreground">
          Médiane {number.format(row.target.median)} · de{" "}
          {number.format(row.target.min)} à {number.format(row.target.max)} sur
          les {pagesRead} pages lues
          {targets.outliers > 0
            ? ` (${targets.outliers} page${targets.outliers > 1 ? "s" : ""} de longueur aberrante écartée${targets.outliers > 1 ? "s" : ""})`
            : ""}
          .
        </p>
      </div>
      <div className="relative h-2.5 rounded-full bg-muted">
        <div
          className="absolute inset-y-0 rounded-full bg-green-500/30"
          style={{
            left: percent(row.low),
            width: `calc(${percent(row.high)} - ${percent(row.low)})`,
          }}
        />
        <div
          className="absolute top-1/2 size-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-background bg-primary"
          style={{ left: percent(row.yours) }}
        />
      </div>
      <p className="text-xs">
        Votre texte :{" "}
        <span className="font-semibold">{number.format(row.yours)} mots</span>{" "}
        {row.status === "below"
          ? `(encore ${number.format(row.missing)} pour atteindre la cible)`
          : row.status === "within"
            ? "(dans la cible)"
            : "(au-dessus de la cible : vérifiez que tout est utile)"}
      </p>
    </div>
  );
}

/**
 * How many words, headings, images, videos, tables, lists and links the pages
 * that rank use, and where the draft stands. Benchmarks from the pages read,
 * not rules: no study shows a number of images or videos ranks a page.
 */
export function TargetsCard({
  rows,
  targets,
  pagesRead,
  imagesMissingAlt,
  sections,
}: {
  rows: TargetRow[];
  targets: BriefTargets;
  pagesRead: number;
  imagesMissingAlt: number;
  sections: { heading: string; words: number }[];
}) {
  const length = rows.find((r) => r.key === "words");
  const others = rows.filter((r) => r.key !== "words");
  const perSection = targets.wordsPerSection;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Cibles de la page 1</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {length ? (
          <LengthHeadline
            row={length}
            targets={targets}
            pagesRead={pagesRead}
          />
        ) : null}

        <ul>
          {others.map((row) => (
            <li
              key={row.key}
              className="flex items-center justify-between gap-2 border-b py-2 text-sm last:border-0"
            >
              <div className="min-w-0">
                <span>{LABEL[row.key]}</span>
                {MEDIA.includes(row.key) ? (
                  <span className="block text-xs text-muted-foreground">
                    {row.target.pagesWith} page
                    {row.target.pagesWith > 1 ? "s" : ""} sur {pagesRead} en{" "}
                    {row.target.pagesWith > 1 ? "ont" : "a"}
                  </span>
                ) : null}
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="tabular-nums">
                  <span className="font-semibold">
                    {number.format(row.yours)}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {" "}
                    / {rangeText(row)}
                  </span>
                </span>
                <span
                  className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_STYLE[row.status]}`}
                >
                  {statusText(row)}
                </span>
              </div>
            </li>
          ))}
        </ul>

        {imagesMissingAlt > 0 ? (
          <p className="text-xs text-amber-600 dark:text-amber-300">
            {imagesMissingAlt} image{imagesMissingAlt > 1 ? "s" : ""} sans texte
            alternatif : décrivez-{imagesMissingAlt > 1 ? "les" : "la"}.
          </p>
        ) : null}

        {perSection !== null && sections.length > 0 ? (
          <details>
            <summary className="cursor-pointer text-xs font-medium">
              Longueur par section (cible : environ {number.format(perSection)}{" "}
              mots)
            </summary>
            <ul className="mt-2 space-y-1">
              {sections.map((section) => {
                const short = section.words < perSection * 0.5;
                const long = section.words > perSection * 2;
                return (
                  <li
                    key={section.heading}
                    className="flex items-center justify-between gap-3 text-xs"
                  >
                    <span className="min-w-0 truncate">{section.heading}</span>
                    <span
                      className={`shrink-0 tabular-nums ${short ? "text-amber-600 dark:text-amber-300" : long ? "text-sky-600 dark:text-sky-300" : "text-muted-foreground"}`}
                    >
                      {number.format(section.words)} mots
                      {short ? " · courte" : long ? " · longue" : ""}
                    </span>
                  </li>
                );
              })}
            </ul>
          </details>
        ) : null}

        <p className="text-xs italic text-muted-foreground">
          Repères tirés des pages lues, pas des règles : aucune étude ne montre
          qu’un nombre d’images ou de vidéos suffit à faire ranker une page.
        </p>
      </CardContent>
    </Card>
  );
}
