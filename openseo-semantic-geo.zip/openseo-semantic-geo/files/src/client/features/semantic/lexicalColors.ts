import type { LexicalStatus, Zone } from "@/shared/semantic/bands";

// One palette for the lexical-field chart and its score: orange = under,
// green = optimised, red = over. The "strong" zone sits between green and red.
export const ZONE_FILL: Record<Zone, string> = {
  under: "#fdba74",
  normal: "#86efac",
  strong: "#fde047",
  over: "#f87171",
};

export const ZONE_STROKE: Record<Zone, string> = {
  under: "#f97316",
  normal: "#22c55e",
  strong: "#eab308",
  over: "#ef4444",
};

export const STATUS_STROKE: Record<LexicalStatus, string> = {
  under: ZONE_STROKE.under,
  optimized: ZONE_STROKE.normal,
  over: ZONE_STROKE.over,
};

export const STATUS_LABEL: Record<LexicalStatus, string> = {
  under: "Sous-optimisé",
  optimized: "Optimisé",
  over: "Sur-optimisé",
};
