import { useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { htmlToPlainText } from "@/shared/semantic/html";
import { analyzeReadability, fleschLevel } from "@/shared/semantic/readability";
import type { BriefReadability } from "@/shared/semantic/types";

const TONE_CLASS = {
  good: "text-success",
  mid: "text-amber-500",
  bad: "text-destructive",
} as const;

const percent = (value: number) => `${Math.round(value * 100)} %`;

function Row({
  label,
  value,
  top,
  worse,
}: {
  label: string;
  value: string;
  /** What the pages that rank do, when known. */
  top?: string;
  worse?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b py-1.5 text-sm last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right tabular-nums">
        <span
          className={worse ? "font-semibold text-amber-500" : "font-semibold"}
        >
          {value}
        </span>
        {top ? (
          <span className="text-xs text-muted-foreground">
            {" "}
            · page 1 : {top}
          </span>
        ) : null}
      </span>
    </div>
  );
}

/** Readability of the text (Flesch, sentences, passive voice), next to the top. */
export function ReadabilityCard({
  html,
  languageCode,
  top,
}: {
  html: string;
  languageCode: string;
  /** Median readability of the ranking pages, when the SERP was analysed. */
  top?: BriefReadability;
}) {
  const result = useMemo(
    () => analyzeReadability(htmlToPlainText(html), languageCode),
    [html, languageCode],
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lisibilité</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {!result ? (
          <p className="text-sm text-muted-foreground">
            Écrivez quelques phrases de plus pour mesurer la lisibilité.
          </p>
        ) : (
          <>
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-semibold tabular-nums">
                {result.flesch}
              </span>
              <span
                className={`text-sm font-medium ${TONE_CLASS[fleschLevel(result.flesch).tone]}`}
              >
                {fleschLevel(result.flesch).label}
              </span>
              {top ? (
                <span className="text-xs text-muted-foreground">
                  page 1 : {top.flesch} (
                  {fleschLevel(top.flesch).label.toLowerCase()})
                </span>
              ) : null}
            </div>
            <div>
              <Row
                label="Longueur moyenne des phrases"
                value={`${result.avgSentence} mots`}
                top={top ? `${top.avgSentence}` : undefined}
                worse={result.avgSentence > 24}
              />
              <Row
                label="Phrases de plus de 25 mots"
                value={percent(result.longSentenceShare)}
                top={top ? percent(top.longSentenceShare) : undefined}
                worse={result.longSentenceShare > 0.2}
              />
              <Row
                label="Phrases au passif (estimation)"
                value={percent(result.passiveShare)}
                top={top ? percent(top.passiveShare) : undefined}
                worse={result.passiveShare > 0.25}
              />
            </div>
            <p className="text-xs italic text-muted-foreground">
              Indice de Flesch adapté au français : plus il est haut, plus le
              texte se lit facilement. Au-dessus de 60, un lecteur pressé suit
              sans effort.
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
