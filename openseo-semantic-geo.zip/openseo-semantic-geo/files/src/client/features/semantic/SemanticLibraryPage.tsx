import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FilePlus2, FileText } from "lucide-react";
import { EmptyState } from "@/client/components/EmptyState";
import { InlineConfirm } from "@/client/components/InlineConfirm";
import { PageHeader } from "@/client/components/PageHeader";
import { QueryError } from "@/client/components/QueryState";
import { SkeletonCard } from "@/client/components/SkeletonPresets";
import { Badge } from "@/client/components/ui/badge";
import { Button } from "@/client/components/ui/button";
import { Input } from "@/client/components/ui/input";
import {
  Table,
  TableBody,
  TableCard,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/client/components/ui/table";
import {
  deleteSemanticDocument,
  listSemanticDocuments,
} from "@/serverFunctions/semantic";
import type { SemanticDocumentSummary } from "@/types/schemas/semantic-documents";

type StatusFilter = "all" | "prod" | "draft";

const STATUS_FILTERS: { key: StatusFilter; label: string }[] = [
  { key: "all", label: "Tous" },
  { key: "prod", label: "En production" },
  { key: "draft", label: "Brouillons" },
];

function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function ScoreBadge({ score }: { score: number | null }) {
  if (score === null) return <span className="text-muted-foreground">-</span>;
  const variant =
    score >= 80 ? "success" : score >= 55 ? "outline" : "destructive";
  return <Badge variant={variant}>{score} / 100</Badge>;
}

function matches(doc: SemanticDocumentSummary, query: string): boolean {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;
  return [doc.keyword, doc.slug, doc.title].some((value) =>
    value.toLowerCase().includes(needle),
  );
}

export function SemanticLibraryPage({ projectId }: { projectId: string }) {
  const queryClient = useQueryClient();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const queryKey = ["semantic-documents", projectId];
  const listQuery = useQuery({
    queryKey,
    queryFn: () => listSemanticDocuments({ data: { projectId } }),
  });
  const removeMutation = useMutation({
    mutationFn: (id: string) =>
      deleteSemanticDocument({ data: { projectId, id } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey }),
  });

  const documents = listQuery.data;
  const visible = useMemo(
    () =>
      (documents ?? []).filter(
        (doc) =>
          matches(doc, query) &&
          (status === "all" ||
            (status === "prod") === (doc.publishedAt !== null)),
      ),
    [documents, query, status],
  );

  const newButton = (
    <Button
      nativeButton={false}
      render={
        <Link
          to="/p/$projectId/semantic/$documentId"
          params={{ projectId, documentId: "new" }}
        />
      }
    >
      <FilePlus2 /> Nouveau contenu
    </Button>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Optimisation SEO"
        description="Historique des mots-clés travaillés sur ce projet : score, dates et mise en production."
        actions={newButton}
      />
      {listQuery.isPending ? <SkeletonCard /> : null}
      {listQuery.isError ? (
        <QueryError
          error={listQuery.error}
          fallback="Impossible de charger l’historique."
          onRetry={() => void listQuery.refetch()}
        />
      ) : null}
      {documents && documents.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="Aucun mot-clé travaillé pour l’instant"
          description="Créez un contenu ou importez une page existante pour mesurer son optimisation sémantique."
          action={newButton}
        />
      ) : null}
      {documents && documents.length > 0 ? (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Filtrer par mot-clé ou slug"
              aria-label="Filtrer par mot-clé ou slug"
              className="max-w-xs"
            />
            {STATUS_FILTERS.map(({ key, label }) => (
              <Button
                key={key}
                type="button"
                size="sm"
                variant={status === key ? "secondary" : "ghost"}
                onClick={() => setStatus(key)}
              >
                {label}
              </Button>
            ))}
            <span className="ml-auto text-xs text-muted-foreground">
              {visible.length} / {documents.length}
            </span>
          </div>
          <TableCard>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Mot-clé cible</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Création</TableHead>
                  <TableHead>Dernière modification</TableHead>
                  <TableHead>Mise en prod</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell className="max-w-64">
                      <Link
                        to="/p/$projectId/semantic/$documentId"
                        params={{ projectId, documentId: doc.id }}
                        className="block truncate font-medium hover:underline"
                        title={doc.title}
                      >
                        {doc.keyword || doc.title}
                      </Link>
                    </TableCell>
                    <TableCell className="max-w-48 truncate text-muted-foreground">
                      {doc.slug ? `/${doc.slug}` : "-"}
                    </TableCell>
                    <TableCell>
                      <ScoreBadge score={doc.score} />
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {formatDate(doc.createdAt)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {formatDate(doc.updatedAt)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {doc.publishedAt ? (
                        <Badge variant="success">
                          {formatDate(doc.publishedAt)}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">Brouillon</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <InlineConfirm
                        label={`Supprimer ${doc.title}`}
                        confirmLabel="Supprimer"
                        pending={
                          removeMutation.isPending &&
                          removeMutation.variables === doc.id
                        }
                        onConfirm={() => removeMutation.mutate(doc.id)}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableCard>
          {visible.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Aucun contenu ne correspond à ce filtre.
            </p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
