import { useMemo } from "react";
import {
  buildTargetRows,
  draftCounts,
  sectionWords,
  type TargetRow,
} from "@/shared/semantic/targets";
import type { SemanticBrief } from "@/shared/semantic/types";

export type TargetView = {
  rows: TargetRow[];
  sections: { heading: string; words: number }[];
  imagesMissingAlt: number;
};

/** The draft measured against the targets of the pages that rank, if any. */
export function useTargetView(
  brief: SemanticBrief | null,
  html: string,
  pageUrl: string,
  totalWords: number,
): TargetView | null {
  return useMemo(() => {
    if (!brief?.targets) return null;
    const { counts, doc } = draftCounts(html, pageUrl, totalWords);
    return {
      rows: buildTargetRows(counts, brief.targets),
      sections: sectionWords(html),
      imagesMissingAlt: doc.imagesMissingAlt,
    };
  }, [brief, html, pageUrl, totalWords]);
}
