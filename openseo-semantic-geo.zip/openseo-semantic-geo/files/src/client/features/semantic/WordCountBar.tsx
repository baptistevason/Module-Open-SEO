import type { TargetRow } from "@/shared/semantic/targets";

const number = new Intl.NumberFormat("fr-FR");

/** Live word count under the editor, against the length of the pages that rank. */
export function WordCountBar({ row }: { row: TargetRow }) {
  const percent = row.high > 0 ? Math.round((row.yours / row.high) * 100) : 0;
  const color =
    row.status === "within"
      ? "bg-green-500"
      : row.status === "below"
        ? "bg-amber-500"
        : "bg-sky-500";
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border bg-card px-4 py-2 text-sm">
      <span>
        <span className="font-semibold tabular-nums">
          {number.format(row.yours)}
        </span>{" "}
        mots
      </span>
      <span className="text-muted-foreground">
        cible {number.format(row.low)} à {number.format(row.high)}
      </span>
      <div className="h-1.5 min-w-24 flex-1 overflow-hidden rounded-full bg-muted">
        <div
          className={`h-full rounded-full ${color}`}
          style={{ width: `${Math.min(100, percent)}%` }}
        />
      </div>
      <span className="text-xs text-muted-foreground tabular-nums">
        {row.status === "below"
          ? `encore ${number.format(row.missing)}`
          : row.status === "within"
            ? "dans la cible"
            : "au-dessus"}
      </span>
    </div>
  );
}
