import { Download, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { Button } from "@/client/components/ui/button";
import { Card, CardContent } from "@/client/components/ui/card";
import { Input } from "@/client/components/ui/input";

export type SeoFields = {
  title: string;
  keyword: string;
  metaDescription: string;
  slug: string;
  pageUrl: string;
};

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block space-y-1">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

/** Title tag, meta description, slug and the "import a page" shortcut. */
export function SeoFieldsCard({
  fields,
  onChange,
  importUrl,
  onImportUrlChange,
  onImport,
  importing,
  canImport,
  importError,
}: {
  fields: SeoFields;
  onChange: (patch: Partial<SeoFields>) => void;
  importUrl: string;
  onImportUrlChange: (value: string) => void;
  onImport: () => void;
  importing: boolean;
  canImport: boolean;
  importError: string | null;
}) {
  return (
    <Card>
      <CardContent className="space-y-3">
        <Field label="Titre (balise title)">
          <Input
            value={fields.title}
            onChange={(e) => onChange({ title: e.target.value })}
            placeholder="Titre du contenu"
            className="text-base font-medium"
          />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Méta description">
            <Input
              value={fields.metaDescription}
              onChange={(e) => onChange({ metaDescription: e.target.value })}
            />
          </Field>
          <Field label="Slug">
            <Input
              value={fields.slug}
              onChange={(e) => onChange({ slug: e.target.value })}
              placeholder="mon-article"
            />
          </Field>
        </div>
        <Field label="URL de la page (publiée ou cible)">
          <Input
            value={fields.pageUrl}
            onChange={(e) => onChange({ pageUrl: e.target.value })}
            placeholder="https://exemple.fr/mon-article"
          />
        </Field>
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-0 flex-1 basis-64">
            <Field label="Importer le texte d’une page (la vôtre ou un concurrent)">
              <Input
                value={importUrl}
                onChange={(e) => onImportUrlChange(e.target.value)}
                placeholder="https://exemple.fr/page"
              />
            </Field>
          </div>
          <Button
            type="button"
            variant="outline"
            disabled={importUrl.trim().length < 4 || importing || !canImport}
            onClick={onImport}
          >
            {importing ? <Loader2 className="animate-spin" /> : <Download />}
            Importer
          </Button>
        </div>
        {importError ? (
          <Alert variant="destructive">
            <AlertDescription>{importError}</AlertDescription>
          </Alert>
        ) : null}
      </CardContent>
    </Card>
  );
}
