import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { getSemanticAfterPublish } from "@/serverFunctions/semantic";
import type { PeriodTotals } from "@/shared/semantic/types";

const number = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });

type Delta = { text: string; tone: "good" | "bad" | "flat" };

function volumeDelta(before: number, after: number): Delta {
  if (before === 0 && after === 0) return { text: "=", tone: "flat" };
  if (before === 0) return { text: "nouveau", tone: "good" };
  const pct = ((after - before) / before) * 100;
  if (Math.abs(pct) < 1) return { text: "=", tone: "flat" };
  return {
    text: `${pct > 0 ? "+" : ""}${number.format(pct)} %`,
    tone: pct > 0 ? "good" : "bad",
  };
}

/** Lower is better for a position: a drop in the number is a gain. */
function positionDelta(before: number, after: number): Delta {
  if (before === 0 || after === 0) return { text: "-", tone: "flat" };
  const gain = before - after;
  if (Math.abs(gain) < 0.1) return { text: "=", tone: "flat" };
  return {
    text: `${gain > 0 ? "+" : ""}${number.format(gain)} place${Math.abs(gain) >= 2 ? "s" : ""}`,
    tone: gain > 0 ? "good" : "bad",
  };
}

const TONE: Record<Delta["tone"], string> = {
  good: "text-success",
  bad: "text-destructive",
  flat: "text-muted-foreground",
};

function Metric({
  label,
  before,
  after,
  delta,
}: {
  label: string;
  before: string;
  after: string;
  delta: Delta;
}) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b py-1.5 text-sm last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="tabular-nums">
        {before} → <span className="font-semibold">{after}</span>{" "}
        <span className={`text-xs ${TONE[delta.tone]}`}>{delta.text}</span>
      </span>
    </div>
  );
}

function PeriodMetrics({
  title,
  before,
  after,
}: {
  title: string;
  before: PeriodTotals;
  after: PeriodTotals;
}) {
  const pos = (value: number) => (value > 0 ? number.format(value) : "-");
  return (
    <div>
      <div className="mb-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        {title}
      </div>
      <Metric
        label="Clics"
        before={String(before.clicks)}
        after={String(after.clicks)}
        delta={volumeDelta(before.clicks, after.clicks)}
      />
      <Metric
        label="Impressions"
        before={String(before.impressions)}
        after={String(after.impressions)}
        delta={volumeDelta(before.impressions, after.impressions)}
      />
      <Metric
        label="Position moyenne"
        before={pos(before.position)}
        after={pos(after.position)}
        delta={positionDelta(before.position, after.position)}
      />
    </div>
  );
}

/**
 * Did the optimisation pay off? Search Console results of the page over the
 * same number of days before and after the "marked in production" date.
 */
export function ResultsCard({
  projectId,
  pageUrl,
  publishedAt,
  keyword,
}: {
  projectId: string;
  pageUrl: string;
  publishedAt: string;
  keyword: string;
}) {
  const query = useQuery({
    queryKey: [
      "semantic-after-publish",
      projectId,
      pageUrl,
      publishedAt,
      keyword.toLowerCase(),
    ],
    queryFn: () =>
      getSemanticAfterPublish({
        data: { projectId, pageUrl, publishedAt, keyword: keyword.trim() },
      }),
    staleTime: 10 * 60 * 1000,
  });
  const data = query.data;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Résultats depuis la mise en prod</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {query.isPending ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Lecture de Search
            Console…
          </p>
        ) : null}
        {query.isError ? (
          <p className="text-sm text-destructive">
            Impossible de lire Search Console pour le moment.
          </p>
        ) : null}
        {data && !data.connected ? (
          <p className="text-sm text-muted-foreground">
            Search Console n&apos;est pas connecté à ce projet.
          </p>
        ) : null}
        {data?.connected && data.status === "no_url" ? (
          <p className="text-sm text-muted-foreground">
            Renseignez l&apos;URL publiée de la page (champ « URL de la page »)
            pour suivre ses résultats.
          </p>
        ) : null}
        {data?.connected && data.status === "too_early" ? (
          <p className="text-sm text-muted-foreground">
            Trop tôt pour comparer : encore {data.daysLeft} jour
            {data.daysLeft > 1 ? "s" : ""} de données Search Console (elles
            arrivent avec 3 jours de décalage).
          </p>
        ) : null}
        {data?.connected && data.status === "ready" ? (
          <>
            <p className="text-xs text-muted-foreground">
              {data.windowDays} jours après la mise en prod, contre les{" "}
              {data.windowDays} jours précédents.
            </p>
            <PeriodMetrics
              title="Page"
              before={data.before}
              after={data.after}
            />
            {data.keywordBefore && data.keywordAfter ? (
              <PeriodMetrics
                title={`Mot-clé « ${keyword.trim()} » sur cette page`}
                before={data.keywordBefore}
                after={data.keywordAfter}
              />
            ) : null}
            {data.before.impressions + data.after.impressions === 0 ? (
              <p className="text-xs text-amber-500">
                Aucune donnée pour cette URL : vérifiez qu&apos;elle est écrite
                exactement comme dans Search Console (https, www, slash final).
              </p>
            ) : null}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}
