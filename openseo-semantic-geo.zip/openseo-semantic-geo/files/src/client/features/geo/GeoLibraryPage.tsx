import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Loader2, Sparkles } from "lucide-react";
import { PageHeader } from "@/client/components/PageHeader";
import { QueryError } from "@/client/components/QueryState";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { Badge } from "@/client/components/ui/badge";
import { Button } from "@/client/components/ui/button";
import { Card, CardContent } from "@/client/components/ui/card";
import { Input } from "@/client/components/ui/input";
import {
  Table,
  TableBody,
  TableCard,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/client/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/client/components/ui/tabs";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import {
  listSemanticDocuments,
  loadSemanticPage,
  saveSemanticDocument,
} from "@/serverFunctions/semantic";
import { GeoSiteChecklist } from "./GeoSiteChecklist";
import { TONE_COLOR, toneOfScore } from "./geoUi";

function formatDate(iso: string | null): string {
  if (!iso) return "-";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function GeoBadge({ score }: { score: number | null }) {
  if (score === null) return <span className="text-muted-foreground">-</span>;
  return (
    <span
      className="rounded-full px-2 py-0.5 text-xs font-semibold text-white"
      style={{ backgroundColor: TONE_COLOR[toneOfScore(score)] }}
    >
      {score} / 100
    </span>
  );
}

/** Starts a GEO analysis from a URL: imports the text, saves it, opens it. */
function NewAnalysis({ projectId }: { projectId: string }) {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [keyword, setKeyword] = useState("");
  const mutation = useMutation({
    mutationFn: async () => {
      const page = await loadSemanticPage({
        data: { projectId, url: url.trim() },
      });
      if (!page.ok) return page;
      const saved = await saveSemanticDocument({
        data: {
          projectId,
          title: page.title,
          keyword: keyword.trim(),
          titleTag: page.title,
          metaDescription: "",
          slug: "",
          pageUrl: url.trim(),
          contentHtml: page.html,
          score: null,
          brief: null,
        },
      });
      return { ok: true as const, id: saved.id };
    },
    onSuccess: (result) => {
      if (!result.ok) return;
      void navigate({
        to: "/p/$projectId/geo/$documentId",
        params: { projectId, documentId: result.id },
      });
    },
  });
  const failure =
    mutation.data && !mutation.data.ok
      ? mutation.data.message
      : mutation.isError
        ? getStandardErrorMessage(
            mutation.error,
            "Impossible d’analyser cette page.",
          )
        : null;

  return (
    <Card>
      <CardContent className="space-y-3">
        <div className="text-sm font-medium">Analyser une page en ligne</div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-0 flex-[2] basis-64">
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://exemple.fr/mon-article"
              aria-label="URL de la page"
            />
          </div>
          <div className="min-w-0 flex-1 basis-48">
            <Input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Mot-clé principal"
              aria-label="Mot-clé principal"
            />
          </div>
          <Button
            disabled={url.trim().length < 4 || mutation.isPending}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? (
              <Loader2 className="animate-spin" />
            ) : (
              <Sparkles />
            )}
            Analyser
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Le texte de la page est importé, puis évalué sur la checklist GEO.
          Vous pouvez aussi choisir un contenu déjà travaillé dans l’éditeur
          SEO.
        </p>
        {failure ? (
          <Alert variant="destructive">
            <AlertDescription>{failure}</AlertDescription>
          </Alert>
        ) : null}
      </CardContent>
    </Card>
  );
}

function ContentsTable({ projectId }: { projectId: string }) {
  const query = useQuery({
    queryKey: ["semantic-documents", projectId],
    queryFn: () => listSemanticDocuments({ data: { projectId } }),
  });
  if (query.isError) {
    return (
      <QueryError
        error={query.error}
        fallback="Impossible de charger les contenus."
        onRetry={() => void query.refetch()}
      />
    );
  }
  const documents = query.data ?? [];
  if (query.data && documents.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Aucun contenu pour l’instant : analysez une page en ligne ci-dessus ou
        créez un contenu dans l’éditeur SEO.
      </p>
    );
  }
  return (
    <TableCard>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Mot-clé cible</TableHead>
            <TableHead>Page</TableHead>
            <TableHead>Score GEO</TableHead>
            <TableHead>Dernière analyse</TableHead>
            <TableHead>Mise en prod</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {documents.map((doc) => (
            <TableRow key={doc.id}>
              <TableCell className="max-w-64">
                <Link
                  to="/p/$projectId/geo/$documentId"
                  params={{ projectId, documentId: doc.id }}
                  className="block truncate font-medium hover:underline"
                  title={doc.title}
                >
                  {doc.keyword || doc.title}
                </Link>
              </TableCell>
              <TableCell className="max-w-56 truncate text-muted-foreground">
                {doc.pageUrl || (doc.slug ? `/${doc.slug}` : "-")}
              </TableCell>
              <TableCell>
                <GeoBadge score={doc.geoScore} />
              </TableCell>
              <TableCell className="whitespace-nowrap">
                {formatDate(doc.geoAnalyzedAt)}
              </TableCell>
              <TableCell>
                {doc.publishedAt ? (
                  <Badge variant="success">{formatDate(doc.publishedAt)}</Badge>
                ) : (
                  <span className="text-muted-foreground">Brouillon</span>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableCard>
  );
}

export function GeoLibraryPage({ projectId }: { projectId: string }) {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Optimisation GEO"
        description="Rendez vos contenus citables par ChatGPT, Perplexity, Gemini et les AI Overviews : checklist, score et diagnostic."
      />
      <Tabs defaultValue="pages">
        <TabsList>
          <TabsTrigger value="pages">Pages</TabsTrigger>
          <TabsTrigger value="site">Site : sources et mesure</TabsTrigger>
        </TabsList>
        <TabsContent value="pages" className="mt-4 space-y-4">
          <NewAnalysis projectId={projectId} />
          <ContentsTable projectId={projectId} />
        </TabsContent>
        <TabsContent value="site" className="mt-4">
          <GeoSiteChecklist projectId={projectId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
