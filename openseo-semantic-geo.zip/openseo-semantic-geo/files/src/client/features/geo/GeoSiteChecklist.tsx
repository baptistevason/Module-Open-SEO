import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { QueryError } from "@/client/components/QueryState";
import { getGeoSiteState, setGeoSiteCheck } from "@/serverFunctions/semantic";
import { evaluateSite, scoreResults } from "@/shared/geo/evaluate";
import { GeoBlocks } from "./GeoBlocks";
import { GeoKpiGuide } from "./GeoKpiGuide";
import { GeoScoreCard } from "./GeoScoreCard";

/**
 * Site-level GEO checklist: architecture, external sources, measurement. What
 * OpenSEO already knows (Search Console, Google Analytics, Prompt Tracking)
 * fills in automatically; the rest is ticked by hand and kept per project.
 */
export function GeoSiteChecklist({ projectId }: { projectId: string }) {
  const queryClient = useQueryClient();
  const queryKey = ["geo-site", projectId];
  const query = useQuery({
    queryKey,
    queryFn: () => getGeoSiteState({ data: { projectId } }),
  });
  const mutation = useMutation({
    mutationFn: (input: { checkId: string; done: boolean }) =>
      setGeoSiteCheck({ data: { projectId, ...input } }),
    onMutate: async (input) => {
      await queryClient.cancelQueries({ queryKey });
      const previous = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(
        queryKey,
        (current: typeof query.data | undefined) =>
          current
            ? {
                ...current,
                checks: { ...current.checks, [input.checkId]: input.done },
              }
            : current,
      );
      return { previous };
    },
    onError: (_error, _input, context) => {
      if (context?.previous)
        queryClient.setQueryData(queryKey, context.previous);
    },
    onSettled: () => void queryClient.invalidateQueries({ queryKey }),
  });

  const data = query.data;
  const results = useMemo(
    () => (data ? evaluateSite(data.facts, data.checks) : []),
    [data],
  );
  const score = useMemo(() => scoreResults(results), [results]);

  if (query.isError) {
    return (
      <QueryError
        error={query.error}
        fallback="Impossible de charger la checklist du site."
        onRetry={() => void query.refetch()}
      />
    );
  }
  if (!data) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Chargement…
      </p>
    );
  }

  return (
    <div className="space-y-4">
      <GeoScoreCard score={score} heading="Score GEO du site" />
      <GeoBlocks
        projectId={projectId}
        scope="site"
        results={results}
        blockScores={score.blocks}
        manual={data.checks}
        onTick={(checkId, done) => mutation.mutate({ checkId, done })}
      />
      <GeoKpiGuide />
    </div>
  );
}
