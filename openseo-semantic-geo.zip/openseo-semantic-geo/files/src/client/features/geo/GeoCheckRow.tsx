import { Badge } from "@/client/components/ui/badge";
import { Checkbox } from "@/client/components/ui/checkbox";
import type { GeoCheckDef, GeoCheckResult } from "@/shared/geo/types";
import { STATUS_STYLE, ToolLink } from "./geoUi";

const SOURCE_LABEL: Record<GeoCheckResult["source"], string> = {
  auto: "automatique",
  live: "page publiée",
  llm: "analyse IA",
  manual: "à la main",
};

/** One control of the checklist: status, detail, hand tick, helper link. */
export function GeoCheckRow({
  projectId,
  def,
  result,
  ticked,
  onTick,
}: {
  projectId: string;
  def: GeoCheckDef;
  result: GeoCheckResult;
  ticked: boolean;
  onTick: (done: boolean) => void;
}) {
  const style = STATUS_STYLE[result.status];
  const Icon = style.icon;
  // An automatic "ok" needs no tick; everything else can be validated by hand.
  const showTick = result.status !== "ok" || ticked;

  return (
    <li className="flex gap-3 border-b py-3 last:border-0">
      <Icon
        className={`mt-0.5 size-5 shrink-0 ${style.color}`}
        aria-label={style.label}
      />
      <div className="min-w-0 flex-1 space-y-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="text-sm font-medium">{def.label}</span>
          {def.ref ? (
            <Badge variant="outline" title="Numéro dans la checklist GEO">
              #{def.ref}
            </Badge>
          ) : null}
          {def.priority ? (
            <Badge variant="destructive">Prioritaire</Badge>
          ) : null}
        </div>
        <p className="text-xs text-muted-foreground">{result.detail}</p>
        <p className="text-xs italic text-muted-foreground/80">{def.why}</p>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
            {SOURCE_LABEL[result.source]}
          </span>
          {def.tool ? <ToolLink projectId={projectId} tool={def.tool} /> : null}
        </div>
      </div>
      {showTick ? (
        <label className="flex shrink-0 cursor-pointer items-start gap-1.5 text-xs text-muted-foreground">
          <Checkbox
            checked={ticked}
            onCheckedChange={(value) => onTick(value)}
            aria-label={`Valider à la main : ${def.label}`}
          />
          Validé
        </label>
      ) : null}
    </li>
  );
}
