import { Link } from "@tanstack/react-router";
import { CircleAlert, CircleCheck, CircleDashed, CircleX } from "lucide-react";
import type { GeoTone } from "@/shared/geo/evaluate";
import type { GeoCheckDef, GeoStatus } from "@/shared/geo/types";

// One palette for the GEO module: green = good, orange = to reinforce,
// red = to rework. Same colours as the lexical-field score.
export const TONE_COLOR: Record<GeoTone, string> = {
  good: "#22c55e",
  mid: "#f97316",
  bad: "#ef4444",
};

export const STATUS_STYLE: Record<
  GeoStatus,
  { icon: typeof CircleCheck; color: string; label: string }
> = {
  ok: { icon: CircleCheck, color: "text-success", label: "Conforme" },
  warn: { icon: CircleAlert, color: "text-amber-500", label: "À améliorer" },
  fail: { icon: CircleX, color: "text-destructive", label: "Manquant" },
  todo: {
    icon: CircleDashed,
    color: "text-muted-foreground",
    label: "À valider",
  },
};

export function toneOfScore(score: number): GeoTone {
  if (score >= 80) return "good";
  return score >= 55 ? "mid" : "bad";
}

/** Link to another OpenSEO page that helps with a control. */
export function ToolLink({
  projectId,
  tool,
}: {
  projectId: string;
  tool: NonNullable<GeoCheckDef["tool"]>;
}) {
  const className = "text-xs text-primary hover:underline";
  switch (tool.path) {
    case "ai-visibility":
      return (
        <Link
          to="/p/$projectId/ai-visibility"
          params={{ projectId }}
          className={className}
        >
          {tool.label}
        </Link>
      );
    case "backlinks":
      return (
        <Link
          to="/p/$projectId/backlinks"
          params={{ projectId }}
          className={className}
        >
          {tool.label}
        </Link>
      );
    case "audit":
      return (
        <Link
          to="/p/$projectId/audit"
          params={{ projectId }}
          className={className}
        >
          {tool.label}
        </Link>
      );
    case "search-performance":
      return (
        <Link
          to="/p/$projectId/search-performance"
          params={{ projectId }}
          className={className}
        >
          {tool.label}
        </Link>
      );
    case "semantic":
      return (
        <Link
          to="/p/$projectId/semantic"
          params={{ projectId }}
          className={className}
        >
          {tool.label}
        </Link>
      );
  }
}
