import { Badge } from "@/client/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import type { EeatAxis, GeoLlmAnalysis } from "@/shared/geo/types";
import { TONE_COLOR, toneOfScore } from "./geoUi";

const AXES: { key: EeatAxis; label: string }[] = [
  { key: "experience", label: "Expérience" },
  { key: "expertise", label: "Expertise" },
  { key: "authority", label: "Autorité" },
  { key: "trust", label: "Confiance" },
];

/** E-E-A-T diagnostic and prioritised recommendations from the LLM analysis. */
export function GeoLlmCards({ analysis }: { analysis: GeoLlmAnalysis }) {
  const recommendations = [...analysis.recommendations];
  recommendations.sort((a, b) => a.priority - b.priority);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Diagnostic E-E-A-T</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {analysis.summary ? (
            <p className="text-sm text-muted-foreground">{analysis.summary}</p>
          ) : null}
          {AXES.map(({ key, label }) => {
            const axis = analysis.eeat[key];
            const percent = Math.round((axis.score / 5) * 100);
            return (
              <div key={key} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{label}</span>
                  <span className="tabular-nums text-muted-foreground">
                    {axis.score} / 5
                  </span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${percent}%`,
                      backgroundColor: TONE_COLOR[toneOfScore(percent)],
                    }}
                  />
                </div>
                {axis.evidence ? (
                  <p className="text-xs text-muted-foreground">
                    {axis.evidence}
                  </p>
                ) : null}
                {axis.advice ? <p className="text-xs">{axis.advice}</p> : null}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {recommendations.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Recommandations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5">
              {recommendations.map((item) => (
                <li key={item.text} className="flex gap-2 text-sm">
                  <Badge
                    variant={item.priority === 1 ? "destructive" : "outline"}
                    className="mt-0.5 shrink-0"
                  >
                    P{item.priority}
                  </Badge>
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}
    </>
  );
}
