import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";

const LEVELS: { title: string; items: string[] }[] = [
  {
    title: "1. Présence",
    items: [
      "Taux de citation = réponses citant la marque ÷ requêtes testées × 100. Aucun seuil universel : suivez la tendance et l’écart avec vos concurrents sur les mêmes requêtes.",
      "Mentions sans lien : elles construisent l’association entre la marque et le sujet, même sans visite mesurable.",
    ],
  },
  {
    title: "2. Poids",
    items: [
      "Part de voix : vos mentions rapportées à celles de tout le marché sur les mêmes requêtes.",
      "Position dans la réponse : première phrase, corps du texte ou source en bas de réponse.",
      "Sentiment et exactitude : tonalité des mentions et erreurs factuelles à corriger à la source.",
    ],
  },
  {
    title: "3. Conséquence",
    items: [
      "Trafic référent IA, dans Google Analytics : chatgpt.com, perplexity.ai, gemini.google.com. Peu de volume, mais des visiteurs plus avancés dans leur décision.",
      "Requêtes de marque dans Search Console : un utilisateur convaincu par une réponse vous cherche ensuite par votre nom.",
    ],
  },
];

const METHOD = [
  "Interrogez un même prompt au moins 15 fois (environ 30 pour les carrousels produits) : une même requête donne des réponses différentes d’un moment à l’autre.",
  "Testez en environnement neutre, jamais depuis un compte à historique.",
  "Dix requêtes donnent une tendance, une centaine donne une statistique.",
  "Mesurez au minimum chaque mois, chaque semaine sur les marchés très disputés.",
];

/** Reading guide for the measurement controls (36 to 40). */
export function GeoKpiGuide() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Guide des KPI GEO</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        <div className="grid gap-4 md:grid-cols-3">
          {LEVELS.map((level) => (
            <div key={level.title} className="space-y-1.5">
              <div className="font-medium">{level.title}</div>
              <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                {level.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="space-y-1.5">
          <div className="font-medium">Méthode de mesure fiable</div>
          <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
            {METHOD.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
