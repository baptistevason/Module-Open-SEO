import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/client/components/ui/card";
import { GEO_BLOCKS, GEO_CHECK_BY_ID } from "@/shared/geo/catalog";
import type { GeoBlockScore } from "@/shared/geo/evaluate";
import type { GeoBlockId, GeoCheckResult, GeoScope } from "@/shared/geo/types";
import { GeoCheckRow } from "./GeoCheckRow";
import { TONE_COLOR, toneOfScore } from "./geoUi";

/** The checklist grouped by block, each block with its own mini score. */
export function GeoBlocks({
  projectId,
  scope,
  results,
  blockScores,
  manual,
  onTick,
}: {
  projectId: string;
  scope: GeoScope;
  results: GeoCheckResult[];
  blockScores: GeoBlockScore[];
  manual: Record<string, boolean>;
  onTick: (id: string, done: boolean) => void;
}) {
  const byBlock = new Map<GeoBlockId, GeoCheckResult[]>();
  for (const result of results) {
    const block = GEO_CHECK_BY_ID.get(result.id)?.block;
    if (!block) continue;
    byBlock.set(block, [...(byBlock.get(block) ?? []), result]);
  }
  const scores = new Map(blockScores.map((b) => [b.id, b]));

  return (
    <div className="space-y-4">
      {GEO_BLOCKS.filter((b) => b.scope === scope).map((block) => {
        const blockResults = byBlock.get(block.id) ?? [];
        const score = scores.get(block.id);
        return (
          <Card key={block.id}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between gap-3">
                <span>{block.label}</span>
                {score ? (
                  <span
                    className="text-sm font-semibold tabular-nums"
                    style={{ color: TONE_COLOR[toneOfScore(score.score)] }}
                  >
                    {score.score} / 100
                    <span className="ml-2 text-xs font-normal text-muted-foreground">
                      {score.done} / {score.total} conformes
                    </span>
                  </span>
                ) : null}
              </CardTitle>
              <p className="text-xs text-muted-foreground">{block.intro}</p>
            </CardHeader>
            <CardContent>
              <ul>
                {blockResults.map((result) => {
                  const def = GEO_CHECK_BY_ID.get(result.id);
                  if (!def) return null;
                  return (
                    <GeoCheckRow
                      key={result.id}
                      projectId={projectId}
                      def={def}
                      result={result}
                      ticked={Boolean(manual[result.id])}
                      onTick={(done) => onTick(result.id, done)}
                    />
                  );
                })}
              </ul>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
