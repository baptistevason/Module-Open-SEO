import { Card, CardContent } from "@/client/components/ui/card";
import type { GeoScore } from "@/shared/geo/evaluate";
import { GEO_TARGET_SCORE } from "@/shared/geo/evaluate";
import { TONE_COLOR, toneOfScore } from "./geoUi";
import { ScoreRing } from "./ScoreRing";

/** Ring with the 0-100 score, its verdict, and one bar per block. */
export function GeoScoreCard({
  score,
  heading,
}: {
  score: GeoScore;
  heading: string;
}) {
  const color = TONE_COLOR[score.tone];

  return (
    <Card>
      <CardContent className="space-y-5">
        <div className="flex flex-wrap items-center gap-6">
          <ScoreRing score={score.score} color={color} />
          <div className="min-w-0 flex-1 space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {heading}
            </div>
            <span
              className="inline-block rounded-full px-3 py-1 text-sm font-semibold text-white"
              style={{ backgroundColor: color }}
            >
              {score.label}
            </span>
            <p className="text-xs text-muted-foreground">
              Objectif : {GEO_TARGET_SCORE} ou plus. {score.counts.ok}{" "}
              conformes, {score.counts.warn} à améliorer, {score.counts.fail}{" "}
              manquants, {score.counts.todo} à valider.
            </p>
          </div>
        </div>

        <ul className="grid gap-x-8 gap-y-2 sm:grid-cols-2">
          {score.blocks.map((block) => (
            <li key={block.id}>
              <div className="flex justify-between text-xs">
                <span>{block.label}</span>
                <span className="tabular-nums text-muted-foreground">
                  {block.score}
                </span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${block.score}%`,
                    backgroundColor: TONE_COLOR[toneOfScore(block.score)],
                  }}
                />
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
