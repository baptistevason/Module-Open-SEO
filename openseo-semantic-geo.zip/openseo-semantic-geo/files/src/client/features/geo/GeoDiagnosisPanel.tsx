import { ArrowRight, CircleAlert, CircleCheck, CircleX } from "lucide-react";
import { Badge } from "@/client/components/ui/badge";
import { Card, CardContent } from "@/client/components/ui/card";
import type { Diagnosis, DiagnosisItem } from "@/shared/geo/diagnosis";
import { TONE_COLOR, toneOfScore } from "./geoUi";
import { ScoreRing } from "./ScoreRing";

const VERDICT: Record<ReturnType<typeof toneOfScore>, string> = {
  good: "Prêt pour les IA et le SEO",
  mid: "Correct, à renforcer",
  bad: "À retravailler",
};

const SOURCE_LABEL: Record<DiagnosisItem["source"], string> = {
  seo: "SEO",
  geo: "GEO",
  ia: "IA",
};

function MiniScore({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex-1">
      <div className="flex justify-between text-xs">
        <span>{label}</span>
        <span className="tabular-nums text-muted-foreground">{value}</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full"
          style={{
            width: `${value}%`,
            backgroundColor: TONE_COLOR[toneOfScore(value)],
          }}
        />
      </div>
    </div>
  );
}

function Strength({ item }: { item: DiagnosisItem }) {
  return (
    <li className="flex gap-2 text-sm">
      <CircleCheck
        className="mt-0.5 size-4 shrink-0 text-success"
        aria-hidden
      />
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-1.5">
          <span>{item.label}</span>
          <Badge variant="outline">{SOURCE_LABEL[item.source]}</Badge>
        </div>
        {item.detail ? (
          <p className="text-xs text-muted-foreground">{item.detail}</p>
        ) : null}
      </div>
    </li>
  );
}

function Weakness({ item }: { item: DiagnosisItem }) {
  const Icon = item.severity === "fail" ? CircleX : CircleAlert;
  const color =
    item.severity === "fail" ? "text-destructive" : "text-amber-500";
  return (
    <li className="flex gap-2 text-sm">
      <Icon className={`mt-0.5 size-4 shrink-0 ${color}`} aria-hidden />
      <div className="min-w-0 space-y-0.5">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="font-medium">{item.label}</span>
          <Badge variant="outline">{SOURCE_LABEL[item.source]}</Badge>
        </div>
        {item.detail ? (
          <p className="text-xs text-muted-foreground">{item.detail}</p>
        ) : null}
        <p className="flex gap-1 text-xs">
          <ArrowRight className="mt-0.5 size-3 shrink-0" aria-hidden />
          <span>{item.fix}</span>
        </p>
      </div>
    </li>
  );
}

/**
 * The diagnosis beside the editor: one global score (SEO and GEO together),
 * what the content does well, what to fix first and how.
 */
export function GeoDiagnosisPanel({
  seoScore,
  geoScore,
  diagnosis,
  pendingLlm,
}: {
  seoScore: number;
  geoScore: number;
  diagnosis: Diagnosis;
  /** Judgement controls waiting for the AI analysis. */
  pendingLlm: number;
}) {
  const global = Math.round((seoScore + geoScore) / 2);
  const tone = toneOfScore(global);
  const color = TONE_COLOR[tone];

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-5">
            <ScoreRing score={global} color={color} size={112} />
            <div className="min-w-0 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Score global
              </div>
              <span
                className="inline-block rounded-full px-3 py-1 text-sm font-semibold text-white"
                style={{ backgroundColor: color }}
              >
                {VERDICT[tone]}
              </span>
            </div>
          </div>
          <div className="flex gap-4">
            <MiniScore label="SEO" value={seoScore} />
            <MiniScore label="GEO" value={geoScore} />
          </div>
          {pendingLlm > 0 ? (
            <p className="text-xs text-amber-500">
              {pendingLlm} contrôle{pendingLlm > 1 ? "s" : ""} de jugement
              attend{pendingLlm > 1 ? "ent" : ""} l’analyse IA : lancez-la pour
              compléter le score.
            </p>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3">
          <h2 className="text-sm font-semibold text-success">
            Points forts de l’article
          </h2>
          {diagnosis.strengths.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Aucun point fort net pour l’instant : commencez par les points
              faibles ci-dessous.
            </p>
          ) : (
            <ul className="space-y-2.5">
              {diagnosis.strengths.map((item) => (
                <Strength key={item.id} item={item} />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3">
          <h2 className="text-sm font-semibold text-destructive">
            Points faibles de l’article
          </h2>
          {diagnosis.weaknesses.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Aucun point faible détecté. Terminez la checklist détaillée pour
              valider les derniers contrôles.
            </p>
          ) : (
            <ul className="space-y-3.5">
              {diagnosis.weaknesses.map((item) => (
                <Weakness key={item.id} item={item} />
              ))}
            </ul>
          )}
          {diagnosis.pending > 0 ? (
            <p className="text-xs text-muted-foreground">
              {diagnosis.pending} autre{diagnosis.pending > 1 ? "s" : ""}{" "}
              contrôle{diagnosis.pending > 1 ? "s" : ""} à valider dans la
              checklist détaillée (page publiée, analyse IA ou à la main).
            </p>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
