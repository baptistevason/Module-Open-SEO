import {
  useDeferredValue,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Bot, Globe, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/client/components/ui/alert";
import { Button } from "@/client/components/ui/button";
import { Input } from "@/client/components/ui/input";
import { BackLink, PageHeader } from "@/client/components/PageHeader";
import { QueryError } from "@/client/components/QueryState";
import { MarketPicker } from "@/client/features/semantic/MarketPicker";
import { useDocumentMarket } from "@/client/features/semantic/useDocumentMarket";
import { RichEditor } from "@/client/features/semantic/RichEditor";
import { getStandardErrorMessage } from "@/client/lib/error-messages";
import {
  analyzeGeoWithLlm,
  getSemanticDocument,
  probeGeoPage,
  saveGeoDocumentState,
  saveSemanticDocument,
} from "@/serverFunctions/semantic";
import { GEO_CHECK_BY_ID } from "@/shared/geo/catalog";
import { buildDiagnosis } from "@/shared/geo/diagnosis";
import { evaluatePage, scoreResults } from "@/shared/geo/evaluate";
import {
  parseStoredChecks,
  parseStoredLive,
  parseStoredLlm,
} from "@/shared/geo/stored";
import type { GeoLiveFacts, GeoLlmAnalysis } from "@/shared/geo/types";
import {
  analyzeDraft,
  compareWithBrief,
  scoreDraft,
} from "@/shared/semantic/analyze";
import { parseStoredBrief } from "@/shared/semantic/brief-schema";
import type { SemanticDocument } from "@/types/schemas/semantic-documents";
import { GeoBlocks } from "./GeoBlocks";
import { GeoDiagnosisPanel } from "./GeoDiagnosisPanel";
import { GeoLlmCards } from "./GeoLlmCards";

const AUTOSAVE_MS = 1200;
const CONTENT_AUTOSAVE_MS = 1500;
const noop = () => undefined;

export function GeoWorkspacePage({
  projectId,
  documentId,
}: {
  projectId: string;
  documentId: string;
}) {
  const query = useQuery({
    queryKey: ["semantic-document", projectId, documentId],
    queryFn: () => getSemanticDocument({ data: { projectId, id: documentId } }),
    // The workspace owns the state after loading.
    staleTime: Number.POSITIVE_INFINITY,
    gcTime: 0,
  });
  if (query.isError) {
    return (
      <QueryError
        error={query.error}
        fallback="Impossible de charger ce contenu."
        onRetry={() => void query.refetch()}
      />
    );
  }
  if (!query.data) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Chargement…
      </p>
    );
  }
  return <GeoWorkspace projectId={projectId} doc={query.data} />;
}

function Collapsible({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <details className="rounded-xl border bg-card">
      <summary className="cursor-pointer px-4 py-3 text-sm font-medium">
        {title}
      </summary>
      <div className="space-y-4 p-4 pt-0">{children}</div>
    </details>
  );
}

function failureOf(
  data: { ok: boolean; message?: string } | undefined,
  error: unknown,
  fallback: string,
): string | null {
  if (data && !data.ok) return data.message ?? fallback;
  if (error) return getStandardErrorMessage(error, fallback);
  return null;
}

function GeoWorkspace({
  projectId,
  doc,
}: {
  projectId: string;
  doc: SemanticDocument;
}) {
  const queryClient = useQueryClient();
  const [html, setHtml] = useState(doc.contentHtml);
  const [manual, setManual] = useState(() => parseStoredChecks(doc.geoChecks));
  const [live, setLive] = useState<GeoLiveFacts | null>(() =>
    parseStoredLive(doc.geoLive),
  );
  const [llm, setLlm] = useState<GeoLlmAnalysis | null>(() =>
    parseStoredLlm(doc.geoLlm),
  );
  const [url, setUrl] = useState(live?.url ?? doc.pageUrl);
  const [now] = useState(() => Date.now());
  const initialHtml = useRef(doc.contentHtml);
  const brief = useMemo(() => parseStoredBrief(doc.brief), [doc.brief]);
  const [market, setMarket] = useDocumentMarket(projectId, doc, brief);
  const languageCode = market.languageCode;

  // The diagnosis follows the text as it is typed.
  const deferredHtml = useDeferredValue(html);
  const pageUrl = live?.url ?? url;
  const analysis = useMemo(
    () =>
      analyzeDraft({
        title: doc.title,
        meta: doc.metaDescription,
        slug: doc.slug,
        html: deferredHtml,
        keyword: doc.keyword,
        languageCode,
      }),
    [doc, deferredHtml, languageCode],
  );
  const comparison = useMemo(
    () => (brief ? compareWithBrief(analysis, brief) : null),
    [analysis, brief],
  );
  const seo = useMemo(
    () => scoreDraft(analysis, brief, comparison),
    [analysis, brief, comparison],
  );
  const results = useMemo(
    () =>
      evaluatePage(
        {
          html: deferredHtml,
          title: doc.title,
          meta: doc.metaDescription,
          slug: doc.slug,
          keyword: doc.keyword,
          pageUrl,
          languageCode,
          publishedAt: doc.publishedAt,
          updatedAt: doc.updatedAt,
          live,
          now,
        },
        llm?.checks ?? null,
        manual,
      ),
    [doc, deferredHtml, pageUrl, languageCode, live, llm, manual, now],
  );
  const geo = useMemo(() => scoreResults(results), [results]);
  const diagnosis = useMemo(
    () => buildDiagnosis({ geoResults: results, seoParts: seo.parts, llm }),
    [results, seo.parts, llm],
  );
  // Judgement controls the AI analysis has not looked at yet.
  const pendingLlm = llm
    ? 0
    : results.filter(
        (r) => r.status === "todo" && GEO_CHECK_BY_ID.get(r.id)?.mode === "llm",
      ).length;

  const markStale = () =>
    void queryClient.invalidateQueries({
      queryKey: ["semantic-document", projectId],
      refetchType: "none",
    });

  const geoSave = useMutation({
    mutationFn: () =>
      saveGeoDocumentState({
        data: {
          projectId,
          id: doc.id,
          checks: manual,
          live: live ? JSON.stringify(live) : null,
          llm: llm ? JSON.stringify(llm) : null,
          score: geo.score,
          // One note only: the score out of 100.
          llmScore: null,
        },
      }),
    onSuccess: () => {
      markStale();
      void queryClient.invalidateQueries({
        queryKey: ["semantic-documents", projectId],
      });
    },
  });
  const contentSave = useMutation({
    mutationFn: () =>
      saveSemanticDocument({
        data: {
          projectId,
          id: doc.id,
          title: doc.title,
          keyword: doc.keyword,
          titleTag: doc.titleTag,
          metaDescription: doc.metaDescription,
          slug: doc.slug,
          pageUrl: live?.url ?? doc.pageUrl,
          contentHtml: html,
          score: seo.score,
          brief: doc.brief,
          locationCode: market.locationCode,
          languageCode: market.languageCode,
        },
      }),
    onSuccess: () => {
      markStale();
      void queryClient.invalidateQueries({
        queryKey: ["semantic-documents", projectId],
      });
    },
  });

  // Save a moment after any change, never on the first render.
  const firstGeo = useRef(true);
  const saveGeo = geoSave.mutate;
  useEffect(() => {
    if (firstGeo.current) {
      firstGeo.current = false;
      return;
    }
    const timer = window.setTimeout(() => saveGeo(), AUTOSAVE_MS);
    return () => window.clearTimeout(timer);
  }, [manual, live, llm, saveGeo]);
  const firstContent = useRef(true);
  const saveContent = contentSave.mutate;
  useEffect(() => {
    if (firstContent.current) {
      firstContent.current = false;
      return;
    }
    const timer = window.setTimeout(() => saveContent(), CONTENT_AUTOSAVE_MS);
    return () => window.clearTimeout(timer);
  }, [html, market.locationCode, market.languageCode, saveContent]);

  const probe = useMutation({
    mutationFn: () => probeGeoPage({ data: { projectId, url: url.trim() } }),
    onSuccess: (result) => {
      if (result.ok) setLive(result.facts);
    },
  });
  const llmRun = useMutation({
    mutationFn: () =>
      analyzeGeoWithLlm({
        data: {
          projectId,
          html,
          title: doc.title,
          keyword: doc.keyword,
          locationCode: market.locationCode,
          languageCode: market.languageCode,
        },
      }),
    onSuccess: (result) => {
      if (result.ok) setLlm(result.analysis);
    },
  });

  const probeFailure = failureOf(
    probe.data,
    probe.error,
    "Lecture de la page impossible.",
  );
  const llmFailure = failureOf(
    llmRun.data,
    llmRun.error,
    "L’analyse a échoué.",
  );
  const saving = geoSave.isPending || contentSave.isPending;

  return (
    <div className="space-y-5">
      <PageHeader
        backLink={
          <BackLink to="/p/$projectId/geo" params={{ projectId }}>
            Optimisation GEO
          </BackLink>
        }
        title={doc.keyword || doc.title}
        description={
          saving
            ? "Enregistrement…"
            : `${doc.title} · enregistré automatiquement`
        }
        actions={
          <Button
            variant="outline"
            nativeButton={false}
            render={
              <Link
                to="/p/$projectId/semantic/$documentId"
                params={{ projectId, documentId: doc.id }}
              />
            }
          >
            Ouvrir dans l’éditeur SEO
          </Button>
        }
      />

      <div className="rounded-xl border bg-card p-3">
        <MarketPicker market={market} onChange={setMarket} />
        <p className="mt-2 text-xs text-muted-foreground">
          Pays et langue du public visé : ils servent à lire le texte (phrases,
          questions) et à cadrer l’analyse IA.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-xl border bg-card p-3">
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="URL de la page publiée : https://exemple.fr/mon-article"
          aria-label="URL de la page publiée"
          className="min-w-64 flex-1"
        />
        <Button
          variant="outline"
          disabled={url.trim().length < 4 || probe.isPending}
          onClick={() => probe.mutate()}
          title="Lit le title, la méta, le schema, les balises de partage et les images en ligne"
        >
          {probe.isPending ? <Loader2 className="animate-spin" /> : <Globe />}
          Analyser la page publiée
        </Button>
        <Button
          disabled={llmRun.isPending}
          onClick={() => llmRun.mutate()}
          title="Juge l’expérience, l’expertise, l’originalité et la clarté du texte (environ une minute)"
        >
          {llmRun.isPending ? <Loader2 className="animate-spin" /> : <Bot />}
          Analyse IA
        </Button>
      </div>
      {probeFailure ? (
        <Alert variant="destructive">
          <AlertDescription>{probeFailure}</AlertDescription>
        </Alert>
      ) : null}
      {llmFailure ? (
        <Alert variant="destructive">
          <AlertDescription>{llmFailure}</AlertDescription>
        </Alert>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_26rem]">
        <div className="min-w-0 space-y-4">
          <RichEditor
            initialHtml={initialHtml.current}
            onChange={setHtml}
            onReady={noop}
          />
          <Collapsible title="Checklist GEO détaillée">
            <GeoBlocks
              projectId={projectId}
              scope="page"
              results={results}
              blockScores={geo.blocks}
              manual={manual}
              onTick={(id, done) =>
                setManual((current) => ({ ...current, [id]: done }))
              }
            />
          </Collapsible>
          {llm ? (
            <Collapsible title="Analyse IA : E-E-A-T et recommandations">
              <GeoLlmCards analysis={llm} />
            </Collapsible>
          ) : null}
        </div>

        <div className="min-w-0 xl:sticky xl:top-4 xl:self-start">
          <GeoDiagnosisPanel
            seoScore={seo.score}
            geoScore={geo.score}
            diagnosis={diagnosis}
            pendingLlm={pendingLlm}
          />
        </div>
      </div>
    </div>
  );
}
