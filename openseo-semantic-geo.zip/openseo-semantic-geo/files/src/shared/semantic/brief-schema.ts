import { z } from "zod";
import { BRIEF_METRIC_KEYS, type SemanticBrief } from "./types";

const termSchema = z.object({
  term: z.string(),
  kind: z.enum(["word", "bigram", "trigram"]),
  pages: z.number(),
  avgCount: z.number(),
  q1: z.number(),
  median: z.number(),
  q3: z.number(),
  max: z.number(),
});

const metricsSchema = z.object(
  Object.fromEntries(BRIEF_METRIC_KEYS.map((key) => [key, z.number()])),
);

const pageSchema = z.object({
  rank: z.number(),
  url: z.string(),
  domain: z.string(),
  title: z.string(),
  words: z.number(),
  h2Count: z.number(),
  h3Count: z.number(),
  imageCount: z.number(),
  h2: z.array(z.string()),
  metrics: metricsSchema.optional(),
  score: z.number().optional(),
});

const targetSchema = z.object({
  min: z.number(),
  q1: z.number(),
  median: z.number(),
  q3: z.number(),
  max: z.number(),
  pagesWith: z.number(),
});

const targetsSchema = z.object({
  metrics: z.object(
    Object.fromEntries(BRIEF_METRIC_KEYS.map((key) => [key, targetSchema])),
  ),
  wordsPerSection: z.number().nullable(),
  outliers: z.number(),
});

export const semanticBriefSchema = z.object({
  keyword: z.string(),
  languageCode: z.string(),
  locationCode: z.number(),
  fetchedAt: z.string(),
  pagesRead: z.number(),
  pagesRequested: z.number(),
  pages: z.array(pageSchema),
  medianWords: z.number().nullable(),
  avgH2: z.number().nullable(),
  avgH3: z.number().nullable(),
  avgImages: z.number().nullable(),
  terms: z.array(termSchema),
  targets: targetsSchema.optional(),
  readability: z
    .object({
      flesch: z.number(),
      avgSentence: z.number(),
      longSentenceShare: z.number(),
      passiveShare: z.number(),
    })
    .optional(),
  scoreTarget: z
    .object({
      median: z.number(),
      min: z.number(),
      max: z.number(),
      scores: z.array(
        z.object({ rank: z.number(), domain: z.string(), score: z.number() }),
      ),
    })
    .optional(),
});

/**
 * A brief read back from storage or a cache. Anything that does not match the
 * current shape (an older version, a corrupted value) is dropped, so callers
 * simply analyse the SERP again.
 */
export function parseBriefValue(value: unknown): SemanticBrief | null {
  const parsed = semanticBriefSchema.safeParse(value);
  return parsed.success ? parsed.data : null;
}

export function parseStoredBrief(
  raw: string | null | undefined,
): SemanticBrief | null {
  if (!raw) return null;
  try {
    return parseBriefValue(JSON.parse(raw));
  } catch {
    return null;
  }
}
