import { describe, expect, it } from "vitest";
import {
  analyzeDraft,
  compareWithBrief,
  scoreDraft,
  uncoveredSubtopics,
} from "./analyze";
import { parseHtmlDraft } from "./html";
import { reviewStyle } from "./style-review";
import { countNgrams, stopwordsFor, tokenize } from "./text";
import type { SemanticBrief } from "./types";

const HTML = [
  "<h1>Collier de dressage pour chien</h1>",
  "<p>Le collier de dressage aide à éduquer votre chien en douceur.</p>",
  "<h2>Choisir son collier</h2>",
  "<p>Un collier de dressage doit rester confortable pour le chien.</p>",
  "<h2>Les erreurs à éviter</h2>",
  "<ul><li><p>serrer trop fort</p></li><li><p>oublier la laisse</p></li></ul>",
].join("");

const BRIEF: SemanticBrief = {
  keyword: "collier de dressage pour chien",
  languageCode: "fr",
  locationCode: 2250,
  fetchedAt: "2026-10-20T00:00:00.000Z",
  pagesRead: 3,
  pagesRequested: 3,
  pages: [
    {
      rank: 1,
      url: "https://a.fr/x",
      domain: "a.fr",
      title: "A",
      words: 1000,
      h2Count: 5,
      h3Count: 2,
      imageCount: 4,
      h2: ["Récompenser le comportement positif", "Choisir son collier"],
    },
  ],
  medianWords: 1000,
  avgH2: 5,
  avgH3: 2,
  avgImages: 4,
  terms: [
    {
      term: "collier",
      kind: "word",
      pages: 3,
      avgCount: 9,
      q1: 6,
      median: 9,
      q3: 11,
      max: 12,
    },
    {
      term: "récompenses",
      kind: "word",
      pages: 3,
      avgCount: 4,
      q1: 2,
      median: 4,
      q3: 5,
      max: 6,
    },
    {
      term: "laisse",
      kind: "word",
      pages: 2,
      avgCount: 3,
      q1: 1,
      median: 3,
      q3: 4,
      max: 5,
    },
  ],
};

describe("tokenize", () => {
  it("splits apostrophes and keeps accents", () => {
    expect(tokenize("L'éducation canine")).toEqual([
      "l",
      "éducation",
      "canine",
    ]);
  });
});

describe("parseHtmlDraft", () => {
  it("separates headings, paragraphs and list items", () => {
    const doc = parseHtmlDraft(HTML);
    expect(doc.headings.map((h) => h.level)).toEqual([1, 2, 2]);
    expect(doc.paragraphs).toHaveLength(2);
    expect(doc.listItems).toBe(2);
    expect(doc.lists).toEqual([2]);
  });

  it("counts images and tables and decodes entities", () => {
    const doc = parseHtmlDraft(
      "<p>Chiens &amp; chats <img src='a.png'></p><table><tr><td>x</td></tr></table>",
    );
    expect(doc.images).toBe(1);
    expect(doc.tables).toBe(1);
    expect(doc.bodyText).toContain("Chiens & chats");
  });

  it("does not count a paragraph inside a list item as prose", () => {
    const doc = parseHtmlDraft(
      "<ul><li><p>un</p></li><li><p>deux</p></li></ul>",
    );
    expect(doc.paragraphs).toHaveLength(0);
  });
});

describe("countNgrams", () => {
  it("ignores stopwords for words and bigrams", () => {
    const tokens = tokenize("le collier de dressage et le collier");
    const { words, bigrams, trigrams } = countNgrams(
      tokens,
      stopwordsFor("fr"),
    );
    expect(words.get("collier")).toBe(2);
    expect(words.has("le")).toBe(false);
    expect(bigrams.has("collier de")).toBe(false);
    expect(trigrams.get("collier de dressage")).toBe(1);
  });
});

describe("analyzeDraft", () => {
  const analysis = analyzeDraft({
    title: "Collier de dressage : le guide",
    meta: "Tout savoir sur le collier de dressage.",
    slug: "collier-de-dressage",
    html: HTML,
    keyword: "collier de dressage",
    languageCode: "fr",
  });

  it("finds the keyword in the strategic zones", () => {
    expect(analysis.keyword.zones.h1).toBe(2);
    expect(analysis.keyword.zones.firstParagraph).toBe(2);
    expect(analysis.keyword.zones.titleTag).toBe(2);
    expect(analysis.keyword.zones.slug).toBe(2);
    expect(analysis.keyword.occurrences).toBe(3);
  });

  it("reports the structure", () => {
    expect(analysis.structure).toMatchObject({ h1: 1, h2: 2, lists: 1 });
  });
});

describe("brief comparison and score", () => {
  const analysis = analyzeDraft({
    title: "",
    meta: "",
    slug: "",
    html: HTML,
    keyword: "collier de dressage",
    languageCode: "fr",
  });

  it("flags competitor terms missing from the draft", () => {
    const comparison = compareWithBrief(analysis, BRIEF);
    expect(comparison.missingTerms.map((t) => t.term)).toEqual(["récompenses"]);
    expect(comparison.terms.find((t) => t.term === "collier")?.covered).toBe(
      true,
    );
  });

  it("adds term and length parts once the brief is loaded, penalising a short draft", () => {
    const comparison = compareWithBrief(analysis, BRIEF);
    const withoutBrief = scoreDraft(analysis, null, null);
    const withBrief = scoreDraft(analysis, BRIEF, comparison);
    expect(withoutBrief.hasBrief).toBe(false);
    expect(withBrief.parts.map((p) => p.key)).toContain("terms");
    const length = withBrief.parts.find((p) => p.key === "length");
    expect(length?.points).toBeLessThanOrEqual(2);
    expect(withBrief.score).toBeGreaterThanOrEqual(0);
    expect(withBrief.score).toBeLessThanOrEqual(100);
  });

  it("lists competitor sub-topics the draft does not cover", () => {
    const subtopics = uncoveredSubtopics(analysis, BRIEF);
    expect(subtopics.map((s) => s.heading)).toEqual([
      "Récompenser le comportement positif",
    ]);
  });
});

describe("reviewStyle", () => {
  it("finds writing tics with their offsets, accent-aware", () => {
    const text = "Il est essentiel de choisir. Un outil incontournable.";
    const review = reviewStyle(text);
    const ids = review.tics.map((t) => t.id);
    expect(ids).toHaveLength(2);
    expect(ids).toContain("essentiel");
    expect(ids).toContain("incontournable");
    const essentiel = review.tics.find((t) => t.id === "essentiel");
    expect(
      text.slice(essentiel?.matches[0].start, essentiel?.matches[0].end),
    ).toBe("Il est essentiel de");
  });

  it("flags a connector used too often", () => {
    const text = "Ainsi un. Ainsi deux. Ainsi trois. Et le reste du texte.";
    const review = reviewStyle(text);
    expect(review.connectors.find((c) => c.word === "ainsi")?.overused).toBe(
      true,
    );
  });

  it("detects runs of sentences with the same length", () => {
    const text = Array.from(
      { length: 5 },
      () => "Une phrase de cinq mots.",
    ).join("\n");
    expect(reviewStyle(text).rhythm.flatRuns).toHaveLength(1);
  });
});
