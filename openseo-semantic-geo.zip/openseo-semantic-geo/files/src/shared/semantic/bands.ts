// Optimisation zones of the lexical-field chart. For each term, the pages that
// rank give a distribution of "how many times is it used": the middle half of
// that distribution is the normal zone, above it the content over-uses it.
import type { SemanticBriefTerm } from "./types";

export type Zone = "under" | "normal" | "strong" | "over";

export type TermBands = {
  /** Fewer uses than this is under-optimised. */
  from: number;
  /** Up to this many uses is the normal, recommended range. */
  to: number;
  /** Up to this many uses is strong but still seen on ranking pages. */
  strongTo: number;
  /** Top of the scale; beyond `strongTo` is over-optimised. */
  top: number;
};

const OVER_HEADROOM = 1.25;

/** Linear-interpolated quantile of an ascending list. */
export function quantile(sortedAscending: number[], q: number): number {
  if (sortedAscending.length === 0) return 0;
  const position = (sortedAscending.length - 1) * q;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  const weight = position - lower;
  return (
    sortedAscending[lower] * (1 - weight) + sortedAscending[upper] * weight
  );
}

const round1 = (value: number) => Math.round(value * 10) / 10;

/**
 * Quartiles and maximum of a term's per-page counts. `counts` holds only the
 * pages that use the term; the other read pages count as zero.
 */
export function termDistribution(
  counts: number[],
  pagesRead: number,
): Pick<SemanticBriefTerm, "q1" | "median" | "q3" | "max"> {
  const padded = [...counts];
  while (padded.length < pagesRead) padded.push(0);
  padded.sort((a, b) => a - b);
  return {
    q1: round1(quantile(padded, 0.25)),
    median: round1(quantile(padded, 0.5)),
    q3: round1(quantile(padded, 0.75)),
    max: padded.at(-1) ?? 0,
  };
}

export function termBands(
  term: Pick<SemanticBriefTerm, "q1" | "q3" | "max">,
): TermBands {
  const from = Math.max(1, Math.round(term.q1));
  const to = Math.max(from, Math.round(term.q3));
  const strongTo = Math.max(to, term.max);
  const top = Math.max(strongTo + 1, Math.ceil(strongTo * OVER_HEADROOM));
  return { from, to, strongTo, top };
}

export function zoneFor(count: number, bands: TermBands): Zone {
  if (count < bands.from) return "under";
  if (count <= bands.to) return "normal";
  if (count <= bands.strongTo) return "strong";
  return "over";
}

export type LexicalStatus = "optimized" | "under" | "over";

export type LexicalScore = {
  /** 0-100: how close the content is to the usual use of each term. */
  score: number;
  status: LexicalStatus;
  counts: Record<Zone, number>;
  total: number;
  /** Terms used more often than any ranking page does. */
  overCount: number;
  /** Over-optimised terms tolerated before the content reads as over-optimised. */
  overTolerance: number;
  /** Score from which the content counts as optimised. */
  target: number;
};

/** Only the most shared terms are scored. */
export const LEXICAL_SCORE_TERM_CAP = 60;
export const LEXICAL_TARGET = 80;
/** Share of the scored terms that may be over-optimised. */
const OVER_TOLERANCE_SHARE = 0.1;

// Credit per zone. Under-optimised terms earn partial credit in proportion to
// how close they are to the lower bound of the normal range; a strong but
// still observed use is nearly as good as a normal one; going past every
// ranking page is penalised.
const STRONG_CREDIT = 0.85;
const OVER_CREDIT = 0.4;

type ScoredTerm = Pick<SemanticBriefTerm, "q1" | "q3" | "max" | "pages"> & {
  yours: number;
};

/**
 * One score and one status for the whole lexical field, weighted by how many
 * ranking pages use each term. Status: over-optimised when too many terms go
 * past the maximum seen on ranking pages, optimised from the target score,
 * under-optimised otherwise.
 */
export function lexicalScore(terms: ScoredTerm[]): LexicalScore {
  const counts: Record<Zone, number> = {
    under: 0,
    normal: 0,
    strong: 0,
    over: 0,
  };
  const scored = terms.slice(0, LEXICAL_SCORE_TERM_CAP);
  let weighted = 0;
  let weights = 0;
  for (const term of scored) {
    const bands = termBands(term);
    const zone = zoneFor(term.yours, bands);
    counts[zone]++;
    let credit = 0;
    if (zone === "under") credit = term.yours / bands.from;
    else if (zone === "normal") credit = 1;
    else if (zone === "strong") credit = STRONG_CREDIT;
    else credit = OVER_CREDIT;
    weighted += credit * term.pages;
    weights += term.pages;
  }
  const score = weights ? Math.round((weighted * 100) / weights) : 0;
  const overTolerance = Math.max(
    1,
    Math.floor(scored.length * OVER_TOLERANCE_SHARE),
  );
  let status: LexicalStatus = "under";
  if (counts.over > overTolerance) status = "over";
  else if (score >= LEXICAL_TARGET) status = "optimized";
  return {
    score,
    status,
    counts,
    total: scored.length,
    overCount: counts.over,
    overTolerance,
    target: LEXICAL_TARGET,
  };
}
