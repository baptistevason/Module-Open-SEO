// Text primitives for the Sémantique module. Shared by the browser (live
// editor analysis) and the worker (competitor term extraction) so both sides
// tokenize and match terms identically.

const FR_STOPWORDS = [
  "au",
  "aux",
  "avec",
  "ce",
  "ces",
  "cet",
  "cette",
  "dans",
  "de",
  "des",
  "du",
  "elle",
  "elles",
  "en",
  "et",
  "eux",
  "il",
  "ils",
  "je",
  "la",
  "le",
  "les",
  "leur",
  "leurs",
  "lui",
  "ma",
  "mais",
  "me",
  "même",
  "mêmes",
  "mes",
  "moi",
  "mon",
  "ne",
  "ni",
  "nos",
  "notre",
  "nous",
  "on",
  "ou",
  "où",
  "par",
  "pas",
  "pour",
  "qu",
  "que",
  "qui",
  "sa",
  "se",
  "ses",
  "son",
  "sur",
  "ta",
  "te",
  "tes",
  "toi",
  "ton",
  "tu",
  "un",
  "une",
  "vos",
  "votre",
  "vous",
  "y",
  "d",
  "l",
  "j",
  "n",
  "s",
  "c",
  "m",
  "t",
  "à",
  "ça",
  "cela",
  "ceci",
  "être",
  "avoir",
  "faire",
  "fait",
  "faut",
  "peut",
  "peuvent",
  "doit",
  "doivent",
  "est",
  "sont",
  "sera",
  "seront",
  "était",
  "étaient",
  "soit",
  "a",
  "ont",
  "avait",
  "avaient",
  "aura",
  "auront",
  "ayez",
  "êtes",
  "avez",
  "plus",
  "moins",
  "très",
  "bien",
  "tout",
  "tous",
  "toute",
  "toutes",
  "autre",
  "autres",
  "comme",
  "aussi",
  "sans",
  "sous",
  "entre",
  "vers",
  "chez",
  "dont",
  "donc",
  "alors",
  "ainsi",
  "si",
  "oui",
  "non",
  "car",
  "cependant",
  "toutefois",
  "pourtant",
  "quand",
  "comment",
  "pourquoi",
  "quel",
  "quelle",
  "quels",
  "quelles",
  "afin",
  "ci",
  "là",
  "voici",
  "voilà",
  "chaque",
  "plusieurs",
  "certains",
  "certaines",
  "quelques",
  "peu",
  "beaucoup",
  "trop",
  "encore",
  "déjà",
  "ici",
  "souvent",
  "parfois",
  "toujours",
  "jamais",
  "puis",
  "ensuite",
  "enfin",
  "deux",
  "trois",
  "premier",
  "première",
  "second",
  "seconde",
  "aujourd",
  "hui",
  "vite",
  "lors",
  "lorsque",
  "grâce",
  "malgré",
  "pendant",
  "après",
  "avant",
  "depuis",
  "jusqu",
  "dès",
  "celui",
  "celle",
  "ceux",
  "celles",
];

const EN_STOPWORDS = [
  "a",
  "an",
  "and",
  "are",
  "as",
  "at",
  "be",
  "been",
  "but",
  "by",
  "can",
  "could",
  "did",
  "do",
  "does",
  "for",
  "from",
  "had",
  "has",
  "have",
  "he",
  "her",
  "his",
  "how",
  "i",
  "if",
  "in",
  "into",
  "is",
  "it",
  "its",
  "just",
  "may",
  "me",
  "more",
  "most",
  "my",
  "no",
  "not",
  "of",
  "on",
  "one",
  "or",
  "other",
  "our",
  "out",
  "over",
  "she",
  "so",
  "some",
  "such",
  "than",
  "that",
  "the",
  "their",
  "them",
  "then",
  "there",
  "these",
  "they",
  "this",
  "those",
  "to",
  "too",
  "up",
  "us",
  "was",
  "we",
  "were",
  "what",
  "when",
  "where",
  "which",
  "while",
  "who",
  "why",
  "will",
  "with",
  "would",
  "you",
  "your",
  "also",
  "any",
  "all",
  "each",
  "every",
  "both",
  "about",
  "after",
  "before",
  "between",
  "very",
  "only",
  "own",
  "same",
  "should",
  "being",
  "get",
  "got",
];

const STOPWORDS_FR = new Set(FR_STOPWORDS);
const STOPWORDS_EN = new Set(EN_STOPWORDS);

export function stopwordsFor(languageCode: string): ReadonlySet<string> {
  return languageCode.toLowerCase().startsWith("fr")
    ? STOPWORDS_FR
    : STOPWORDS_EN;
}

export function stripAccents(value: string): string {
  return value.normalize("NFD").replace(/[̀-ͯ]/g, "");
}

/** Lowercase words; apostrophes split ("l'été" -> "l", "été"). */
export function tokenize(text: string): string[] {
  return (
    (text || "")
      .toLowerCase()
      .replace(/['’‘]/g, " ")
      .match(/[a-zà-öø-ÿœæç0-9]+(?:-[a-zà-öø-ÿœæç0-9]+)*/g) ?? []
  );
}

/** Occurrences of `sequence` in `tokens`, accent-insensitive. */
export function countSequence(
  tokens: readonly string[],
  sequence: readonly string[],
): number {
  if (sequence.length === 0 || tokens.length < sequence.length) return 0;
  const norm = tokens.map(stripAccents);
  const target = sequence.map(stripAccents);
  let count = 0;
  for (let i = 0; i <= norm.length - target.length; i++) {
    let match = true;
    for (let j = 0; j < target.length; j++) {
      if (norm[i + j] !== target[j]) {
        match = false;
        break;
      }
    }
    if (match) count++;
  }
  return count;
}

function bump(map: Map<string, number>, key: string) {
  map.set(key, (map.get(key) ?? 0) + 1);
}

export type NgramCounts = {
  words: Map<string, number>;
  bigrams: Map<string, number>;
  trigrams: Map<string, number>;
};

/**
 * Meaningful words, bigrams and trigrams of a token list. Words and bigrams
 * must be made of non-stopwords; a trigram may have a linking word in the
 * middle ("collier de dressage").
 */
export function countNgrams(
  tokens: readonly string[],
  stopwords: ReadonlySet<string>,
): NgramCounts {
  const words = new Map<string, number>();
  const bigrams = new Map<string, number>();
  const trigrams = new Map<string, number>();
  const meaningful = (token: string | undefined): token is string =>
    token !== undefined &&
    token.length >= 3 &&
    !stopwords.has(token) &&
    !/^\d+$/.test(token);

  for (let i = 0; i < tokens.length; i++) {
    const a = tokens[i];
    const b = tokens[i + 1];
    const c = tokens[i + 2];
    if (meaningful(a)) bump(words, a);
    if (meaningful(a) && meaningful(b)) bump(bigrams, `${a} ${b}`);
    if (meaningful(a) && b !== undefined && meaningful(c)) {
      bump(trigrams, `${a} ${b} ${c}`);
    }
  }
  return { words, bigrams, trigrams };
}

const DETECTION_SAMPLE = 3_000;
const DETECTION_MIN_TOKENS = 30;

/**
 * "fr" or "en", from which stopword list the text matches best. The project
 * market is only a fallback: a French article in an English-market project
 * must still be read as French.
 */
export function detectLanguage(
  tokens: readonly string[],
  fallback: string,
): string {
  const fallbackLanguage = fallback.toLowerCase().startsWith("fr")
    ? "fr"
    : "en";
  if (tokens.length < DETECTION_MIN_TOKENS) return fallbackLanguage;
  let fr = 0;
  let en = 0;
  for (const token of tokens.slice(0, DETECTION_SAMPLE)) {
    if (STOPWORDS_FR.has(token)) fr++;
    if (STOPWORDS_EN.has(token)) en++;
  }
  if (fr === en) return fallbackLanguage;
  return fr > en ? "fr" : "en";
}
