// Readability of a text: Flesch reading ease (French and English variants),
// sentence length and passive voice. Pure heuristics, shared by the worker
// (competitor pages) and the browser (the draft) so both are measured alike.
import { tokenize } from "./text";

const VOWELS = /[aeiouyàâäéèêëîïôöùûüÿœæ]+/g;

/** Syllables of a word: vowel groups, minus the silent final e of French and English. */
export function countSyllables(word: string): number {
  const w = word.toLowerCase().replace(/[^a-zà-öø-ÿœæ]/g, "");
  if (w.length <= 3) return 1;
  let count = (w.match(VOWELS) ?? []).length;
  if (count > 1 && (w.endsWith("e") || w.endsWith("es") || w.endsWith("ent")))
    count--;
  return Math.max(1, count);
}

const PASSIVE =
  /\b(?:est|sont|était|étaient|sera|seront|fut|furent|été)\s+(?:\p{L}+ment\s+)?\p{L}+(?:é|ée|és|ées)\b/iu;
// Verbs conjugated with "être" in the active voice are not passives.
const ACTIVE_WITH_ETRE =
  /\b(?:est|sont|était|étaient|sera|seront)\s+(?:allée?s?|arrivée?s?|resté(?:e)?s?|tombée?s?|entrée?s?|sortie?s?|montée?s?|retournée?s?|rentrée?s?|née?s?|décédée?s?|passée?s?|apparue?s?|parti(?:e)?s?|venue?s?|devenue?s?)\b/iu;

function sentencesOf(text: string): string[] {
  return text
    .split(/[.!?…\n]+/)
    .map((s) => s.trim())
    .filter((s) => tokenize(s).length >= 3);
}

export type FleschLevel = {
  label: string;
  tone: "good" | "mid" | "bad";
};

/** Reading ease bands of the Flesch scale, named in French. */
export function fleschLevel(score: number): FleschLevel {
  if (score >= 80) return { label: "Très facile", tone: "good" };
  if (score >= 70) return { label: "Facile", tone: "good" };
  if (score >= 60) return { label: "Assez facile", tone: "good" };
  if (score >= 50) return { label: "Standard", tone: "mid" };
  if (score >= 30) return { label: "Assez difficile", tone: "mid" };
  return { label: "Difficile", tone: "bad" };
}

export type Readability = {
  /** 0-100 (can fall outside on extreme texts), higher is easier. */
  flesch: number;
  /** Mean sentence length in words. */
  avgSentence: number;
  /** Share of sentences longer than 25 words, 0-1. */
  longSentenceShare: number;
  /** Share of sentences in the passive voice, 0-1 (estimate). */
  passiveShare: number;
  sentences: number;
  words: number;
};

export function analyzeReadability(
  text: string,
  languageCode: string,
): Readability | null {
  const sentences = sentencesOf(text);
  const words = tokenize(text);
  if (sentences.length < 3 || words.length < 30) return null;

  const syllables = words.reduce((sum, w) => sum + countSyllables(w), 0);
  const asl = words.length / sentences.length;
  const asw = syllables / words.length;
  const french = languageCode.toLowerCase().startsWith("fr");
  // Kandel and Moles for French, the original Flesch constants for English.
  const flesch = french
    ? 207 - 1.015 * asl - 73.6 * asw
    : 206.835 - 1.015 * asl - 84.6 * asw;
  const long = sentences.filter((s) => tokenize(s).length > 25).length;
  const passive = sentences.filter(
    (s) => PASSIVE.test(s) && !ACTIVE_WITH_ETRE.test(s),
  ).length;
  return {
    flesch: Math.round(flesch),
    avgSentence: Math.round(asl * 10) / 10,
    longSentenceShare: long / sentences.length,
    passiveShare: passive / sentences.length,
    sentences: sentences.length,
    words: words.length,
  };
}

/** Share of passive sentences of a text, among sentences of 4 words or more. */
export function passiveShareOfText(text: string): {
  share: number;
  total: number;
} {
  const sentences = text
    .split(/[.!?…\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.split(/\s+/).filter(Boolean).length >= 4);
  const passive = sentences.filter(
    (s) => PASSIVE.test(s) && !ACTIVE_WITH_ETRE.test(s),
  ).length;
  return {
    share: sentences.length ? passive / sentences.length : 0,
    total: sentences.length,
  };
}
