// What the AI assistant of the editor produces, and how it becomes HTML for
// the editor. Shared by the worker (validation) and the browser (insertion).
import { escapeHtml } from "./html";
import type { FaqItem } from "./geo";

export const GENERATE_KINDS = ["faq", "blurb", "meta", "outline"] as const;
export type GenerateKind = (typeof GENERATE_KINDS)[number];

export type OutlineSection = { h2: string; h3: string[] };

export type GeneratedContent =
  | { kind: "faq"; items: FaqItem[] }
  | { kind: "blurb"; options: string[] }
  | { kind: "meta"; titles: string[]; descriptions: string[] }
  | { kind: "outline"; sections: OutlineSection[] };

export const FAQ_HEADING = "Questions fréquentes";

/** The FAQ as editor HTML: one H2, then each question as H3 with its answer. */
export function faqToHtml(items: FaqItem[], heading = FAQ_HEADING): string {
  const body = items
    .map(
      (item) =>
        `<h3>${escapeHtml(item.question)}</h3><p>${escapeHtml(item.answer)}</p>`,
    )
    .join("");
  return `<h2>${escapeHtml(heading)}</h2>${body}`;
}

/** The outline as editor HTML: headings with an empty paragraph to fill in. */
export function outlineToHtml(sections: OutlineSection[]): string {
  return sections
    .map((section) => {
      const subs = section.h3
        .map((h3) => `<h3>${escapeHtml(h3)}</h3><p></p>`)
        .join("");
      return `<h2>${escapeHtml(section.h2)}</h2><p></p>${subs}`;
    })
    .join("");
}

export function paragraphToHtml(text: string): string {
  return `<p>${escapeHtml(text)}</p>`;
}

/** Plain text of a FAQ, for the clipboard. */
export function faqToText(items: FaqItem[]): string {
  return items.map((item) => `${item.question}\n${item.answer}`).join("\n\n");
}
