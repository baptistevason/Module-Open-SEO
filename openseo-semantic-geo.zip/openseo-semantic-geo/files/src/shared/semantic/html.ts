// Minimal HTML reader for the editor output (TipTap emits clean, well-formed
// HTML). Environment-agnostic so the same code runs in the browser, in the
// worker and in tests: no DOM needed.

const ENTITIES: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
  laquo: "«",
  raquo: "»",
  hellip: "…",
  rsquo: "’",
  lsquo: "‘",
  ndash: "–",
  mdash: "—",
};

export function decodeEntities(value: string): string {
  return value.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, body: string) => {
    if (body.startsWith("#")) {
      const hex = body[1].toLowerCase() === "x";
      const code = Number.parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    }
    return ENTITIES[body.toLowerCase()] ?? match;
  });
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export type DraftBlock = {
  kind: "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "li";
  text: string;
};

export type ParsedDraft = {
  /** Every text block in document order: the basis of the GEO checks. */
  blocks: DraftBlock[];
  /** Links found in the content, with their anchor text. */
  links: { href: string; text: string }[];
  headings: { level: number; text: string }[];
  /** Prose blocks: not headings, not list items. */
  paragraphs: string[];
  /** All text, one block per line, headings and list items included. */
  bodyText: string;
  listItems: number;
  /** Item count of each list, in document order. */
  lists: number[];
  tables: number;
  images: number;
  /** Images with no alt text or an empty one. */
  imagesMissingAlt: number;
  /** Embedded videos: YouTube, Vimeo and similar iframes, video elements. */
  videos: number;
  /** Bold (strong, b) and blockquote elements, for the GEO format checks. */
  bold: number;
  quotes: number;
};

const BLOCK_TAGS = new Set([
  "p",
  "li",
  "blockquote",
  "td",
  "th",
  "div",
  "br",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
]);
const TOKEN = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>|([^<]+)/g;
const HREF = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i;

const ALT = /\balt\s*=\s*(?:"([^"]*)"|'([^']*)')/i;
const SRC = /\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)')/i;
export const VIDEO_HOST =
  /youtube(?:-nocookie)?\.com|youtu\.be|vimeo\.com|dailymotion\.com|wistia\.(?:com|net)|player\./i;

/** A <video> element, or an iframe whose source is a known video player. */
function isVideoTag(name: string, raw: string): boolean {
  if (name === "video") return true;
  if (name !== "iframe") return false;
  const src = SRC.exec(raw);
  return VIDEO_HOST.test(src?.[1] ?? src?.[2] ?? "");
}

type HeadingKind = "h1" | "h2" | "h3" | "h4" | "h5" | "h6";

const HEADING_KINDS: HeadingKind[] = ["h1", "h2", "h3", "h4", "h5", "h6"];

function headingKind(level: number): HeadingKind {
  return HEADING_KINDS[level - 1] ?? "h6";
}

export function parseHtmlDraft(html: string): ParsedDraft {
  const headings: ParsedDraft["headings"] = [];
  const paragraphs: string[] = [];
  const bodyLines: string[] = [];
  const blocks: DraftBlock[] = [];
  const links: ParsedDraft["links"] = [];
  const lists: number[] = [];
  const listStack: number[] = [];
  let listItems = 0;
  let tables = 0;
  let images = 0;
  let imagesMissingAlt = 0;
  let videos = 0;
  let bold = 0;
  let quotes = 0;
  let liDepth = 0;
  let headingLevel = 0;
  let buffer = "";
  let openLink: { href: string; text: string } | null = null;

  const flush = () => {
    const text = decodeEntities(buffer).replace(/\s+/g, " ").trim();
    buffer = "";
    if (!text) return;
    bodyLines.push(text);
    if (headingLevel > 0) {
      headings.push({ level: headingLevel, text });
      blocks.push({ kind: headingKind(headingLevel), text });
    } else if (liDepth === 0) {
      paragraphs.push(text);
      blocks.push({ kind: "p", text });
    } else {
      blocks.push({ kind: "li", text });
    }
  };

  for (const match of html.matchAll(TOKEN)) {
    const [raw, closing, rawName, text] = match;
    if (text !== undefined) {
      buffer += text;
      if (openLink) openLink.text += text;
      continue;
    }
    const name = rawName.toLowerCase();
    const isClosing = closing === "/";
    if (name === "a") {
      if (isClosing) {
        if (openLink) {
          links.push({
            href: openLink.href,
            text: decodeEntities(openLink.text).replace(/\s+/g, " ").trim(),
          });
          openLink = null;
        }
      } else {
        const href = HREF.exec(raw);
        openLink = {
          href: decodeEntities(href?.[1] ?? href?.[2] ?? ""),
          text: "",
        };
      }
      continue;
    }
    if (name === "img" && !isClosing) {
      images++;
      const alt = ALT.exec(raw);
      if (!(alt?.[1] ?? alt?.[2] ?? "").trim()) imagesMissingAlt++;
    }
    if (!isClosing && isVideoTag(name, raw)) videos++;
    if (name === "table" && !isClosing) tables++;
    if ((name === "strong" || name === "b") && !isClosing) bold++;
    if (name === "blockquote" && !isClosing) quotes++;
    if ((name === "ul" || name === "ol") && !isClosing) {
      flush();
      lists.push(0);
      listStack.push(lists.length - 1);
      continue;
    }
    if ((name === "ul" || name === "ol") && isClosing) {
      flush();
      listStack.pop();
      continue;
    }
    if (!BLOCK_TAGS.has(name)) continue;

    flush();
    if (name === "li") {
      if (isClosing) {
        liDepth = Math.max(0, liDepth - 1);
      } else {
        liDepth++;
        listItems++;
        const current = listStack.at(-1);
        if (current !== undefined) lists[current]++;
      }
    }
    headingLevel = /^h[1-6]$/.test(name) && !isClosing ? Number(name[1]) : 0;
  }
  flush();

  return {
    blocks,
    links,
    headings,
    paragraphs,
    bodyText: bodyLines.join("\n"),
    listItems,
    lists,
    tables,
    images,
    imagesMissingAlt,
    videos,
    bold,
    quotes,
  };
}

/** Plain text of the HTML, one block per line. */
export function htmlToPlainText(html: string): string {
  return parseHtmlDraft(html).bodyText;
}
