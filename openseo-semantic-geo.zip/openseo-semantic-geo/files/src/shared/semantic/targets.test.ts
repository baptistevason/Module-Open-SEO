import { describe, expect, it } from "vitest";
import { analyzeReadability, countSyllables, fleschLevel } from "./readability";
import {
  buildTargetRows,
  computeTargets,
  countLinks,
  draftCounts,
  sectionWords,
  targetRow,
  type MetricCounts,
} from "./targets";

const counts = (overrides: Partial<MetricCounts> = {}): MetricCounts => ({
  words: 1500,
  h2: 6,
  h3: 4,
  paragraphs: 30,
  images: 5,
  videos: 0,
  tables: 1,
  lists: 3,
  bold: 10,
  internalLinks: 6,
  externalLinks: 3,
  ...overrides,
});

const page = (overrides: Partial<MetricCounts> = {}) => ({
  metrics: counts(overrides),
});

describe("computeTargets", () => {
  it("builds a spread per metric and counts the pages that have one", () => {
    const targets = computeTargets([
      page({ words: 1200, images: 2, videos: 0 }),
      page({ words: 1500, images: 4, videos: 1 }),
      page({ words: 1800, images: 6, videos: 0 }),
      page({ words: 2100, images: 8, videos: 1 }),
    ]);
    expect(targets.metrics.words).toMatchObject({
      min: 1200,
      median: 1650,
      max: 2100,
    });
    expect(targets.metrics.images).toMatchObject({
      min: 2,
      max: 8,
      pagesWith: 4,
    });
    expect(targets.metrics.videos.pagesWith).toBe(2);
    expect(targets.outliers).toBe(0);
  });

  it("leaves out pages whose length is an outlier", () => {
    const targets = computeTargets([
      page({ words: 1400 }),
      page({ words: 1500 }),
      page({ words: 1600 }),
      page({ words: 1700 }),
      page({ words: 9000, images: 80 }),
    ]);
    expect(targets.outliers).toBe(1);
    expect(targets.metrics.words.max).toBe(1700);
    expect(targets.metrics.images.max).toBeLessThan(80);
  });

  it("gives the median length of a section", () => {
    const targets = computeTargets([
      page({ words: 1200, h2: 6 }),
      page({ words: 1800, h2: 6 }),
    ]);
    expect(targets.wordsPerSection).toBe(250);
  });
});

describe("targetRow", () => {
  const target = { min: 2, q1: 4, median: 6, q3: 8, max: 12, pagesWith: 5 };

  it("compares a count with the middle half of the pages", () => {
    expect(targetRow("images", 1, target)).toMatchObject({
      status: "below",
      missing: 3,
      low: 4,
      high: 8,
    });
    expect(targetRow("images", 6, target).status).toBe("within");
    expect(targetRow("images", 11, target).status).toBe("above");
  });

  it("builds every row", () => {
    const targets = computeTargets([page(), page(), page()]);
    expect(buildTargetRows(counts(), targets)).toHaveLength(11);
  });
});

describe("countLinks", () => {
  it("splits internal and external links", () => {
    expect(
      countLinks(
        [
          "/a",
          "https://www.exemple.fr/b",
          "https://autre.org/c",
          "#top",
          "mailto:x@y.z",
        ],
        "exemple.fr",
      ),
    ).toEqual({ internal: 2, external: 1 });
  });
});

const filler = (n: number) => Array.from({ length: n }, () => "mot").join(" ");

describe("draftCounts and sectionWords", () => {
  const html =
    `<h1>T</h1><p>${filler(20)}</p><h2>Un</h2><p>${filler(30)}</p><h2>Deux</h2><p>court</p>` +
    `<img src="a.png" alt="ok"><img src="b.png"><iframe src="https://www.youtube.com/embed/x"></iframe>` +
    `<ul><li><p>a</p></li></ul><p><strong>g</strong> <a href="/x">i</a> <a href="https://z.org">e</a></p>`;

  it("measures a draft like the pages read", () => {
    const { counts: c, doc } = draftCounts(html, "https://exemple.fr/p", 100);
    expect(c).toMatchObject({
      h2: 2,
      paragraphs: 2,
      images: 2,
      videos: 1,
      lists: 1,
      bold: 1,
      internalLinks: 1,
      externalLinks: 1,
    });
    expect(doc.imagesMissingAlt).toBe(1);
  });

  it("counts the words of each H2 section", () => {
    expect(sectionWords(html)).toEqual([
      { heading: "Un", words: 30 },
      { heading: "Deux", words: 5 },
    ]);
  });
});

describe("readability", () => {
  it("counts syllables with silent final e", () => {
    expect(countSyllables("chat")).toBe(1);
    expect(countSyllables("maison")).toBe(2);
    expect(countSyllables("table")).toBe(1);
    expect(countSyllables("éducation")).toBeGreaterThanOrEqual(3);
  });

  it("scores a simple text as easier than a heavy one", () => {
    const easy =
      "Le chien dort. Il mange du pain. Le chat boit du lait. Nous allons au parc. Il fait beau ce matin. Les enfants jouent dehors.";
    const hard =
      "L’optimisation sémantique conditionnelle des représentations contextuelles nécessite l’application systématique d’algorithmes d’apprentissage particulièrement sophistiqués, notamment lorsqu’interviennent des considérations institutionnelles extraordinairement complexes.";
    const a = analyzeReadability(`${easy} ${easy}`, "fr");
    const b = analyzeReadability(`${hard} ${hard} ${hard}`, "fr");
    expect(a).not.toBeNull();
    expect(b).not.toBeNull();
    expect(a?.flesch ?? 0).toBeGreaterThan(b?.flesch ?? 0);
    expect(fleschLevel(85).tone).toBe("good");
    expect(fleschLevel(20).tone).toBe("bad");
  });

  it("needs enough text", () => {
    expect(analyzeReadability("Trop court.", "fr")).toBeNull();
  });
});
