// GEO checks: is the content easy for AI answer engines (ChatGPT, Perplexity,
// Gemini, AI Overviews) to quote? Pure heuristics over the editor HTML, run
// live in the browser. They do not predict citations; they flag the habits
// that make a passage extractable and trustworthy.
import { parseHtmlDraft, type DraftBlock } from "./html";

export type GeoStatus = "ok" | "warn" | "fail";

export type GeoCheck = {
  id: string;
  label: string;
  status: GeoStatus;
  detail: string;
  /** Short list of the headings or passages concerned. */
  items?: string[];
};

export type FaqItem = { question: string; answer: string };

export const BLURB_MIN_WORDS = 40;
export const BLURB_MAX_WORDS = 80;
const ANSWER_MIN_WORDS = 15;
const ANSWER_MAX_WORDS = 90;
const FAQ_MIN_ITEMS = 3;
const FAQ_ANSWER_MAX_WORDS = 120;

export function countWords(text: string): number {
  return text.split(/\s+/).filter(Boolean).length;
}

const FAQ_HEADING =
  /\bfaq\b|questions?\s+(?:fréquentes?|courantes?)|foire aux questions/i;
const FIGURE =
  /\d[\d\s.,]*\s?(?:%|€|(?:euros?|ans?|kg|cm|mm|ml|jours?|mois|semaines?|fois)\b)|\b(?:19|20)\d{2}\b/i;
const FRESHNESS = /mis(?:e)? à jour|actualisé|dernière mise à jour|updated/i;
const AUTHOR =
  /rédigé par|écrit par|relu par|vérifié par|auteur|par\s+(?:le\s+|la\s+)?(?:dr\.?|docteur|vétérinaire|expert)|vétérinaire|docteur|expert/i;

const isHeading = (block: DraftBlock) => /^h[1-6]$/.test(block.kind);
const isQuestion = (text: string) => text.trim().endsWith("?");

/** Questions of the content with the prose that answers them. */
export function extractFaq(blocks: DraftBlock[]): FaqItem[] {
  const items: FaqItem[] = [];
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    if (!isHeading(block) || block.kind === "h1" || !isQuestion(block.text)) {
      continue;
    }
    // One paragraph and the list items that follow it: anything after
    // belongs to the rest of the page, not to this answer.
    const answer: string[] = [];
    let sawParagraph = false;
    for (let j = i + 1; j < blocks.length && !isHeading(blocks[j]); j++) {
      if (blocks[j].kind === "p") {
        if (sawParagraph) break;
        sawParagraph = true;
      }
      answer.push(blocks[j].text);
    }
    const text = answer.join(" ").trim();
    if (text) {
      items.push({
        question: block.text.trim(),
        answer: text.split(/\s+/).slice(0, FAQ_ANSWER_MAX_WORDS).join(" "),
      });
    }
  }
  return items;
}

function blurbCheck(blocks: DraftBlock[]): GeoCheck {
  const firstSection = blocks.findIndex(
    (b) => b.kind === "h2" || b.kind === "h3",
  );
  const intro = (firstSection === -1 ? blocks : blocks.slice(0, firstSection))
    .filter((b) => b.kind === "p")
    .at(0);
  const label = `Blurb GEO (${BLURB_MIN_WORDS} à ${BLURB_MAX_WORDS} mots)`;
  if (!intro) {
    return {
      id: "blurb",
      label,
      status: "fail",
      detail: "Aucun paragraphe d’introduction avant le premier sous-titre.",
    };
  }
  const words = countWords(intro.text);
  if (words < BLURB_MIN_WORDS) {
    return {
      id: "blurb",
      label,
      status: "warn",
      detail: `Introduction trop courte : ${words} mots. Résumez la réponse en ${BLURB_MIN_WORDS} à ${BLURB_MAX_WORDS} mots.`,
    };
  }
  if (words > BLURB_MAX_WORDS) {
    return {
      id: "blurb",
      label,
      status: "warn",
      detail: `Introduction trop longue : ${words} mots. Condensez-la à ${BLURB_MAX_WORDS} mots maximum.`,
    };
  }
  return {
    id: "blurb",
    label,
    status: "ok",
    detail: `${words} mots : un passage assez court pour être repris tel quel.`,
  };
}

function answerFirstCheck(blocks: DraftBlock[]): GeoCheck {
  const label = "Réponse directe sous chaque sous-titre";
  const weak: string[] = [];
  let total = 0;
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    if (block.kind !== "h2") continue;
    // FAQ section titles introduce questions, not an answer.
    if (FAQ_HEADING.test(block.text)) continue;
    total++;
    const next = blocks[i + 1];
    const words = next && next.kind === "p" ? countWords(next.text) : 0;
    if (words < ANSWER_MIN_WORDS || words > ANSWER_MAX_WORDS) {
      weak.push(block.text);
    }
  }
  if (total === 0) {
    return {
      id: "answer-first",
      label,
      status: "warn",
      detail: "Aucun sous-titre H2 : structurez le contenu en sections.",
    };
  }
  const good = total - weak.length;
  const ratio = good / total;
  return {
    id: "answer-first",
    label,
    status: ratio >= 0.8 ? "ok" : ratio >= 0.5 ? "warn" : "fail",
    detail: `${good} / ${total} sections commencent par un paragraphe de ${ANSWER_MIN_WORDS} à ${ANSWER_MAX_WORDS} mots qui répond tout de suite.`,
    items: weak.slice(0, 5),
  };
}

function faqCheck(blocks: DraftBlock[], faq: FaqItem[]): GeoCheck {
  const label = "FAQ en fin de contenu";
  const hasFaqHeading = blocks.some(
    (b) => isHeading(b) && FAQ_HEADING.test(b.text),
  );
  if (faq.length >= FAQ_MIN_ITEMS) {
    return {
      id: "faq",
      label,
      status: "ok",
      detail: `${faq.length} questions avec réponse : prêtes pour le schema FAQPage.`,
    };
  }
  if (faq.length > 0 || hasFaqHeading) {
    return {
      id: "faq",
      label,
      status: "warn",
      detail: `${faq.length} question(s) détectée(s). Visez au moins ${FAQ_MIN_ITEMS} sous-titres formulés en question, suivis de leur réponse.`,
    };
  }
  return {
    id: "faq",
    label,
    status: "fail",
    detail:
      "Aucune FAQ. Ajoutez une section de questions (titres se terminant par « ? ») avec une réponse courte.",
  };
}

function sourcesCheck(
  blocks: DraftBlock[],
  links: { href: string; text: string }[],
): GeoCheck {
  const label = "Chiffres sourcés";
  const figures = blocks.filter(
    (b) => b.kind !== "h1" && !isHeading(b) && FIGURE.test(b.text),
  ).length;
  const external = links.filter((l) => /^https?:\/\//i.test(l.href)).length;
  if (figures < 3) {
    return {
      id: "sources",
      label,
      status: "ok",
      detail: "Peu de chiffres : rien à sourcer pour l’instant.",
    };
  }
  if (external === 0) {
    return {
      id: "sources",
      label,
      status: "fail",
      detail: `${figures} passages chiffrés et aucun lien externe : citez vos sources (organisme, étude, année).`,
    };
  }
  return {
    id: "sources",
    label,
    status: external * 4 < figures ? "warn" : "ok",
    detail: `${figures} passages chiffrés, ${external} lien(s) externe(s).`,
  };
}

function freshnessCheck(text: string): GeoCheck {
  const label = "Date ou mise à jour visible";
  const year = new Date().getFullYear();
  const mentionsYear = [year, year - 1].some((y) => text.includes(String(y)));
  const ok = mentionsYear || FRESHNESS.test(text);
  return {
    id: "freshness",
    label,
    status: ok ? "ok" : "warn",
    detail: ok
      ? "Une date récente ou une mise à jour est mentionnée."
      : "Aucune date récente : indiquez « mis à jour le … » et l’année des chiffres.",
  };
}

function authorCheck(text: string): GeoCheck {
  const ok = AUTHOR.test(text);
  return {
    id: "author",
    label: "Auteur ou expertise mentionnés",
    status: ok ? "ok" : "warn",
    detail: ok
      ? "Un auteur, une relecture ou une expertise est évoqué."
      : "Aucun signal d’auteur ou d’expertise (rédigé par, relu par, profession).",
  };
}

function structureCheck(lists: number, tables: number): GeoCheck {
  const ok = lists + tables > 0;
  return {
    id: "structure",
    label: "Listes ou tableaux",
    status: ok ? "ok" : "warn",
    detail: ok
      ? `${lists} liste(s), ${tables} tableau(x) : des formats faciles à citer.`
      : "Aucune liste ni tableau : ajoutez-en un pour les étapes ou comparaisons.",
  };
}

export function analyzeGeo(html: string) {
  const doc = parseHtmlDraft(html);
  const faq = extractFaq(doc.blocks);
  const text = doc.bodyText;
  const checks = [
    blurbCheck(doc.blocks),
    answerFirstCheck(doc.blocks),
    faqCheck(doc.blocks, faq),
    sourcesCheck(doc.blocks, doc.links),
    freshnessCheck(text),
    authorCheck(text),
    structureCheck(doc.lists.length, doc.tables),
  ];
  const passed = checks.filter((c) => c.status === "ok").length;
  return { checks, faq, passed, total: checks.length };
}

export type GeoAnalysis = ReturnType<typeof analyzeGeo>;

/** JSON-LD text safe to embed in a <script> tag. */
function toScriptJson(value: unknown): string {
  return JSON.stringify(value, null, 2).replace(/</g, "\\u003c");
}

export function buildFaqSchema(items: FaqItem[]): string {
  return toScriptJson({
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  });
}

export function buildArticleSchema(input: {
  headline: string;
  description: string;
  url: string;
  datePublished: string | null;
  dateModified: string | null;
}): string {
  const schema: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: input.headline,
  };
  if (input.description) schema.description = input.description;
  if (input.url) schema.mainEntityOfPage = input.url;
  if (input.datePublished) schema.datePublished = input.datePublished;
  if (input.dateModified) schema.dateModified = input.dateModified;
  return toScriptJson(schema);
}

/** The JSON-LD wrapped in the script tag to paste into the page. */
export function wrapJsonLd(json: string): string {
  return `<script type="application/ld+json">\n${json}\n</script>`;
}
