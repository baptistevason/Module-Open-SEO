// Style review: spots what makes copy sound generic (writing tics, overused
// connectors, monotonous sentence rhythm) so it can be reworked by hand.
// Pure and environment-agnostic: runs live in the browser while editing.

export type Tic = {
  id: string;
  label: string;
  hint: string;
  pattern: string;
};

// Stock phrases of generic web copy. `hint` tells what to do instead.
export const TICS: Tic[] = [
  {
    id: "essentiel",
    label: "« Il est essentiel de… »",
    hint: "Dire directement quoi faire et pourquoi.",
    pattern:
      "\\bil est (?:essentiel|important|crucial|primordial|capital|fondamental|indispensable|nécessaire) de\\b",
  },
  {
    id: "convient",
    label: "« Il convient de / force est de constater »",
    hint: "Tournure administrative : verbe d'action direct.",
    pattern: "\\bil convient de\\b|\\bforce est de constater\\b",
  },
  {
    id: "que-vous-soyez",
    label: "« Que vous soyez… ou… »",
    hint: "Nommer le lecteur visé plutôt que tout le monde.",
    pattern: "\\bque vous soyez\\b|\\bque ce soit pour\\b",
  },
  {
    id: "monde-ou",
    label: "« Dans un monde où / à l'ère de »",
    hint: "Entrée en matière creuse : commencer par le fait utile.",
    pattern: "\\bdans un monde où\\b|\\bà l['’]ère (?:du|de la|des|de l['’])",
  },
  {
    id: "veritable",
    label: "« Véritable allié / atout / levier »",
    hint: "Montrer le bénéfice concret au lieu de l'étiqueter.",
    pattern:
      "\\bvéritables? (?:allié|alliée|atout|levier|pilier|révolution|trésor|must)s?\\b",
  },
  {
    id: "role-cle",
    label: "« Joue un rôle clé »",
    hint: "Expliquer ce que ça fait réellement.",
    pattern:
      "\\bjou(?:e|ent|er|ant) un rôle (?:clé|crucial|essentiel|majeur|déterminant|central|important)\\b",
  },
  {
    id: "au-coeur",
    label: "« Au cœur de »",
    hint: "Souvent superflu : le retirer ou préciser.",
    pattern: "\\bau c(?:œ|oe)ur (?:de|du|des)\\b",
  },
  {
    id: "incontournable",
    label: "« Incontournable »",
    hint: "Superlatif vide : dire pourquoi c'est utile.",
    pattern: "\\bincontournables?\\b",
  },
  {
    id: "change-donne",
    label: "« Change la donne »",
    hint: "Image usée : chiffrer ou décrire le changement.",
    pattern: "\\bchang(?:e|ent|er|era) la donne\\b",
  },
  {
    id: "pas-seulement",
    label: "« Ce n'est pas seulement X, c'est Y »",
    hint: "Opposition artificielle : affirmer Y directement.",
    pattern:
      "\\bn['’](?:est|sont) pas (?:seulement|simplement|juste|qu['’]un|qu['’]une)\\b|\\bnon seulement\\b",
  },
  {
    id: "hesitez",
    label: "« N'hésitez pas à »",
    hint: "Appel à l'action mou : verbe à l'impératif.",
    pattern: "\\bn['’]hésitez pas à\\b",
  },
  {
    id: "plongeons",
    label: "« Plongeons / découvrons ensemble »",
    hint: "Annonce inutile : entrer dans le sujet.",
    pattern:
      "\\b(?:plongeons|découvrons ensemble|explorons ensemble|voyons ensemble)\\b",
  },
  {
    id: "compris",
    label: "« Vous l'aurez compris »",
    hint: "Formule de remplissage : la supprimer.",
    pattern: "\\bvous l['’]aurez compris\\b|\\bsans plus attendre\\b",
  },
  {
    id: "en-somme",
    label: "« En somme / en conclusion »",
    hint: "Conclusion scolaire : finir sur l'action ou l'idée forte.",
    pattern:
      "\\ben (?:somme|conclusion|définitive|résumé)\\b|\\bpour conclure\\b",
  },
  {
    id: "optimal",
    label: "« Optimal / optimiser »",
    hint: "Mot fourre-tout : dire ce qui s'améliore et de combien.",
    pattern: "\\boptima(?:l|le|ux|les)\\b|\\bde manière optimale\\b",
  },
  {
    id: "tranquillite",
    label: "« En toute sérénité / tranquillité »",
    hint: "Promesse vague : dire ce qui rassure concrètement.",
    pattern: "\\ben toute (?:sérénité|tranquillité|simplicité|sécurité)\\b",
  },
];

// Logical connectors that pile up in generated copy.
export const CONNECTORS = [
  "de plus",
  "par ailleurs",
  "en outre",
  "en effet",
  "ainsi",
  "également",
  "notamment",
  "toutefois",
  "cependant",
  "néanmoins",
  "d'ailleurs",
  "d’ailleurs",
  "enfin",
];

export type TextMatch = { start: number; end: number };

const WORD = /[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu;
const wordCount = (value: string) => (value.match(WORD) ?? []).length;

// Accent-aware word boundaries: the regex word boundary only knows ASCII
// letters. At the start of a top-level alternative it becomes a lookbehind,
// at its end a lookahead.
function splitTopLevel(source: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let current = "";
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    if (ch === "\\") {
      current += ch + (source[i + 1] ?? "");
      i++;
      continue;
    }
    if (ch === "(") depth++;
    if (ch === ")") depth--;
    if (ch === "|" && depth === 0) {
      parts.push(current);
      current = "";
      continue;
    }
    current += ch;
  }
  parts.push(current);
  return parts;
}

function boundaryRegex(source: string): RegExp {
  const parts = splitTopLevel(source).map((alternative) => {
    let part = alternative;
    if (part.startsWith("\\b")) part = "(?<![\\p{L}\\p{N}])" + part.slice(2);
    if (part.endsWith("\\b")) part = part.slice(0, -2) + "(?![\\p{L}\\p{N}])";
    return part;
  });
  return new RegExp(parts.join("|"), "giu");
}

function findAll(text: string, regex: RegExp): TextMatch[] {
  const out: TextMatch[] = [];
  regex.lastIndex = 0;
  let match = regex.exec(text);
  while (match !== null) {
    if (match[0].length === 0) {
      regex.lastIndex++;
    } else {
      out.push({ start: match.index, end: match.index + match[0].length });
    }
    match = regex.exec(text);
  }
  return out;
}

// Splits prose into sentences with their offsets. Line breaks end a sentence
// too, so headings and list items never merge with the next paragraph.
function sentences(text: string, skip: TextMatch[] | undefined) {
  const out: { start: number; end: number; words: number }[] = [];
  const re = /[^.!?…\n]+[.!?…]*/g;
  let match = re.exec(text);
  while (match !== null) {
    const start = match.index;
    const end = start + match[0].length;
    const skipped = skip?.some((r) => start >= r.start && end <= r.end);
    const words = wordCount(match[0]);
    if (!skipped && words >= 3) out.push({ start, end, words });
    match = re.exec(text);
  }
  return out;
}

export type StyleReview = ReturnType<typeof reviewStyle>;

// text: plain text of the content, blocks separated by "\n".
// options.skipRanges: offsets excluded from rhythm stats (headings).
export function reviewStyle(
  text: string,
  options: { skipRanges?: TextMatch[] } = {},
) {
  const totalWords = wordCount(text);

  const tics = TICS.map((tic) => ({
    id: tic.id,
    label: tic.label,
    hint: tic.hint,
    matches: findAll(text, boundaryRegex(tic.pattern)),
  }))
    .filter((tic) => tic.matches.length > 0)
    .map((tic) => ({ ...tic, count: tic.matches.length }));
  tics.sort((a, b) => b.count - a.count);

  // A connector is overused past 1 use per 350 words (minimum 3 uses).
  const connectorLimit = Math.max(3, Math.ceil(totalWords / 350));
  const byConnector = new Map<string, { word: string; matches: TextMatch[] }>();
  for (const connector of CONNECTORS) {
    const key = connector.replace("’", "'");
    const matches = findAll(text, boundaryRegex(`\\b${connector}\\b`));
    if (matches.length === 0) continue;
    const entry = byConnector.get(key) ?? { word: key, matches: [] };
    entry.matches.push(...matches);
    byConnector.set(key, entry);
  }
  const connectors = [...byConnector.values()].map((c) => ({
    ...c,
    count: c.matches.length,
    overused: c.matches.length >= connectorLimit,
  }));
  connectors.sort((a, b) => b.count - a.count);

  // Rhythm: human prose alternates short and long sentences. A low
  // coefficient of variation, or long runs of same-length sentences, reads flat.
  const list = sentences(text, options.skipRanges);
  const lengths = list.map((s) => s.words);
  const mean = lengths.length
    ? lengths.reduce((a, b) => a + b, 0) / lengths.length
    : 0;
  const variance = lengths.length
    ? lengths.reduce((a, b) => a + (b - mean) ** 2, 0) / lengths.length
    : 0;
  const cv = mean ? Math.sqrt(variance) / mean : 0;

  const flatRuns: (TextMatch & { sentences: number })[] = [];
  let runStart = 0;
  for (let i = 1; i <= list.length; i++) {
    const continues =
      i < list.length && Math.abs(list[i].words - list[i - 1].words) <= 3;
    if (!continues) {
      if (i - runStart >= 4) {
        flatRuns.push({
          start: list[runStart].start,
          end: list[i - 1].end,
          sentences: i - runStart,
        });
      }
      runStart = i;
    }
  }

  const shortShare = lengths.length
    ? lengths.filter((n) => n <= 8).length / lengths.length
    : 0;

  return {
    totalWords,
    tics,
    connectors,
    connectorLimit,
    rhythm: {
      sentences: list.length,
      mean,
      cv,
      shortShare,
      flat: list.length >= 8 && cv < 0.35,
      flatRuns,
    },
  };
}
