// Live semantic analysis of a draft (Markdown or plain text), optionally
// compared with a SERP brief built from the pages ranking for the keyword.
import {
  countNgrams,
  detectLanguage,
  countSequence,
  stopwordsFor,
  stripAccents,
  tokenize,
} from "./text";
import { lexicalScore, type LexicalScore } from "./bands";
import { parseHtmlDraft } from "./html";
import type { SemanticBrief, SemanticBriefTerm } from "./types";

export type ZonePresence = 0 | 1 | 2; // absent | scattered | exact phrase

export type DraftInput = {
  title: string;
  meta: string;
  slug: string;
  /** HTML produced by the editor. */
  html: string;
  keyword: string;
  languageCode: string;
};

function zonePresence(
  zoneText: string,
  keywordTokens: string[],
  stopwords: ReadonlySet<string>,
): ZonePresence {
  if (keywordTokens.length === 0) return 0;
  const tokens = tokenize(zoneText);
  if (countSequence(tokens, keywordTokens) > 0) return 2;
  const meaningful = keywordTokens.filter((t) => !stopwords.has(t));
  const required = meaningful.length ? meaningful : keywordTokens;
  const present = new Set(tokens.map(stripAccents));
  return required.every((t) => present.has(stripAccents(t))) ? 1 : 0;
}

function maxZone(
  texts: string[],
  keywordTokens: string[],
  stopwords: ReadonlySet<string>,
): ZonePresence {
  let best: ZonePresence = 0;
  for (const text of texts) {
    const value = zonePresence(text, keywordTokens, stopwords);
    if (value > best) best = value;
  }
  return best;
}

function top<T extends { count: number }>(entries: T[], limit: number): T[] {
  const sorted = [...entries];
  sorted.sort((a, b) => b.count - a.count);
  return sorted.slice(0, limit);
}

export function analyzeDraft(input: DraftInput) {
  const doc = parseHtmlDraft(input.html);
  const tokens = tokenize(doc.bodyText);
  const language = detectLanguage(tokens, input.languageCode);
  const stopwords = stopwordsFor(language);
  const totalWords = tokens.length;

  const sentenceLengths = doc.bodyText
    .split(/[.!?…]+/)
    .map((s) => tokenize(s).length)
    .filter((n) => n >= 3);
  const avgSentence = sentenceLengths.length
    ? sentenceLengths.reduce((a, b) => a + b, 0) / sentenceLengths.length
    : 0;

  const keywordTokens = tokenize(input.keyword);
  const occurrences = countSequence(tokens, keywordTokens);
  const density = totalWords ? (occurrences * 100) / totalWords : 0;

  const h1 = doc.headings.find((h) => h.level === 1)?.text;
  const h2s = doc.headings.filter((h) => h.level === 2).map((h) => h.text);
  const h3s = doc.headings.filter((h) => h.level === 3).map((h) => h.text);

  const zones = {
    titleTag: zonePresence(input.title, keywordTokens, stopwords),
    h1: zonePresence(h1 ?? input.title, keywordTokens, stopwords),
    h2: maxZone(h2s, keywordTokens, stopwords),
    h3: maxZone(h3s, keywordTokens, stopwords),
    firstParagraph: zonePresence(
      doc.paragraphs[0] ?? "",
      keywordTokens,
      stopwords,
    ),
    meta: zonePresence(input.meta, keywordTokens, stopwords),
    slug: zonePresence(input.slug.replace(/-/g, " "), keywordTokens, stopwords),
  };

  const ngrams = countNgrams(tokens, stopwords);
  const pct = (count: number) => (totalWords ? (count * 100) / totalWords : 0);
  const topWords = top(
    [...ngrams.words].map(([word, count]) => ({
      word,
      count,
      pct: pct(count),
    })),
    5,
  );
  const repeated = (map: Map<string, number>) =>
    top(
      [...map]
        .filter(([, count]) => count >= 2)
        .map(([phrase, count]) => ({ phrase, count })),
      5,
    );

  const longParagraphs = doc.paragraphs.filter(
    (p) => tokenize(p).length > 100,
  ).length;

  return {
    totalWords,
    readingMinutes: Math.max(1, Math.round(totalWords / 220)),
    avgSentence,
    longSentences: sentenceLengths.filter((n) => n > 30).length,
    keyword: { value: input.keyword.trim(), occurrences, density, zones },
    topWords,
    topBigrams: repeated(ngrams.bigrams),
    topTrigrams: repeated(ngrams.trigrams),
    structure: {
      h1: doc.headings.filter((h) => h.level === 1).length,
      h2: h2s.length,
      h3: h3s.length,
      paragraphs: doc.paragraphs.length,
      lists: doc.lists.length,
      listItems: doc.listItems,
      tables: doc.tables,
      threeItemLists: doc.lists.filter((n) => n === 3).length,
      images: doc.images,
      longParagraphs,
    },
    tokens,
    stopwords,
  };
}

export type DraftAnalysis = ReturnType<typeof analyzeDraft>;

export type TermComparison = SemanticBriefTerm & {
  /** Occurrences in the draft. */
  yours: number;
  covered: boolean;
};

export type ScorePart = {
  key: "keyword" | "zones" | "terms" | "length" | "structure";
  label: string;
  points: number;
  max: number;
  hint: string;
};

export type BriefComparison = {
  terms: TermComparison[];
  missingTerms: TermComparison[];
  /** 0..1, weighted by how many competitor pages use each term. */
  termCoverage: number;
  /** Score and status of the whole lexical field (chart header). */
  lexical: LexicalScore;
  /** Draft length / median competitor length. */
  lengthRatio: number | null;
};

/** Only the most widely shared terms count toward the score. */
const TERM_SCORE_CAP = 60;

/**
 * Compares a text with the lexical field when the number of uses of each term
 * is already known (the competitor pages are scored this way, from the counts
 * of the read pages, without scanning their text again).
 */
export function compareWithCounts(
  terms: TermComparison[],
  totalWords: number,
  medianWords: number | null,
): BriefComparison {
  const scored = terms.slice(0, TERM_SCORE_CAP);
  // Most widely shared first, whatever the number of words.
  const byImportance = [...terms];
  byImportance.sort((a, b) => b.pages - a.pages || b.avgCount - a.avgCount);
  const totalWeight = scored.reduce((sum, t) => sum + t.pages, 0);
  const coveredWeight = scored
    .filter((t) => t.covered)
    .reduce((sum, t) => sum + t.pages, 0);
  return {
    terms,
    missingTerms: terms.filter((t) => !t.covered),
    termCoverage: totalWeight ? coveredWeight / totalWeight : 0,
    lexical: lexicalScore(byImportance),
    lengthRatio: medianWords ? totalWords / medianWords : null,
  };
}

export function compareWithBrief(
  analysis: DraftAnalysis,
  brief: SemanticBrief,
): BriefComparison {
  const terms = brief.terms.map<TermComparison>((term) => {
    const yours = countSequence(analysis.tokens, tokenize(term.term));
    return { ...term, yours, covered: yours > 0 };
  });
  return compareWithCounts(terms, analysis.totalWords, brief.medianWords);
}

function densityPoints(density: number, max: number): number {
  if (density <= 0) return 0;
  if (density >= 0.5 && density <= 2.5) return max;
  if (density < 0.5) return Math.round((density / 0.5) * max);
  // Over-optimised: lose points progressively up to 5 %.
  return Math.max(0, Math.round(max * (1 - (density - 2.5) / 2.5)));
}

function zonePoints(value: ZonePresence): number {
  if (value === 2) return 4;
  return value === 1 ? 2 : 0;
}

/**
 * 0-100 score. Without a SERP brief only the on-page parts count and the
 * score is rescaled, so a draft is never penalised for a brief not loaded yet.
 */
export function scoreDraft(
  analysis: DraftAnalysis,
  brief: SemanticBrief | null,
  comparison: BriefComparison | null,
): { score: number; parts: ScorePart[]; hasBrief: boolean } {
  const kw = analysis.keyword;
  const parts: ScorePart[] = [];

  parts.push({
    key: "keyword",
    label: "Densité du mot-clé",
    max: 15,
    points: kw.value ? densityPoints(kw.density, 15) : 0,
    hint: "Visez entre 0,5 % et 2,5 % du texte.",
  });

  const zoneValues: ZonePresence[] = [
    kw.zones.h1,
    kw.zones.firstParagraph,
    kw.zones.titleTag,
    kw.zones.meta,
    kw.zones.h2 >= kw.zones.h3 ? kw.zones.h2 : kw.zones.h3,
  ];
  parts.push({
    key: "zones",
    label: "Zones stratégiques",
    max: 20,
    points: kw.value
      ? zoneValues.reduce<number>((sum, z) => sum + zonePoints(z), 0)
      : 0,
    hint: "Mot-clé dans le H1, la balise title, la méta, le premier paragraphe et un sous-titre.",
  });

  const s = analysis.structure;
  let structurePoints = 0;
  if (s.h1 === 1) structurePoints += 4;
  if (s.h2 >= 3) structurePoints += 4;
  else if (s.h2 >= 1) structurePoints += 2;
  if (s.longParagraphs === 0 && s.paragraphs > 0) structurePoints += 4;
  if (analysis.avgSentence > 0 && analysis.avgSentence <= 24) {
    structurePoints += 3;
  }
  parts.push({
    key: "structure",
    label: "Structure et lisibilité",
    max: 15,
    points: structurePoints,
    hint: "Un seul H1, au moins 3 H2, paragraphes courts (mobile), phrases sous 24 mots.",
  });

  if (brief && comparison) {
    parts.push({
      key: "terms",
      label: "Optimisation du champ lexical",
      max: 35,
      points: Math.round((comparison.lexical.score * 35) / 100),
      hint: "Mots du champ lexical employés aussi souvent que sur les pages qui se positionnent (voir le diagramme).",
    });
    const ratio = comparison.lengthRatio;
    parts.push({
      key: "length",
      label: "Longueur face au top",
      max: 15,
      points: ratio === null ? 0 : Math.round(Math.min(1, ratio) * 15),
      hint: "Rapportée à la longueur médiane des pages concurrentes.",
    });
  }

  const max = parts.reduce((sum, p) => sum + p.max, 0);
  const points = parts.reduce((sum, p) => sum + p.points, 0);
  return {
    score: max ? Math.round((points * 100) / max) : 0,
    parts,
    hasBrief: brief !== null,
  };
}

/** Competitor H2s whose meaningful words your draft barely touches. */
export function uncoveredSubtopics(
  analysis: DraftAnalysis,
  brief: SemanticBrief,
): { heading: string; domain: string }[] {
  const draftWords = new Set(
    analysis.tokens
      .filter((t) => t.length >= 4 && !analysis.stopwords.has(t))
      .map(stripAccents),
  );
  const seen = new Set<string>();
  const result: { heading: string; domain: string }[] = [];
  for (const page of brief.pages) {
    for (const heading of page.h2) {
      const words = tokenize(heading).filter(
        (t) => t.length >= 4 && !analysis.stopwords.has(t),
      );
      if (words.length === 0) continue;
      const hit = words.filter((w) => draftWords.has(stripAccents(w))).length;
      const key = words.map(stripAccents).join(" ");
      if (hit / words.length < 0.5 && !seen.has(key)) {
        seen.add(key);
        result.push({ heading, domain: page.domain });
      }
    }
  }
  return result.slice(0, 12);
}
