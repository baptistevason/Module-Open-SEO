import { describe, expect, it } from "vitest";
import {
  lexicalScore,
  quantile,
  termBands,
  termDistribution,
  zoneFor,
} from "./bands";
import { parseStoredBrief } from "./brief-schema";

describe("termDistribution", () => {
  it("counts the pages that do not use the term as zeros", () => {
    const d = termDistribution([3, 5, 9, 1, 2, 3], 8);
    // sorted: 0 0 1 2 3 3 5 9
    expect(d.max).toBe(9);
    expect(d.median).toBe(2.5);
    expect(d.q1).toBe(0.8);
    expect(d.q3).toBe(3.5);
  });

  it("handles a single page", () => {
    expect(termDistribution([4], 1)).toEqual({
      q1: 4,
      median: 4,
      q3: 4,
      max: 4,
    });
  });
});

describe("quantile", () => {
  it("interpolates between neighbours", () => {
    expect(quantile([1, 2, 3, 4], 0.5)).toBe(2.5);
    expect(quantile([], 0.5)).toBe(0);
  });
});

describe("termBands and zoneFor", () => {
  const bands = termBands({ q1: 0.8, q3: 3.5, max: 9 });

  it("builds ordered zones that always leave room above the maximum", () => {
    expect(bands).toEqual({ from: 1, to: 4, strongTo: 9, top: 12 });
    expect(termBands({ q1: 0, q3: 0, max: 0 }).top).toBeGreaterThan(
      termBands({ q1: 0, q3: 0, max: 0 }).strongTo,
    );
  });

  it("classifies a count", () => {
    expect(zoneFor(0, bands)).toBe("under");
    expect(zoneFor(1, bands)).toBe("normal");
    expect(zoneFor(4, bands)).toBe("normal");
    expect(zoneFor(6, bands)).toBe("strong");
    expect(zoneFor(10, bands)).toBe("over");
  });
});

describe("parseStoredBrief", () => {
  it("drops a brief without zone statistics (older shape)", () => {
    const old = JSON.stringify({
      keyword: "x",
      languageCode: "fr",
      locationCode: 2250,
      fetchedAt: "2026-10-20T00:00:00.000Z",
      pagesRead: 1,
      pagesRequested: 1,
      pages: [],
      medianWords: null,
      avgH2: null,
      avgH3: null,
      avgImages: null,
      terms: [{ term: "a", kind: "word", pages: 1, avgCount: 1 }],
    });
    expect(parseStoredBrief(old)).toBeNull();
    expect(parseStoredBrief("not json")).toBeNull();
    expect(parseStoredBrief(null)).toBeNull();
  });
});

describe("lexicalScore", () => {
  // One term used by every page: normal range 4-8, strong up to 12, over beyond.
  const term = { q1: 4, q3: 8, max: 12, pages: 8 };
  const field = (yours: number[]) => yours.map((y) => ({ ...term, yours: y }));

  it("is optimised when the content stays in the normal range", () => {
    const result = lexicalScore(field([5, 6, 7, 8, 4, 5, 6, 7, 5, 6]));
    expect(result.score).toBe(100);
    expect(result.status).toBe("optimized");
    expect(result.counts.normal).toBe(10);
  });

  it("is under-optimised when words are missing or too rare", () => {
    const result = lexicalScore(field([0, 0, 1, 2, 5, 0, 0, 3, 0, 6]));
    expect(result.status).toBe("under");
    expect(result.score).toBeLessThan(80);
    expect(result.overCount).toBe(0);
  });

  it("is over-optimised when too many words pass the maximum", () => {
    const result = lexicalScore(field([20, 25, 30, 6, 6, 6, 6, 6, 6, 6]));
    expect(result.counts.over).toBe(3);
    expect(result.overTolerance).toBe(1);
    expect(result.status).toBe("over");
  });

  it("tolerates a single over-used word", () => {
    const result = lexicalScore(field([20, 6, 6, 6, 6, 6, 6, 6, 6, 6]));
    expect(result.overCount).toBe(1);
    expect(result.status).not.toBe("over");
  });

  it("scores an empty field as under-optimised", () => {
    expect(lexicalScore([])).toMatchObject({ score: 0, status: "under" });
  });
});
