// Targets drawn from the ranking pages (how many words, headings, images,
// videos, links…) and the draft's position against them. The targets are
// benchmarks from the pages read, not rules: no study shows that a number of
// images or videos ranks a page by itself.
import type { ParsedDraft } from "./html";
import { parseHtmlDraft } from "./html";
import { quantile } from "./bands";
import { countWords } from "./geo";
import {
  BRIEF_METRIC_KEYS,
  type BriefMetricKey,
  type BriefTargets,
  type MetricTarget,
} from "./types";

export type MetricCounts = Record<BriefMetricKey, number>;

/** A paragraph is a prose block of at least this many words. */
export const PARAGRAPH_MIN_WORDS = 12;

const OUTLIER_HIGH = 2.5;
const OUTLIER_LOW = 0.35;
const MIN_PAGES_FOR_OUTLIERS = 5;
const MIN_SECTIONS_FOR_RATE = 2;

export function hostOf(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

/** Splits links into internal (same site) and external (another site). */
export function countLinks(
  hrefs: string[],
  host: string | null,
): { internal: number; external: number } {
  let internal = 0;
  let external = 0;
  for (const raw of hrefs) {
    const href = raw.trim();
    if (
      !href ||
      href.startsWith("#") ||
      /^(mailto|tel|javascript):/i.test(href)
    ) {
      continue;
    }
    if (href.startsWith("/")) {
      internal++;
    } else if (/^https?:\/\//i.test(href)) {
      if (host !== null && hostOf(href) === host) internal++;
      else external++;
    }
  }
  return { internal, external };
}

const round = (value: number) => Math.round(value);
const roundTo = (value: number, step: number) =>
  Math.round(value / step) * step;

function sortedAscending(values: number[]): number[] {
  const sorted = [...values];
  sorted.sort((a, b) => a - b);
  return sorted;
}

function distribution(values: number[], step: number): MetricTarget {
  const sorted = [...values];
  sorted.sort((a, b) => a - b);
  return {
    min: roundTo(sorted[0] ?? 0, step),
    q1: roundTo(quantile(sorted, 0.25), step),
    median: roundTo(quantile(sorted, 0.5), step),
    q3: roundTo(quantile(sorted, 0.75), step),
    max: roundTo(sorted.at(-1) ?? 0, step),
    pagesWith: sorted.filter((v) => v > 0).length,
  };
}

type PageCounts = { metrics: MetricCounts };

/**
 * One target per metric from the pages read. Pages whose length is an outlier
 * (far longer or shorter than the median) are left out of every target: a
 * giant guide or a thin category page would skew them all.
 */
export function computeTargets(pages: PageCounts[]): BriefTargets {
  const words = pages.map((p) => p.metrics.words);
  const sortedWords = [...words];
  sortedWords.sort((a, b) => a - b);
  const median = quantile(sortedWords, 0.5);
  const kept =
    pages.length >= MIN_PAGES_FOR_OUTLIERS
      ? pages.filter(
          (p) =>
            p.metrics.words <= median * OUTLIER_HIGH &&
            p.metrics.words >= median * OUTLIER_LOW,
        )
      : pages;
  const used = kept.length > 0 ? kept : pages;

  const spread = (key: BriefMetricKey) =>
    distribution(
      used.map((p) => p.metrics[key]),
      key === "words" ? 10 : 1,
    );
  const metrics: Record<BriefMetricKey, MetricTarget> = {
    words: spread("words"),
    h2: spread("h2"),
    h3: spread("h3"),
    paragraphs: spread("paragraphs"),
    images: spread("images"),
    videos: spread("videos"),
    tables: spread("tables"),
    lists: spread("lists"),
    bold: spread("bold"),
    internalLinks: spread("internalLinks"),
    externalLinks: spread("externalLinks"),
  };

  const rates = used
    .filter((p) => p.metrics.h2 >= MIN_SECTIONS_FOR_RATE)
    .map((p) => p.metrics.words / p.metrics.h2);
  return {
    metrics,
    wordsPerSection:
      rates.length >= 2
        ? roundTo(quantile(sortedAscending(rates), 0.5), 10)
        : null,
    outliers: pages.length - used.length,
  };
}

/** The counts of a draft, measured like the pages read. */
export function draftCounts(
  html: string,
  pageUrl: string,
  totalWords: number,
): { counts: MetricCounts; doc: ParsedDraft } {
  const doc = parseHtmlDraft(html);
  const links = countLinks(
    doc.links.map((l) => l.href),
    hostOf(pageUrl),
  );
  const counts: MetricCounts = {
    words: totalWords,
    h2: doc.headings.filter((h) => h.level === 2).length,
    h3: doc.headings.filter((h) => h.level === 3).length,
    paragraphs: doc.paragraphs.filter(
      (p) => countWords(p) >= PARAGRAPH_MIN_WORDS,
    ).length,
    images: doc.images,
    videos: doc.videos,
    tables: doc.tables,
    lists: doc.lists.length,
    bold: doc.bold,
    internalLinks: links.internal,
    externalLinks: links.external,
  };
  return { counts, doc };
}

export type TargetStatus = "below" | "within" | "above";

export type TargetRow = {
  key: BriefMetricKey;
  yours: number;
  target: MetricTarget;
  /** Recommended range: the middle half of the pages. */
  low: number;
  high: number;
  status: TargetStatus;
  /** Units to add to reach the low end of the range (0 when not below). */
  missing: number;
};

export function targetRow(
  key: BriefMetricKey,
  yours: number,
  target: MetricTarget,
): TargetRow {
  const low = Math.floor(target.q1);
  const high = Math.max(low, Math.ceil(target.q3));
  let status: TargetStatus = "within";
  if (yours < low) status = "below";
  else if (yours > high) status = "above";
  return {
    key,
    yours,
    target,
    low,
    high,
    status,
    missing: status === "below" ? low - yours : 0,
  };
}

export function buildTargetRows(
  counts: MetricCounts,
  targets: BriefTargets,
): TargetRow[] {
  return BRIEF_METRIC_KEYS.map((key) =>
    targetRow(key, counts[key], targets.metrics[key]),
  );
}

/** Word count of each H2 section of the draft (text up to the next H1/H2). */
export function sectionWords(
  html: string,
): { heading: string; words: number }[] {
  const { blocks } = parseHtmlDraft(html);
  const sections: { heading: string; words: number }[] = [];
  let current: { heading: string; words: number } | null = null;
  for (const block of blocks) {
    if (block.kind === "h1" || block.kind === "h2") {
      current = block.kind === "h2" ? { heading: block.text, words: 0 } : null;
      if (current) sections.push(current);
      continue;
    }
    if (current) current.words += countWords(block.text);
  }
  return sections.map((s) => ({ ...s, words: round(s.words) }));
}
