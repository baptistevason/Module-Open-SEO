export type SemanticTermKind = "word" | "bigram" | "trigram";

/** A term the top-ranking pages share, with how widely and how often. */
export type SemanticBriefTerm = {
  term: string;
  kind: SemanticTermKind;
  /** How many of the read pages use the term. */
  pages: number;
  /** Mean occurrences per page, over the pages that use it. */
  avgCount: number;
  /**
   * Occurrences per page across ALL the read pages (zero where the term is
   * absent): lower quartile, median, upper quartile and maximum. They draw
   * the optimisation zones of the lexical-field chart.
   */
  q1: number;
  median: number;
  q3: number;
  max: number;
};

/** What is counted on a page, to give the draft a target for each. */
export const BRIEF_METRIC_KEYS = [
  "words",
  "h2",
  "h3",
  "paragraphs",
  "images",
  "videos",
  "tables",
  "lists",
  "bold",
  "internalLinks",
  "externalLinks",
] as const;
export type BriefMetricKey = (typeof BRIEF_METRIC_KEYS)[number];

/** Spread of one metric across the ranking pages. */
export type MetricTarget = {
  min: number;
  q1: number;
  median: number;
  q3: number;
  max: number;
  /** How many of the read pages have at least one. */
  pagesWith: number;
};

export type BriefTargets = {
  metrics: Record<BriefMetricKey, MetricTarget>;
  /** Median words per H2 section, null when pages have too few sections. */
  wordsPerSection: number | null;
  /** Pages left out of the length target because their length is an outlier. */
  outliers: number;
};

/** Median readability of the ranking pages. */
export type BriefReadability = {
  flesch: number;
  avgSentence: number;
  longSentenceShare: number;
  passiveShare: number;
};

/** The score of each ranking page, computed like the draft's score. */
export type BriefScoreTarget = {
  median: number;
  min: number;
  max: number;
  scores: { rank: number; domain: string; score: number }[];
};

export type SemanticBriefPage = {
  rank: number;
  url: string;
  domain: string;
  title: string;
  words: number;
  h2Count: number;
  h3Count: number;
  imageCount: number;
  /** H2 headings, capped, for the sub-topic comparison. */
  h2: string[];
  /** Counts used for the targets; absent on briefs saved before they existed. */
  metrics?: Record<BriefMetricKey, number>;
  /** Score of this page with the draft's method; absent on older briefs. */
  score?: number;
};

export type SemanticBrief = {
  keyword: string;
  languageCode: string;
  locationCode: number;
  fetchedAt: string;
  /** Pages that were actually read (the rest were blocked or unreadable). */
  pagesRead: number;
  pagesRequested: number;
  pages: SemanticBriefPage[];
  medianWords: number | null;
  avgH2: number | null;
  avgH3: number | null;
  avgImages: number | null;
  terms: SemanticBriefTerm[];
  /** Absent on briefs saved before the targets existed: analyse again. */
  targets?: BriefTargets;
  readability?: BriefReadability;
  scoreTarget?: BriefScoreTarget;
};

/**
 * Expected failures (unreadable page, no SERP results) come back as data: the
 * client only ever receives a bare error code, never a server message.
 */
export type SemanticResult<T> =
  | ({ ok: true } & T)
  | { ok: false; message: string };

export const FACT_STATUSES = [
  "confirme",
  "a_sourcer",
  "incorrect",
  "obsolete",
  "non_verifiable",
] as const;
export type FactStatus = (typeof FACT_STATUSES)[number];

export type FactCheckClaim = {
  quote: string;
  claim: string;
  status: FactStatus;
  explanation: string;
  source: { title: string; url: string } | null;
  suggestion: string | null;
  /** Whether the quote could be located in the text (for highlighting). */
  found: boolean;
};

export type OutgoingLink = {
  url: string;
  title: string;
  anchor: string;
  reason: string;
};

export type IncomingLinkSuggestion = {
  url: string;
  title: string;
  sentence: string;
  anchor: string;
  newSentence: string;
  reason: string;
  /** Whether the sentence really exists on the page. */
  found: boolean;
};

export type CannibalPage = {
  page: string;
  clicks: number;
  impressions: number;
  position: number;
};

export type CannibalizationResult =
  | { connected: false }
  | {
      connected: true;
      startDate: string;
      endDate: string;
      pages: CannibalPage[];
    };

export type PeriodTotals = {
  startDate: string;
  endDate: string;
  clicks: number;
  impressions: number;
  /** Impression-weighted average position, 0 when there were no impressions. */
  position: number;
};

export type AfterPublishResult =
  | { connected: false }
  | { connected: true; status: "no_url" }
  | { connected: true; status: "too_early"; daysLeft: number }
  | {
      connected: true;
      status: "ready";
      windowDays: number;
      before: PeriodTotals;
      after: PeriodTotals;
      /** The target keyword on this page only, when a keyword is set. */
      keywordBefore: PeriodTotals | null;
      keywordAfter: PeriodTotals | null;
    };
