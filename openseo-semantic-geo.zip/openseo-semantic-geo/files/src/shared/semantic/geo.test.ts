import { describe, expect, it } from "vitest";
import { z } from "zod";
import {
  analyzeGeo,
  buildArticleSchema,
  buildFaqSchema,
  countWords,
  extractFaq,
  wrapJsonLd,
} from "./geo";
import { parseHtmlDraft } from "./html";

const words = (n: number) => Array.from({ length: n }, () => "mot").join(" ");

const GOOD = [
  "<h1>Dogue de Majorque</h1>",
  `<p>${words(55)}</p>`,
  "<h2>Origine de la race</h2>",
  `<p>${words(30)}</p>`,
  "<h2>Caractère</h2>",
  `<p>${words(30)} en 2024, 80 % des maîtres le confirment, selon <a href="https://exemple.org/etude">une étude</a>.</p>`,
  "<ul><li><p>un</p></li><li><p>deux</p></li></ul>",
  "<h2>Questions fréquentes</h2>",
  "<h3>Quelle est son espérance de vie ?</h3>",
  `<p>${words(20)}</p>`,
  "<h3>Est-il adapté aux familles ?</h3>",
  `<p>${words(20)}</p>`,
  "<h3>Combien coûte-t-il ?</h3>",
  `<p>${words(20)}</p>`,
  "<p>Article rédigé par un vétérinaire, mis à jour en 2026.</p>",
].join("");

function status(html: string, id: string) {
  return analyzeGeo(html).checks.find((c) => c.id === id)?.status;
}

describe("parseHtmlDraft blocks and links", () => {
  it("keeps document order and the anchor text of links", () => {
    const doc = parseHtmlDraft(
      '<h2>Titre</h2><p>Voir <a href="https://a.fr/x">cette page</a>.</p>',
    );
    expect(doc.blocks.map((b) => b.kind)).toEqual(["h2", "p"]);
    expect(doc.links).toEqual([{ href: "https://a.fr/x", text: "cette page" }]);
  });
});

describe("analyzeGeo", () => {
  it("accepts a well structured content", () => {
    const geo = analyzeGeo(GOOD);
    expect(status(GOOD, "blurb")).toBe("ok");
    expect(status(GOOD, "answer-first")).toBe("ok");
    expect(status(GOOD, "faq")).toBe("ok");
    expect(status(GOOD, "structure")).toBe("ok");
    expect(status(GOOD, "author")).toBe("ok");
    expect(geo.passed).toBeGreaterThanOrEqual(6);
  });

  it("flags an introduction that is too long or too short", () => {
    expect(status(`<h1>T</h1><p>${words(120)}</p><h2>A</h2>`, "blurb")).toBe(
      "warn",
    );
    expect(status(`<h1>T</h1><p>${words(10)}</p><h2>A</h2>`, "blurb")).toBe(
      "warn",
    );
    expect(status("<h1>T</h1><h2>A</h2><p>x</p>", "blurb")).toBe("fail");
  });

  it("fails sections that do not start with an answer", () => {
    const html = `<h2>A</h2><h3>Sous</h3><p>${words(30)}</p><h2>B</h2><ul><li>x</li></ul>`;
    expect(status(html, "answer-first")).toBe("fail");
  });

  it("fails figures without any external source", () => {
    const html = `<p>10 % des chiens.</p><p>En 2020, 5 ans.</p><p>20 kg en moyenne.</p>`;
    expect(status(html, "sources")).toBe("fail");
  });

  it("reports a missing FAQ", () => {
    expect(status(`<h2>A</h2><p>${words(30)}</p>`, "faq")).toBe("fail");
  });
});

describe("FAQ extraction and schema", () => {
  const faq = extractFaq(parseHtmlDraft(GOOD).blocks);

  it("pairs each question heading with its answer", () => {
    expect(faq).toHaveLength(3);
    expect(faq[0].question).toBe("Quelle est son espérance de vie ?");
    expect(countWords(faq[0].answer)).toBe(20);
  });

  it("builds a valid FAQPage JSON-LD", () => {
    const schema = z
      .object({
        "@type": z.literal("FAQPage"),
        mainEntity: z.array(
          z.object({
            "@type": z.literal("Question"),
            name: z.string(),
            acceptedAnswer: z.object({ "@type": z.literal("Answer") }),
          }),
        ),
      })
      .parse(JSON.parse(buildFaqSchema(faq)));
    expect(schema.mainEntity).toHaveLength(3);
  });

  it("escapes angle brackets so the script tag cannot be closed early", () => {
    const out = buildFaqSchema([{ question: "A ?", answer: "</script><b>" }]);
    expect(out).not.toContain("</script>");
    expect(
      wrapJsonLd(out).startsWith('<script type="application/ld+json">'),
    ).toBe(true);
  });

  it("omits empty Article fields", () => {
    const json: unknown = JSON.parse(
      buildArticleSchema({
        headline: "T",
        description: "",
        url: "",
        datePublished: null,
        dateModified: "2026-10-20",
      }),
    );
    expect(json).toEqual({
      "@context": "https://schema.org",
      "@type": "Article",
      headline: "T",
      dateModified: "2026-10-20",
    });
  });
});
