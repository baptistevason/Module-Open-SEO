// Types of the GEO module (optimisation for generative engines: ChatGPT,
// Perplexity, Gemini, Copilot, AI Overviews). A checklist of controls, some
// evaluated automatically, some from the published page, some by an LLM and
// the rest ticked by hand, rolled up into one score.

export type GeoStatus = "ok" | "warn" | "fail" | "todo";

/** Where the status of a control comes from. */
export type GeoSource = "auto" | "live" | "llm" | "manual";

/** How a control is evaluated. */
export type GeoMode = "auto" | "live" | "llm" | "manual";

export type GeoScope = "page" | "site";

export type GeoBlockId =
  | "structure"
  | "format"
  | "schema"
  | "authenticity"
  | "eeat"
  | "readability"
  | "seo"
  | "final"
  | "architecture"
  | "sources"
  | "measure";

export type GeoBlock = {
  id: GeoBlockId;
  scope: GeoScope;
  label: string;
  /** One line on why the block matters for generative engines. */
  intro: string;
};

export type GeoCheckDef = {
  id: string;
  block: GeoBlockId;
  scope: GeoScope;
  /** Number in the numbered GEO checklist, when it has one. */
  ref?: string;
  label: string;
  /** Why it matters, shown as help text. */
  why: string;
  /** 1 = minor, 2 = normal, 3 = major. Priority controls weigh most. */
  weight: 1 | 2 | 3;
  priority?: boolean;
  mode: GeoMode;
  /** Another OpenSEO page that helps with this control. */
  tool?: {
    label: string;
    path:
      | "ai-visibility"
      | "backlinks"
      | "audit"
      | "search-performance"
      | "semantic";
  };
};

export type GeoCheckResult = {
  id: string;
  status: GeoStatus;
  detail: string;
  source: GeoSource;
};

/** What an LLM said about one control it is able to judge. */
export type GeoLlmCheck = {
  status: Exclude<GeoStatus, "todo">;
  note: string;
};

export type EeatAxis = "experience" | "expertise" | "authority" | "trust";

export type GeoEeatDiagnosis = Record<
  EeatAxis,
  { score: number; evidence: string; advice: string }
>;

export type GeoLlmAnalysis = {
  analyzedAt: string;
  /** Overall quality as a generative engine would perceive it, out of 20. */
  score: number;
  summary: string;
  eeat: GeoEeatDiagnosis;
  checks: Record<string, GeoLlmCheck>;
  recommendations: { priority: 1 | 2 | 3; text: string }[];
};

/** Facts read from the published page, fetched and parsed on the server. */
export type GeoLiveFacts = {
  url: string;
  fetchedAt: string;
  title: string;
  metaDescription: string;
  canonical: string | null;
  lang: string | null;
  hreflangs: string[];
  ogTitle: boolean;
  ogDescription: boolean;
  ogImage: boolean;
  twitterCard: boolean;
  jsonLdTypes: string[];
  jsonLdAuthor: boolean;
  jsonLdDatePublished: boolean;
  jsonLdDateModified: boolean;
  hasBreadcrumb: boolean;
  hasPublisher: boolean;
  metaAuthor: boolean;
  imageCount: number;
  imagesMissingAlt: number;
  hasTimeTag: boolean;
  readingTimeShown: boolean;
  wordCount: number;
  tableCount: number;
};

/** What OpenSEO already knows about the project, for the site-level checks. */
export type GeoSiteFacts = {
  gscConnected: boolean;
  ga4Connected: boolean;
  tracker: {
    enabled: boolean;
    engines: number;
    interval: "daily" | "weekly" | "monthly";
    promptCount: number;
  } | null;
};
