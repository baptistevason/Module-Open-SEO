import { countWords } from "../semantic/geo";
import { countSequence, stopwordsFor, tokenize } from "../semantic/text";
import {
  AUTHOR_TEXT,
  CONTENT_SCHEMAS,
  CTA,
  NEEDS_KEYWORD,
  externalLinks,
  fail,
  firstParagraph,
  h2Sections,
  internalLinks,
  ok,
  openingTokens,
  passiveShare,
  todo,
  warn,
  type Outcome,
  type PageFacts,
} from "./evalFacts";
import {
  factsOutcome,
  freshnessOutcome,
  headingOutcome,
  metaOutcome,
  titleOutcome,
  urlOutcome,
} from "./evalOutcomes";

type Evaluator = (f: PageFacts) => Outcome | null;

const evaluators: Record<string, Evaluator> = {
  "inverted-pyramid": (f) => {
    const intro = firstParagraph(f);
    if (!intro) return fail("Aucun paragraphe d’introduction.");
    const words = countWords(intro);
    // A one-line opening cannot hold the answer, whatever it contains.
    if (words < 25) {
      return (words < 10 ? fail : warn)(
        `Introduction de ${words} mots : trop courte pour répondre à la question (visez 40 à 90 mots).`,
      );
    }
    const early = openingTokens(f, 90);
    const keywordEarly =
      f.keywordTokens.length === 0 || countSequence(early, f.keywordTokens) > 0;
    if (words <= 90 && keywordEarly) {
      return ok(
        `Introduction de ${words} mots${f.keywordTokens.length ? ", mot-clé dans les 90 premiers mots" : ""}.`,
      );
    }
    const problems = [
      words > 90 ? `introduction de ${words} mots (visez 90 au maximum)` : null,
      keywordEarly ? null : "mot-clé absent des 90 premiers mots",
    ].filter(Boolean);
    return (words > 120 ? fail : warn)(`${problems.join(" ; ")}.`);
  },
  "intro-summary": (f) => {
    const intro = firstParagraph(f);
    if (!intro) return fail("Aucun paragraphe d’introduction.");
    const words = countWords(intro);
    if (words >= 40 && words <= 80)
      return ok(
        `${words} mots : un passage assez court pour être repris tel quel.`,
      );
    const near = (words >= 30 && words < 40) || (words > 80 && words <= 100);
    return (near ? warn : fail)(
      `Introduction de ${words} mots : visez 40 à 80.`,
    );
  },
  "modular-sections": (f) => {
    const { total, weak } = h2Sections(f);
    if (total === 0)
      return fail("Aucun sous-titre H2 : structurez le contenu en sections.");
    const ratio = (total - weak) / total;
    const detail = `${total - weak} / ${total} sections commencent par une réponse directe de 15 à 90 mots.`;
    if (total >= 3 && ratio >= 0.8) return ok(detail);
    return (ratio >= 0.5 && total >= 2 ? warn : fail)(
      total < 3 ? `${detail} Prévoyez au moins 3 sections.` : detail,
    );
  },
  "short-paragraphs": (f) => {
    const paragraphs = f.doc.paragraphs;
    if (paragraphs.length === 0) return fail("Aucun paragraphe.");
    const short = paragraphs.filter((p) => countWords(p) <= 90).length;
    const ratio = short / paragraphs.length;
    const detail = `${short} / ${paragraphs.length} paragraphes de 90 mots ou moins.`;
    if (ratio >= 0.9) return ok(detail);
    return (ratio >= 0.7 ? warn : fail)(detail);
  },
  "informative-titles": (f) => {
    const titles = f.doc.headings.filter((h) => h.level === 2 || h.level === 3);
    if (titles.length === 0) return fail("Aucun intertitre.");
    const stop = stopwordsFor(f.ctx.languageCode);
    const meaningful = f.keywordTokens.filter((t) => !stop.has(t));
    const withKeyword = meaningful.length
      ? titles.filter((t) =>
          tokenize(t.text).some((w) => meaningful.includes(w)),
        ).length
      : null;
    const avgWords =
      titles.reduce((n, t) => n + countWords(t.text), 0) / titles.length;
    if (avgWords < 3)
      return warn("Intertitres trop courts : dites de quoi parle la section.");
    if (withKeyword === null)
      return ok(
        `${titles.length} intertitres informatifs (renseignez le mot-clé pour vérifier leur optimisation).`,
      );
    const share = withKeyword / titles.length;
    const detail = `${withKeyword} / ${titles.length} intertitres reprennent le mot-clé.`;
    if (share >= 1 / 3) return ok(detail);
    return (withKeyword > 0 ? warn : fail)(detail);
  },
  "keyword-h1-intro": (f) => {
    if (!f.ctx.keyword.trim()) return todo(NEEDS_KEYWORD);
    const { h1, firstParagraph: intro } = f.analysis.keyword.zones;
    if (h1 === 2 && intro >= 1)
      return ok("Mot-clé dans le H1 et le premier paragraphe.");
    if (h1 === 0 && intro === 0)
      return fail("Mot-clé absent du H1 et du premier paragraphe.");
    return warn(
      `Mot-clé ${h1 === 2 ? "présent" : "absent ou partiel"} dans le H1, ${intro >= 1 ? "présent" : "absent"} dans le premier paragraphe.`,
    );
  },
  lists: (f) =>
    f.doc.lists.length > 0
      ? ok(`${f.doc.lists.length} liste(s) en HTML natif.`)
      : warn(
          "Aucune liste : utilisez-en une pour les étapes ou les énumérations.",
        ),
  tables: (f) =>
    f.doc.tables > 0
      ? ok(`${f.doc.tables} tableau(x) en HTML natif.`)
      : warn("Aucun tableau : ajoutez-en un pour comparer."),
  callouts: (f) =>
    f.doc.quotes > 0
      ? ok(`${f.doc.quotes} encadré(s) ou citation(s).`)
      : warn("Aucun encadré ni citation pour les messages clés."),
  "bold-terms": (f) =>
    f.doc.bold >= 3
      ? ok(`${f.doc.bold} passages en gras.`)
      : warn(
          `${f.doc.bold} passage(s) en gras : mettez les notions importantes en valeur.`,
        ),
  "heading-hierarchy": headingOutcome,
  "image-alt": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    if (live.imageCount === 0) return ok("Aucune image sur la page.");
    if (live.imagesMissingAlt === 0)
      return ok(`${live.imageCount} image(s), toutes avec un alt.`);
    const detail = `${live.imagesMissingAlt} image(s) sur ${live.imageCount} sans alt.`;
    return (live.imagesMissingAlt / live.imageCount > 0.5 ? fail : warn)(
      detail,
    );
  },
  "schema-type": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    const types = live.jsonLdTypes;
    if (types.some((t) => CONTENT_SCHEMAS.has(t.toLowerCase())))
      return ok(`Schema détecté : ${types.join(", ")}.`);
    if (types.length > 0)
      return warn(
        `Seulement ${types.join(", ")} : ajoutez un schema du type de contenu (Article, FAQPage, HowTo…).`,
      );
    return fail("Aucun schema JSON-LD sur la page.");
  },
  "jsonld-present": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    return live.jsonLdTypes.length > 0
      ? ok(`${live.jsonLdTypes.length} type(s) de JSON-LD.`)
      : fail("Aucun JSON-LD sur la page.");
  },
  "schema-fields": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    const present = [
      live.jsonLdAuthor,
      live.jsonLdDatePublished,
      live.jsonLdDateModified,
    ].filter(Boolean).length;
    const detail = `Auteur ${live.jsonLdAuthor ? "présent" : "absent"}, date de publication ${live.jsonLdDatePublished ? "présente" : "absente"}, date de mise à jour ${live.jsonLdDateModified ? "présente" : "absente"}.`;
    if (present === 3) return ok(detail);
    return (present >= 2 ? warn : fail)(detail);
  },
  "breadcrumb-publisher": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    const detail = `Fil d’Ariane ${live.hasBreadcrumb ? "présent" : "absent"}, publisher ${live.hasPublisher ? "présent" : "absent"}.`;
    if (live.hasBreadcrumb && live.hasPublisher) return ok(detail);
    return (live.hasBreadcrumb || live.hasPublisher ? warn : fail)(detail);
  },
  author: (f) => {
    const live = f.ctx.live;
    if (live && (live.jsonLdAuthor || live.metaAuthor))
      return { status: "ok", detail: "Auteur déclaré dans la page publiée." };
    if (AUTHOR_TEXT.test(f.doc.bodyText)) {
      return warn(
        "Un auteur ou une relecture est mentionné dans le texte : déclarez-le aussi dans le schema.",
      );
    }
    return fail(
      live
        ? "Aucun auteur déclaré sur la page publiée ni dans le texte."
        : "Aucun auteur détecté dans le texte (analysez la page publiée pour vérifier le schema).",
    );
  },
  "external-sources": (f) => {
    const n = externalLinks(f);
    if (n >= 2) return ok(`${n} lien(s) externe(s) vers des sources.`);
    return (n === 1 ? warn : fail)(
      `${n} lien externe : citez au moins 2 sources fiables.`,
    );
  },
  "verifiable-facts": factsOutcome,
  "active-voice": (f) => {
    const { share, total } = passiveShare(f);
    if (total < 5) return todo("Texte trop court pour estimer la voix active.");
    const detail = `Environ ${Math.round(share * 100)} % de phrases au passif (estimation).`;
    if (share <= 0.2) return ok(detail);
    return (share <= 0.35 ? warn : fail)(detail);
  },
  "short-sentences": (f) => {
    const avg = f.analysis.avgSentence;
    if (avg === 0) return todo("Texte trop court pour mesurer les phrases.");
    const detail = `Phrase moyenne : ${Math.round(avg)} mots.`;
    if (avg <= 20) return ok(detail);
    return (avg <= 24 ? warn : fail)(`${detail} Visez moins de 20.`);
  },
  "reading-time": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    return live.readingTimeShown
      ? ok("Un temps de lecture est affiché.")
      : warn("Aucun temps de lecture affiché sur la page.");
  },
  "keyword-zones": (f) => {
    if (!f.ctx.keyword.trim()) return todo(NEEDS_KEYWORD);
    const z = f.analysis.keyword.zones;
    const hits = [
      z.h1,
      z.titleTag,
      z.meta,
      z.firstParagraph,
      Math.max(z.h2, z.h3),
    ].filter((v) => v === 2).length;
    const detail = `Mot-clé exact dans ${hits} zone(s) sur 5 (H1, title, méta, premier paragraphe, sous-titre).`;
    if (hits >= 4) return ok(detail);
    return (hits === 3 ? warn : fail)(detail);
  },
  "meta-title": titleOutcome,
  "meta-description": metaOutcome,
  "clean-url": urlOutcome,
  "internal-linking": (f) => {
    const n = internalLinks(f);
    const detail = `${n} lien(s) interne(s) dans le contenu.`;
    if (n >= 3)
      return ok(
        `${detail} Vérifiez aussi les liens entrants depuis les autres pages du cluster.`,
      );
    return (n >= 1 ? warn : fail)(
      `${detail} Reliez la page aux articles de son cluster.`,
    );
  },
  "final-cta": (f) => {
    const tail = f.doc.blocks
      .filter((b) => b.kind === "p" || b.kind === "li")
      .slice(-3);
    if (tail.length === 0) return fail("Aucun contenu.");
    return tail.some((b) => CTA.test(b.text))
      ? ok("Un appel à l’action figure en fin de contenu.")
      : warn("Aucun appel à l’action clair en fin de contenu.");
  },
  "og-twitter": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    const all =
      live.ogTitle && live.ogDescription && live.ogImage && live.twitterCard;
    const some =
      live.ogTitle || live.ogDescription || live.ogImage || live.twitterCard;
    const detail = `Open Graph : titre ${live.ogTitle ? "oui" : "non"}, description ${live.ogDescription ? "oui" : "non"}, image ${live.ogImage ? "oui" : "non"} ; Twitter card ${live.twitterCard ? "oui" : "non"}.`;
    if (all) return ok(detail);
    return (some ? warn : fail)(detail);
  },
  freshness: freshnessOutcome,
  "english-version": (f) => {
    const live = f.ctx.live;
    if (!live) return null;
    if (live.lang?.toLowerCase().startsWith("en"))
      return ok("La page est en anglais.");
    if (live.hreflangs.some((h) => h.toLowerCase().startsWith("en")))
      return ok("Une version anglaise est déclarée (hreflang).");
    return warn("Aucune version anglaise déclarée (hreflang) pour cette page.");
  },
};

/** Outcome of an automatic evaluator, or null when it cannot be told. */
export function evaluatePageCheck(
  id: string,
  facts: PageFacts,
): Outcome | null {
  return evaluators[id]?.(facts) ?? null;
}
