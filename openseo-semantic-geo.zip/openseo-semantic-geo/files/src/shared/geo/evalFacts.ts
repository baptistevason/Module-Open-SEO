// Automatic evaluators of the page-level GEO controls. Each one looks at the
// draft (editor HTML and SEO fields) and, when available, at the facts read
// from the published page. A null outcome means "cannot be told from here":
// the control then falls back to the LLM analysis or to a manual tick.
import { analyzeDraft, type DraftAnalysis } from "../semantic/analyze";
import { countWords } from "../semantic/geo";
import { parseHtmlDraft, type ParsedDraft } from "../semantic/html";
import { passiveShareOfText } from "../semantic/readability";
import { tokenize } from "../semantic/text";
import type { GeoLiveFacts, GeoStatus } from "./types";

export type Outcome = { status: GeoStatus; detail: string };

export type PageContext = {
  html: string;
  title: string;
  meta: string;
  slug: string;
  keyword: string;
  pageUrl: string;
  languageCode: string;
  publishedAt: string | null;
  updatedAt: string | null;
  live: GeoLiveFacts | null;
  now: number;
};

export type PageFacts = {
  ctx: PageContext;
  doc: ParsedDraft;
  analysis: DraftAnalysis;
  keywordTokens: string[];
  host: string | null;
};

export const DAY_MS = 24 * 60 * 60 * 1000;

export function hostOf(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

export function buildFacts(ctx: PageContext): PageFacts {
  return {
    ctx,
    doc: parseHtmlDraft(ctx.html),
    analysis: analyzeDraft({
      title: ctx.title,
      meta: ctx.meta,
      slug: ctx.slug,
      html: ctx.html,
      keyword: ctx.keyword,
      languageCode: ctx.languageCode,
    }),
    keywordTokens: tokenize(ctx.keyword),
    host: hostOf(ctx.pageUrl),
  };
}

export const ok = (detail: string): Outcome => ({ status: "ok", detail });
export const warn = (detail: string): Outcome => ({ status: "warn", detail });
export const fail = (detail: string): Outcome => ({ status: "fail", detail });
export const todo = (detail: string): Outcome => ({ status: "todo", detail });

export const NEEDS_KEYWORD =
  "Renseignez le mot-clé principal pour évaluer ce point.";

export function firstParagraph(f: PageFacts): string | undefined {
  return f.doc.blocks.find((b) => b.kind === "p")?.text;
}

/** The first `limit` words of prose, as tokens. */
export function openingTokens(f: PageFacts, limit: number): string[] {
  const prose = f.doc.blocks
    .filter((b) => b.kind === "p")
    .map((b) => b.text)
    .join(" ");
  return tokenize(prose).slice(0, limit);
}

export const FIGURE =
  /\d[\d\s.,]*\s?(?:%|€|(?:euros?|ans?|kg|cm|mm|ml|jours?|mois|semaines?|fois)\b)|\b(?:19|20)\d{2}\b/i;
export const YEAR = /\b(?:19|20)\d{2}\b/;
export const EXAMPLE =
  /par exemple|exemple|cas concret|en pratique|concrètement|notamment/i;
export const AUTHOR_TEXT =
  /rédigé par|écrit par|relu par|vérifié par|auteur\s*:|par\s+(?:le\s+|la\s+)?(?:dr\.?|docteur|vétérinaire|expert)/i;
export const CTA =
  /contactez|découvrez|téléchargez|inscrivez|demandez|réservez|essayez|commandez|appelez|consultez|rejoignez|abonnez|testez|lisez|en savoir plus|cliquez|devis/i;
export const CONTENT_SCHEMAS = new Set([
  "article",
  "blogposting",
  "newsarticle",
  "howto",
  "faqpage",
  "product",
  "recipe",
  "review",
  "course",
  "event",
  "localbusiness",
  "service",
  "qapage",
  "videoobject",
]);

export function passiveShare(f: PageFacts): { share: number; total: number } {
  return passiveShareOfText(f.doc.bodyText);
}

export function h2Sections(f: PageFacts): { total: number; weak: number } {
  const blocks = f.doc.blocks;
  let total = 0;
  let weak = 0;
  for (let i = 0; i < blocks.length; i++) {
    if (blocks[i].kind !== "h2") continue;
    if (/\bfaq\b|questions?\s+(?:fréquentes?|courantes?)/i.test(blocks[i].text))
      continue;
    total++;
    const next = blocks[i + 1];
    const words = next && next.kind === "p" ? countWords(next.text) : 0;
    if (words < 15 || words > 90) weak++;
  }
  return { total, weak };
}

export function internalLinks(f: PageFacts): number {
  return f.doc.links.filter((l) => {
    const href = l.href.trim();
    if (!href || href.startsWith("#") || /^(mailto|tel):/i.test(href))
      return false;
    if (href.startsWith("/")) return true;
    return f.host !== null && hostOf(href) === f.host;
  }).length;
}

export function externalLinks(f: PageFacts): number {
  return f.doc.links.filter((l) => {
    if (!/^https?:\/\//i.test(l.href)) return false;
    return f.host === null || hostOf(l.href) !== f.host;
  }).length;
}
