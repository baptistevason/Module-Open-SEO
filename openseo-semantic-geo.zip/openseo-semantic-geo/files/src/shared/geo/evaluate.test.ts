import { describe, expect, it } from "vitest";
import { GEO_ALL_CHECKS, GEO_BLOCKS } from "./catalog";
import {
  evaluatePage,
  evaluateSite,
  scoreResults,
  type PageContext,
} from "./evaluate";
import type { GeoLiveFacts } from "./types";

const filler = (n: number) =>
  Array.from({ length: n }, (_, i) => (i % 2 ? "chien" : "race")).join(" ");

const GOOD_HTML = [
  "<h1>Dogue de Majorque : guide complet</h1>",
  `<p>Le dogue de majorque est une race de gardien calme. ${filler(52)}.</p>`,
  "<h2>Origine</h2>",
  `<p>${filler(30)}. Par exemple en 2024, 80 % des éleveurs le confirment.</p>`,
  "<h2>Caractère</h2>",
  `<p>${filler(30)}. <a href="https://www.fci.be/x">FCI</a> et <a href="https://exemple.org/y">étude</a>.</p>`,
  "<blockquote><p>Une phrase à retenir.</p></blockquote>",
  "<h2>Soins</h2>",
  `<p>${filler(30)} <strong>santé</strong>, <strong>poids</strong>, <strong>soins</strong>.</p>`,
  "<ul><li><p>un</p></li><li><p>deux</p></li></ul>",
  "<table><tr><td>a</td></tr></table>",
  `<p>Voir <a href="/races/mastiff">les mastiffs</a>, <a href="/races/cane-corso">le cane corso</a> et <a href="/guides/education">l’éducation</a>.</p>`,
  "<p>Rédigé par Dr Martin, vétérinaire. Contactez-nous pour un conseil.</p>",
].join("");

const LIVE: GeoLiveFacts = {
  url: "https://exemple.fr/dogue-de-majorque",
  fetchedAt: "2026-10-20T00:00:00.000Z",
  title: "Dogue de Majorque : guide complet de la race",
  metaDescription: filler(65),
  canonical: null,
  lang: "fr",
  hreflangs: ["en"],
  ogTitle: true,
  ogDescription: true,
  ogImage: true,
  twitterCard: true,
  jsonLdTypes: ["Article", "BreadcrumbList"],
  jsonLdAuthor: true,
  jsonLdDatePublished: true,
  jsonLdDateModified: true,
  hasBreadcrumb: true,
  hasPublisher: true,
  metaAuthor: true,
  imageCount: 3,
  imagesMissingAlt: 0,
  hasTimeTag: true,
  readingTimeShown: true,
  wordCount: 600,
  tableCount: 1,
};

const NOW = Date.parse("2026-10-20T00:00:00Z");

function context(overrides: Partial<PageContext> = {}): PageContext {
  return {
    html: GOOD_HTML,
    title: "Dogue de Majorque : guide complet de la race",
    meta: filler(65),
    slug: "dogue-de-majorque",
    keyword: "dogue de majorque",
    pageUrl: "https://exemple.fr/dogue-de-majorque",
    languageCode: "fr",
    publishedAt: "2026-09-20T00:00:00.000Z",
    updatedAt: "2026-09-20T00:00:00.000Z",
    live: LIVE,
    now: NOW,
    ...overrides,
  };
}

function status(results: ReturnType<typeof evaluatePage>, id: string) {
  return results.find((r) => r.id === id)?.status;
}

describe("catalog", () => {
  it("gives every control a known block and a unique id", () => {
    const blocks = new Set(GEO_BLOCKS.map((b) => b.id));
    const ids = new Set<string>();
    for (const check of GEO_ALL_CHECKS) {
      expect(blocks.has(check.block)).toBe(true);
      expect(ids.has(check.id)).toBe(false);
      ids.add(check.id);
    }
  });
});

describe("evaluatePage", () => {
  it("scores a well built page high", () => {
    const results = evaluatePage(context(), null, {});
    expect(status(results, "intro-summary")).toBe("ok");
    expect(status(results, "inverted-pyramid")).toBe("ok");
    expect(status(results, "lists")).toBe("ok");
    expect(status(results, "tables")).toBe("ok");
    expect(status(results, "heading-hierarchy")).toBe("ok");
    expect(status(results, "meta-title")).toBe("ok");
    expect(status(results, "schema-type")).toBe("ok");
    expect(status(results, "author")).toBe("ok");
    expect(status(results, "internal-linking")).toBe("ok");
    expect(status(results, "clean-url")).toBe("ok");
    expect(status(results, "freshness")).toBe("ok");
    expect(scoreResults(results).score).toBeGreaterThan(55);
  });

  it("flags a weak page", () => {
    const results = evaluatePage(
      context({
        html: `<p>${filler(200)}</p>`,
        title: "Titre",
        meta: "",
        live: null,
        slug: "Mon_Article",
        pageUrl: "",
      }),
      null,
      {},
    );
    expect(status(results, "intro-summary")).toBe("fail");
    expect(status(results, "short-paragraphs")).toBe("fail");
    expect(status(results, "heading-hierarchy")).toBe("fail");
    expect(status(results, "meta-title")).toBe("fail");
    expect(status(results, "meta-description")).toBe("fail");
    expect(status(results, "clean-url")).toBe("warn");
    expect(status(results, "schema-type")).toBe("todo");
    expect(scoreResults(results).tone).toBe("bad");
  });

  it("needs the published page for the checks that read it", () => {
    const results = evaluatePage(context({ live: null }), null, {});
    expect(status(results, "image-alt")).toBe("todo");
    expect(status(results, "og-twitter")).toBe("todo");
  });

  it("warns when the page was modified after it went live", () => {
    const results = evaluatePage(
      context({ updatedAt: "2026-10-10T00:00:00.000Z" }),
      null,
      {},
    );
    expect(status(results, "freshness")).toBe("warn");
  });

  it("flags a title with an acronym and no developed form", () => {
    const results = evaluatePage(
      context({ live: null, title: "Les règles du RGPD pour votre site web" }),
      null,
      {},
    );
    expect(results.find((r) => r.id === "meta-title")?.detail).toContain(
      "sigle",
    );
  });

  it("takes the LLM verdict for a judgement control, and a tick over everything", () => {
    const llm = {
      experience: { status: "warn" as const, note: "Peu de vécu." },
    };
    const withLlm = evaluatePage(context(), llm, {});
    expect(withLlm.find((r) => r.id === "experience")).toMatchObject({
      status: "warn",
      source: "llm",
    });
    const ticked = evaluatePage(context(), llm, { experience: true });
    expect(ticked.find((r) => r.id === "experience")).toMatchObject({
      status: "ok",
      source: "manual",
    });
  });
});

describe("evaluateSite", () => {
  it("reads what OpenSEO already knows about the project", () => {
    const connected = evaluateSite(
      {
        gscConnected: true,
        ga4Connected: false,
        tracker: {
          enabled: true,
          engines: 4,
          interval: "daily",
          promptCount: 12,
        },
      },
      {},
    );
    expect(status(connected, "tracked-queries")).toBe("ok");
    expect(status(connected, "webmaster-tools")).toBe("warn");
    expect(status(connected, "ai-sessions")).toBe("fail");
    const none = evaluateSite(
      { gscConnected: false, ga4Connected: false, tracker: null },
      { "webmaster-tools": true },
    );
    expect(status(none, "tracked-queries")).toBe("fail");
    expect(status(none, "webmaster-tools")).toBe("ok");
  });
});

describe("scoreResults", () => {
  it("weighs priority controls and reports the blocks", () => {
    const score = scoreResults([
      { id: "inverted-pyramid", status: "ok", detail: "", source: "auto" },
      { id: "memorable", status: "fail", detail: "", source: "manual" },
    ]);
    // weights 3 (ok) and 1 (fail): 75.
    expect(score.score).toBe(75);
    expect(score.blocks.map((b) => b.id)).toEqual(["structure", "final"]);
    expect(score.counts).toMatchObject({ ok: 1, fail: 1 });
  });
});

describe("answer in the first words", () => {
  it("does not count a one-line opening as an answer", () => {
    const results = evaluatePage(
      context({
        html: `<h1>Dogue de Majorque</h1><p>Un article de Wikipédia.</p><h2>Origine</h2><p>${filler(40)}</p>`,
        live: null,
      }),
      null,
      {},
    );
    expect(status(results, "inverted-pyramid")).toBe("fail");
  });
});
