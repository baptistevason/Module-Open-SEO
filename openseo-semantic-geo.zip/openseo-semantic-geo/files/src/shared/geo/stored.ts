import { z } from "zod";
import type { GeoLiveFacts, GeoLlmAnalysis } from "./types";

// Safe readers for the GEO state stored as JSON text with each content. A value
// that does not match the current shape is dropped, so the page simply asks
// for the analysis again.

const liveSchema = z.object({
  url: z.string(),
  fetchedAt: z.string(),
  title: z.string(),
  metaDescription: z.string(),
  canonical: z.string().nullable(),
  lang: z.string().nullable(),
  hreflangs: z.array(z.string()),
  ogTitle: z.boolean(),
  ogDescription: z.boolean(),
  ogImage: z.boolean(),
  twitterCard: z.boolean(),
  jsonLdTypes: z.array(z.string()),
  jsonLdAuthor: z.boolean(),
  jsonLdDatePublished: z.boolean(),
  jsonLdDateModified: z.boolean(),
  hasBreadcrumb: z.boolean(),
  hasPublisher: z.boolean(),
  metaAuthor: z.boolean(),
  imageCount: z.number(),
  imagesMissingAlt: z.number(),
  hasTimeTag: z.boolean(),
  readingTimeShown: z.boolean(),
  wordCount: z.number(),
  tableCount: z.number(),
});

const axisSchema = z.object({
  score: z.number(),
  evidence: z.string(),
  advice: z.string(),
});

const llmSchema = z.object({
  analyzedAt: z.string(),
  score: z.number(),
  summary: z.string(),
  eeat: z.object({
    experience: axisSchema,
    expertise: axisSchema,
    authority: axisSchema,
    trust: axisSchema,
  }),
  checks: z.record(
    z.string(),
    z.object({ status: z.enum(["ok", "warn", "fail"]), note: z.string() }),
  ),
  recommendations: z.array(
    z.object({
      priority: z.union([z.literal(1), z.literal(2), z.literal(3)]),
      text: z.string(),
    }),
  ),
});

const checksSchema = z.record(z.string(), z.boolean());

function parseJson(raw: string | null | undefined): unknown {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function parseStoredLive(
  raw: string | null | undefined,
): GeoLiveFacts | null {
  const parsed = liveSchema.safeParse(parseJson(raw));
  return parsed.success ? parsed.data : null;
}

export function parseStoredLlm(
  raw: string | null | undefined,
): GeoLlmAnalysis | null {
  const parsed = llmSchema.safeParse(parseJson(raw));
  return parsed.success ? parsed.data : null;
}

export function parseStoredChecks(
  raw: string | null | undefined,
): Record<string, boolean> {
  const parsed = checksSchema.safeParse(parseJson(raw));
  return parsed.success ? parsed.data : {};
}
