import { GEO_PAGE_CHECKS_A } from "./catalogPageA";
import { GEO_PAGE_CHECKS_B } from "./catalogPageB";
import { GEO_SITE_CHECKS } from "./catalogSite";
import type { GeoBlock, GeoCheckDef } from "./types";

// The GEO checklist: the categories and tasks of the "Checklist GEO" sheet,
// plus the numbered controls 18 to 40 (page, external sources, measurement).

export const GEO_BLOCKS: GeoBlock[] = [
  {
    id: "structure",
    scope: "page",
    label: "Structure claire et modulaire",
    intro:
      "Un modèle extrait un passage, pas une page : chaque section doit répondre seule, dès les premiers mots.",
  },
  {
    id: "format",
    scope: "page",
    label: "Format lisible et structuré",
    intro:
      "Listes, tableaux et hiérarchie en HTML natif : c’est ce qu’un modèle sait lire et reprendre.",
  },
  {
    id: "schema",
    scope: "page",
    label: "Données structurées",
    intro:
      "Le balisage relie la page à son auteur, sa date et son type de contenu, donc à la bonne entité.",
  },
  {
    id: "authenticity",
    scope: "page",
    label: "Authenticité et valeur humaine",
    intro:
      "Ce qu’une IA ne peut pas produire seule est ce qui mérite d’être cité.",
  },
  {
    id: "eeat",
    scope: "page",
    label: "E-E-A-T",
    intro:
      "Expérience, expertise, autorité, confiance : des faits vérifiables et des auteurs nommés sont la matière première d’une citation.",
  },
  {
    id: "readability",
    scope: "page",
    label: "Accessibilité et lisibilité",
    intro:
      "Un style clair, actif et court est plus facile à comprendre et à citer.",
  },
  {
    id: "seo",
    scope: "page",
    label: "SEO et UX",
    intro:
      "Les bases du référencement restent le point d’entrée : title, méta, URL, maillage, balises de partage.",
  },
  {
    id: "final",
    scope: "page",
    label: "Objectif final",
    intro: "Compréhensible par une IA, mémorable pour un humain.",
  },
  {
    id: "architecture",
    scope: "site",
    label: "Architecture du site",
    intro:
      "Les pages qui portent votre positionnement doivent être faciles à atteindre.",
  },
  {
    id: "sources",
    scope: "site",
    label: "Sources externes",
    intro:
      "Les modèles citent rarement votre site directement : ils citent des sources tierces qui parlent de vous.",
  },
  {
    id: "measure",
    scope: "site",
    label: "Mesure",
    intro:
      "Sans mesure de la visibilité, une stratégie GEO devient une suite d’intuitions.",
  },
];

export const GEO_CHECKS: GeoCheckDef[] = [
  ...GEO_PAGE_CHECKS_A,
  ...GEO_PAGE_CHECKS_B,
];

export const GEO_ALL_CHECKS: GeoCheckDef[] = [
  ...GEO_CHECKS,
  ...GEO_SITE_CHECKS,
];

export const GEO_CHECK_BY_ID = new Map(GEO_ALL_CHECKS.map((c) => [c.id, c]));

/** Ids the LLM is asked to judge. */
export const GEO_LLM_CHECK_IDS = GEO_ALL_CHECKS.filter(
  (c) => c.mode === "llm",
).map((c) => c.id);
