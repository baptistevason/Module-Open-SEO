import { GEO_ALL_CHECKS, GEO_BLOCKS, GEO_CHECKS } from "./catalog";
import { GEO_SITE_CHECKS } from "./catalogSite";
import { buildFacts, type Outcome, type PageContext } from "./evalFacts";
import { evaluatePageCheck } from "./evalPage";
import type {
  GeoBlockId,
  GeoCheckDef,
  GeoCheckResult,
  GeoLlmCheck,
  GeoSiteFacts,
  GeoStatus,
} from "./types";

export type { PageContext } from "./evalFacts";

/** Hand-ticked controls: id -> validated. */
export type GeoManual = Record<string, boolean>;

function todoDetail(def: GeoCheckDef): string {
  if (def.mode === "live") {
    return "Renseignez l’URL puis analysez la page publiée, ou validez à la main.";
  }
  if (def.mode === "llm") {
    return "Lancez l’analyse IA, ou validez à la main.";
  }
  return "À valider à la main.";
}

/**
 * Status of one control. A hand tick always wins (the author checked it), then
 * the automatic outcome, then the LLM verdict, then "to do".
 */
function resolve(
  def: GeoCheckDef,
  outcome: Outcome | null,
  llm: Record<string, GeoLlmCheck> | null,
  manual: GeoManual,
): GeoCheckResult {
  if (manual[def.id]) {
    return {
      id: def.id,
      status: "ok",
      detail: "Validé à la main.",
      source: "manual",
    };
  }
  if (outcome && outcome.status !== "todo") {
    return {
      id: def.id,
      status: outcome.status,
      detail: outcome.detail,
      source: def.mode === "live" ? "live" : "auto",
    };
  }
  const fromLlm = llm?.[def.id];
  if (def.mode === "llm" && fromLlm) {
    return {
      id: def.id,
      status: fromLlm.status,
      detail: fromLlm.note,
      source: "llm",
    };
  }
  return {
    id: def.id,
    status: "todo",
    detail: outcome?.detail ?? todoDetail(def),
    source: def.mode === "manual" ? "manual" : def.mode,
  };
}

export function evaluatePage(
  ctx: PageContext,
  llm: Record<string, GeoLlmCheck> | null,
  manual: GeoManual,
): GeoCheckResult[] {
  const facts = buildFacts(ctx);
  return GEO_CHECKS.map((def) =>
    resolve(def, evaluatePageCheck(def.id, facts), llm, manual),
  );
}

const ok = (detail: string): Outcome => ({ status: "ok", detail });
const warn = (detail: string): Outcome => ({ status: "warn", detail });
const fail = (detail: string): Outcome => ({ status: "fail", detail });

function siteOutcome(id: string, facts: GeoSiteFacts | null): Outcome | null {
  if (!facts) return null;
  if (id === "tracked-queries") {
    const t = facts.tracker;
    if (!t)
      return fail("Aucun suivi de prompts : créez-le dans Prompt Tracking.");
    if (!t.enabled)
      return fail("Le suivi de prompts existe mais il est désactivé.");
    const detail = `${t.promptCount} prompt(s) sur ${t.engines} moteur(s), vérification ${
      t.interval === "daily"
        ? "quotidienne"
        : t.interval === "weekly"
          ? "hebdomadaire"
          : "mensuelle"
    }.`;
    if (t.promptCount >= 5 && t.engines >= 3 && t.interval === "daily")
      return ok(detail);
    return warn(
      `${detail} Visez un suivi quotidien sur au moins 3 moteurs et 5 prompts.`,
    );
  }
  if (id === "webmaster-tools") {
    return facts.gscConnected
      ? warn(
          "Search Console est connectée. Confirmez Bing Webmaster Tools en cochant la case.",
        )
      : fail("Search Console n’est pas connectée à ce projet.");
  }
  if (id === "ai-sessions") {
    return facts.ga4Connected
      ? warn(
          "Google Analytics est connecté. Cochez la case une fois les référents IA (chatgpt.com, perplexity.ai, gemini.google.com) isolés.",
        )
      : fail("Google Analytics n’est pas connecté à ce projet.");
  }
  return null;
}

export function evaluateSite(
  facts: GeoSiteFacts | null,
  manual: GeoManual,
): GeoCheckResult[] {
  return GEO_SITE_CHECKS.map((def) =>
    resolve(def, siteOutcome(def.id, facts), null, manual),
  );
}

// --- Score -------------------------------------------------------------------

export type GeoTone = "good" | "mid" | "bad";

export type GeoBlockScore = {
  id: GeoBlockId;
  label: string;
  /** 0-100 over the controls of the block. */
  score: number;
  total: number;
  done: number;
};

export type GeoScore = {
  /** 0-100, weighted by the importance of each control. */
  score: number;
  label: string;
  tone: GeoTone;
  blocks: GeoBlockScore[];
  counts: Record<GeoStatus, number>;
};

const POINTS: Record<GeoStatus, number> = {
  ok: 1,
  warn: 0.5,
  fail: 0,
  todo: 0,
};
export const GEO_TARGET_SCORE = 80;
const MID_SCORE = 55;

const TONE_LABEL: Record<GeoTone, string> = {
  good: "Optimisé GEO",
  mid: "Correct, à renforcer",
  bad: "À retravailler",
};

/** Weighted score of the results of one scope (page or site). */
export function scoreResults(results: GeoCheckResult[]): GeoScore {
  const defs = new Map(GEO_ALL_CHECKS.map((d) => [d.id, d]));
  const counts: Record<GeoStatus, number> = {
    ok: 0,
    warn: 0,
    fail: 0,
    todo: 0,
  };
  let weighted = 0;
  let weights = 0;
  const perBlock = new Map<
    GeoBlockId,
    { weighted: number; weights: number; total: number; done: number }
  >();

  for (const result of results) {
    const def = defs.get(result.id);
    if (!def) continue;
    counts[result.status]++;
    weighted += POINTS[result.status] * def.weight;
    weights += def.weight;
    const block = perBlock.get(def.block) ?? {
      weighted: 0,
      weights: 0,
      total: 0,
      done: 0,
    };
    block.weighted += POINTS[result.status] * def.weight;
    block.weights += def.weight;
    block.total++;
    if (result.status === "ok") block.done++;
    perBlock.set(def.block, block);
  }

  const score = weights ? Math.round((weighted * 100) / weights) : 0;
  const tone: GeoTone =
    score >= GEO_TARGET_SCORE ? "good" : score >= MID_SCORE ? "mid" : "bad";
  const blocks: GeoBlockScore[] = GEO_BLOCKS.filter((b) =>
    perBlock.has(b.id),
  ).map((b) => {
    const data = perBlock.get(b.id);
    return {
      id: b.id,
      label: b.label,
      score:
        data && data.weights
          ? Math.round((data.weighted * 100) / data.weights)
          : 0,
      total: data?.total ?? 0,
      done: data?.done ?? 0,
    };
  });
  return { score, label: TONE_LABEL[tone], tone, blocks, counts };
}
