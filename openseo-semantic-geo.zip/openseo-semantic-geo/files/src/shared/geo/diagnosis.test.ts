import { describe, expect, it } from "vitest";
import type { ScorePart } from "../semantic/analyze";
import { GEO_CHECKS } from "./catalog";
import { buildDiagnosis, GEO_FIXES } from "./diagnosis";
import type { GeoCheckResult, GeoLlmAnalysis } from "./types";

const result = (
  id: string,
  status: GeoCheckResult["status"],
  detail = "",
): GeoCheckResult => ({ id, status, detail, source: "auto" });

const part = (
  key: ScorePart["key"],
  points: number,
  max: number,
): ScorePart => ({ key, label: key, points, max, hint: `Conseil ${key}` });

const axis = (score: number) => ({
  score,
  evidence: "preuve",
  advice: "conseil",
});

describe("GEO_FIXES", () => {
  it("gives a directive to every page control", () => {
    for (const check of GEO_CHECKS) {
      expect(GEO_FIXES[check.id], check.id).toBeTruthy();
    }
  });
});

describe("buildDiagnosis", () => {
  it("separates strengths from weaknesses and sorts the weaknesses by gravity", () => {
    const diagnosis = buildDiagnosis({
      geoResults: [
        result("lists", "ok"),
        result("inverted-pyramid", "fail", "6 mots"),
        result("tables", "warn"),
        result("author", "fail"),
        result("lead-image", "todo"),
      ],
      seoParts: [part("keyword", 15, 15), part("structure", 3, 15)],
      llm: null,
    });
    expect(diagnosis.strengths.map((s) => s.id)).toEqual(
      expect.arrayContaining(["geo-lists", "seo-keyword"]),
    );
    // Failures first, the heaviest control first (a priority control counts one more).
    expect(diagnosis.weaknesses.map((w) => w.id).slice(0, 2)).toEqual([
      "geo-inverted-pyramid",
      "geo-author",
    ]);
    expect(diagnosis.weaknesses.map((w) => w.id)).toContain("seo-structure");
    expect(
      diagnosis.weaknesses.find((w) => w.id === "geo-tables")?.severity,
    ).toBe("warn");
    expect(diagnosis.weaknesses[0].fix).toBe(GEO_FIXES["inverted-pyramid"]);
    expect(diagnosis.pending).toBe(1);
  });

  it("ignores the site-level controls", () => {
    const diagnosis = buildDiagnosis({
      geoResults: [result("cited-sources", "fail")],
      seoParts: [],
      llm: null,
    });
    expect(diagnosis.weaknesses).toHaveLength(0);
    expect(diagnosis.pending).toBe(0);
  });

  it("adds the E-E-A-T axes of an AI analysis", () => {
    const llm: GeoLlmAnalysis = {
      analyzedAt: "2026-10-20T00:00:00.000Z",
      score: 12,
      summary: "",
      eeat: {
        experience: axis(5),
        expertise: axis(3),
        authority: axis(1),
        trust: axis(2),
      },
      checks: {},
      recommendations: [],
    };
    const diagnosis = buildDiagnosis({ geoResults: [], seoParts: [], llm });
    expect(diagnosis.strengths.map((s) => s.id)).toEqual(["ia-experience"]);
    expect(diagnosis.weaknesses.map((w) => w.id)).toEqual([
      "ia-authority",
      "ia-trust",
    ]);
    expect(diagnosis.weaknesses[0].fix).toBe("conseil");
  });

  it("caps the lists", () => {
    const geoResults = GEO_CHECKS.filter((c) => c.scope === "page").map((c) =>
      result(c.id, "fail"),
    );
    const diagnosis = buildDiagnosis({ geoResults, seoParts: [], llm: null });
    expect(diagnosis.weaknesses).toHaveLength(7);
    expect(diagnosis.strengths).toHaveLength(0);
  });
});
