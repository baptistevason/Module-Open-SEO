import { countSequence, tokenize } from "../semantic/text";
import {
  AUTHOR_TEXT,
  DAY_MS,
  EXAMPLE,
  FIGURE,
  YEAR,
  externalLinks,
  fail,
  ok,
  todo,
  warn,
  type Outcome,
  type PageFacts,
} from "./evalFacts";

export function titleOutcome(f: PageFacts): Outcome {
  const live = f.ctx.live?.title.trim();
  const title = live || f.ctx.title.trim();
  if (!title) return fail("Aucun title renseigné.");
  const length = title.length;
  const where = live ? "Title de la page publiée" : "Title du brouillon";
  const hasKeyword =
    f.keywordTokens.length === 0 ||
    countSequence(tokenize(title), f.keywordTokens) > 0;
  const acronym = /\b[A-Z]{2,6}\b/.test(title) && !title.includes("(");
  const problems: string[] = [];
  if (length < 40 || length > 60)
    problems.push(`${length} caractères (visez 40 à 60)`);
  if (!hasKeyword) problems.push("les termes exacts du mot-clé sont absents");
  if (acronym)
    problems.push("un sigle sans sa forme développée entre parenthèses");
  if (problems.length === 0)
    return ok(`${where} : ${length} caractères, termes exacts présents.`);
  const severe = length < 30 || length > 75 || !hasKeyword;
  return (severe ? fail : warn)(`${where} : ${problems.join(" ; ")}.`);
}

export function metaOutcome(f: PageFacts): Outcome {
  const live = f.ctx.live?.metaDescription.trim();
  const meta = live || f.ctx.meta.trim();
  const where = live ? "Méta de la page publiée" : "Méta du brouillon";
  if (!meta) return fail("Aucune méta description.");
  const title = (f.ctx.live?.title || f.ctx.title).trim();
  if (title && meta.toLowerCase() === title.toLowerCase()) {
    return fail(
      "La méta description est identique au title : rédigez-en une qui décrit la page.",
    );
  }
  const length = meta.length;
  if (length >= 130 && length <= 155)
    return ok(`${where} : ${length} caractères.`);
  const severe = length < 90 || length > 180;
  return (severe ? fail : warn)(
    `${where} : ${length} caractères (visez 130 à 150).`,
  );
}

export function urlOutcome(f: PageFacts): Outcome | null {
  let path = "";
  if (f.ctx.pageUrl) {
    try {
      const url = new URL(f.ctx.pageUrl);
      if (url.search) return warn("L’URL contient des paramètres.");
      path = url.pathname.replace(/^\/|\/$/g, "");
    } catch {
      return warn("L’URL de la page n’est pas valide.");
    }
  } else if (f.ctx.slug) {
    path = f.ctx.slug;
  } else {
    return todo("Renseignez le slug ou l’URL de la page.");
  }
  if (!path) return ok("Page d’accueil.");
  if (path.length > 75)
    return warn(
      `URL longue (${path.length} caractères) : visez 75 au maximum.`,
    );
  if (!/^[a-z0-9-]+(\/[a-z0-9-]+)*$/.test(path)) {
    return warn(
      "L’URL devrait être en minuscules, avec des tirets, sans accent ni caractère spécial.",
    );
  }
  return ok("URL courte, en minuscules, avec des tirets.");
}

export function freshnessOutcome(f: PageFacts): Outcome | null {
  const { publishedAt, updatedAt, now } = f.ctx;
  if (!publishedAt) {
    return todo("Marquez le contenu en production pour suivre sa fraîcheur.");
  }
  const published = Date.parse(publishedAt);
  const updated = updatedAt ? Date.parse(updatedAt) : published;
  if (Number.isNaN(published)) return null;
  if (updated - published > DAY_MS) {
    return warn(
      "Le contenu a été modifié depuis la mise en production : redatez la page si l’information a changé.",
    );
  }
  const age = Math.floor((now - published) / DAY_MS);
  if (age > 365)
    return warn(
      `Publié il y a ${age} jours : vérifiez que l’information est toujours exacte avant de redater.`,
    );
  return ok(
    `En production depuis ${age} jour${age > 1 ? "s" : ""}, sans modification depuis.`,
  );
}

export function factsOutcome(f: PageFacts): Outcome | null {
  const blocks = f.doc.blocks.filter((b) => b.kind === "p" || b.kind === "li");
  const figures = blocks.filter((b) => FIGURE.test(b.text)).length;
  const dated = blocks.filter(
    (b) => FIGURE.test(b.text) && YEAR.test(b.text),
  ).length;
  const examples = blocks.filter((b) => EXAMPLE.test(b.text)).length;
  const sources = externalLinks(f);
  const author = AUTHOR_TEXT.test(f.doc.bodyText);
  const signals = [
    figures >= 3,
    dated >= 1,
    examples >= 1,
    sources >= 1,
    author,
  ].filter(Boolean).length;
  const detail = `${figures} passage(s) chiffré(s), ${dated} daté(s), ${examples} exemple(s), ${sources} source(s) externe(s)${author ? ", auteur mentionné" : ""}.`;
  if (signals >= 4) return ok(detail);
  if (signals >= 2)
    return warn(`${detail} Ajoutez chiffres datés, exemples et sources.`);
  return fail(`${detail} Le contenu manque de faits vérifiables.`);
}

export function headingOutcome(f: PageFacts): Outcome {
  const levels = f.doc.headings.map((h) => h.level);
  const h1 = levels.filter((l) => l === 1).length;
  if (h1 === 0) return fail("Aucun H1.");
  const jumps = levels.some((level, i) => i > 0 && level - levels[i - 1] > 1);
  if (h1 > 1) return warn(`${h1} titres H1 : gardez un seul titre principal.`);
  if (jumps)
    return warn("Un niveau de titre est sauté (par exemple H2 puis H4).");
  return ok("Un seul H1 et une hiérarchie sans saut.");
}
