// The diagnosis shown next to the editor: what the content does well, what to
// fix first, and how. It reads the GEO checklist, the SEO score parts and,
// when an AI analysis was run, the E-E-A-T axes.
import type { ScorePart } from "../semantic/analyze";
import { GEO_CHECK_BY_ID } from "./catalog";
import type { EeatAxis, GeoCheckResult, GeoLlmAnalysis } from "./types";

export type DiagnosisSource = "seo" | "geo" | "ia";

export type DiagnosisItem = {
  id: string;
  source: DiagnosisSource;
  label: string;
  /** What was observed. */
  detail: string;
  /** What to do about it (weaknesses only). */
  fix: string;
  /** Importance, to sort and cut the lists. */
  weight: number;
  severity: "fail" | "warn";
};

export type Diagnosis = {
  strengths: DiagnosisItem[];
  weaknesses: DiagnosisItem[];
  /** GEO controls that could not be evaluated yet. */
  pending: number;
};

/** The action to take for each page control of the GEO checklist. */
export const GEO_FIXES: Record<string, string> = {
  "inverted-pyramid":
    "Répondez à la question posée dès le premier paragraphe, en 90 mots maximum, avec le mot-clé exact.",
  "intro-summary":
    "Résumez la réponse en 40 à 80 mots juste sous le titre (Assistant IA : Introduction GEO).",
  "modular-sections":
    "Faites commencer chaque H2 par un paragraphe de 15 à 90 mots qui répond tout de suite à son titre.",
  "short-paragraphs":
    "Coupez les paragraphes de plus de 90 mots en blocs de 3 à 5 lignes.",
  "informative-titles":
    "Reformulez les intertitres pour qu’ils disent de quoi parle la section et reprennent le mot-clé.",
  "keyword-h1-intro":
    "Placez le mot-clé exact dans le H1 et dans la première phrase.",
  lists: "Transformez une énumération en liste à puces ou numérotée.",
  tables:
    "Ajoutez un tableau pour comparer des options ou résumer des données.",
  callouts:
    "Mettez le message clé d’une section dans une citation ou un encadré.",
  "bold-terms": "Mettez en gras au moins trois notions importantes.",
  "heading-hierarchy": "Gardez un seul H1 et ne sautez aucun niveau de titre.",
  "image-alt":
    "Renseignez un alt descriptif sur chaque image et sortez le texte important des images.",
  "lead-image": "Ajoutez un chapô et une image sous le H1.",
  "schema-type":
    "Ajoutez un JSON-LD du bon type (Article, FAQPage, HowTo) : copiez-le depuis la carte Schema.org de l’éditeur SEO.",
  "jsonld-present": "Intégrez un bloc JSON-LD dans la page.",
  "schema-fields":
    "Ajoutez l’auteur, la date de publication et la date de mise à jour dans le schema Article.",
  "breadcrumb-publisher":
    "Ajoutez un fil d’Ariane (BreadcrumbList) et l’éditeur de la page (Organization).",
  experience:
    "Racontez un vécu précis : un cas rencontré, un essai personnel, un résultat observé.",
  opinions:
    "Prenez position : donnez un avis argumenté plutôt qu’une généralité.",
  anecdotes:
    "Ajoutez une anecdote ou un exemple concret pour chaque grande idée.",
  "unique-advice":
    "Apportez un conseil ou une astuce que les autres sites ne donnent pas.",
  "hard-to-generate":
    "Retirez ce que dix autres sites disent déjà et ajoutez ce que vous seul pouvez dire.",
  author:
    "Nommez l’auteur avec sa fonction, ajoutez une bio et déclarez-le dans le schema.",
  "external-sources":
    "Citez au moins deux sources fiables avec un lien (organisme, étude, texte officiel).",
  "verifiable-facts":
    "Ajoutez des chiffres datés, des exemples concrets et leurs sources.",
  "first-hand-data":
    "Appuyez-vous sur une donnée issue de votre activité : enquête, test, chiffres internes.",
  "no-dubious-info":
    "Vérifiez chaque affirmation (carte Vérification des faits) et retirez ce qui n’est pas sourcé.",
  "clear-style":
    "Simplifiez : phrases courtes, mots courants, jargon expliqué.",
  "active-voice": "Passez les phrases au passif à la voix active.",
  "short-sentences": "Découpez les phrases de plus de 20 mots.",
  contrast: "Vérifiez le contraste entre le texte et le fond du gabarit.",
  responsive:
    "Testez la page sur mobile : texte lisible, tableaux qui défilent.",
  "reading-time": "Affichez un temps de lecture sous le titre.",
  "keyword-zones":
    "Placez le mot-clé exact dans le H1, le title, la méta, le premier paragraphe et un sous-titre.",
  "meta-title":
    "Réécrivez le title en 40 à 60 caractères avec les termes exacts (Assistant IA : Title et méta).",
  "meta-description":
    "Rédigez une méta unique de 130 à 150 caractères qui décrit la page et incite au clic.",
  "clean-url":
    "Utilisez une URL courte, en minuscules, avec des tirets, sans paramètre.",
  "internal-linking":
    "Ajoutez au moins 3 liens vers les articles du même cluster, et des liens de retour vers cette page.",
  "final-cta":
    "Terminez par un appel à l’action clair : contactez, téléchargez, découvrez…",
  "og-twitter":
    "Ajoutez les balises Open Graph (titre, description, image) et Twitter card.",
  freshness:
    "Redatez la page seulement quand l’information a changé, et indiquez « mis à jour le … ».",
  "english-version": "Créez une version anglaise et déclarez-la avec hreflang.",
  "ai-understandable":
    "Relisez la page comme un lecteur pressé : l’idée centrale ressort-elle en dix secondes ?",
  memorable: "Terminez chaque section sur une idée forte qu’on retient.",
};

const AXIS_LABEL: Record<EeatAxis, string> = {
  experience: "Expérience",
  expertise: "Expertise",
  authority: "Autorité",
  trust: "Confiance",
};

const AXES: EeatAxis[] = ["experience", "expertise", "authority", "trust"];

const MAX_STRENGTHS = 5;
const MAX_WEAKNESSES = 7;
const SEO_STRONG = 0.85;
const SEO_WEAK = 0.6;
const SEO_VERY_WEAK = 0.35;

function geoItems(results: GeoCheckResult[]) {
  const strengths: DiagnosisItem[] = [];
  const weaknesses: DiagnosisItem[] = [];
  let pending = 0;
  for (const result of results) {
    const def = GEO_CHECK_BY_ID.get(result.id);
    if (!def || def.scope !== "page") continue;
    if (result.status === "todo") {
      pending++;
      continue;
    }
    // Priority controls count for more when sorting.
    const weight = def.weight + (def.priority ? 1 : 0);
    const item: DiagnosisItem = {
      id: `geo-${def.id}`,
      source: "geo",
      label: def.label,
      detail: result.detail,
      fix: GEO_FIXES[def.id] ?? def.why,
      weight,
      severity: result.status === "fail" ? "fail" : "warn",
    };
    if (result.status === "ok") strengths.push(item);
    else weaknesses.push(item);
  }
  return { strengths, weaknesses, pending };
}

function seoItems(parts: ScorePart[]) {
  const strengths: DiagnosisItem[] = [];
  const weaknesses: DiagnosisItem[] = [];
  for (const part of parts) {
    const ratio = part.max ? part.points / part.max : 0;
    const item: DiagnosisItem = {
      id: `seo-${part.key}`,
      source: "seo",
      label: part.label,
      detail: `${part.points} / ${part.max} points.`,
      fix: part.hint,
      weight: part.max / 5,
      severity: ratio < SEO_VERY_WEAK ? "fail" : "warn",
    };
    if (ratio >= SEO_STRONG) strengths.push(item);
    else if (ratio < SEO_WEAK) weaknesses.push(item);
  }
  return { strengths, weaknesses };
}

function iaItems(llm: GeoLlmAnalysis | null) {
  const strengths: DiagnosisItem[] = [];
  const weaknesses: DiagnosisItem[] = [];
  if (!llm) return { strengths, weaknesses };
  for (const axis of AXES) {
    const value = llm.eeat[axis];
    const item: DiagnosisItem = {
      id: `ia-${axis}`,
      source: "ia",
      label: `E-E-A-T : ${AXIS_LABEL[axis]} (${value.score} / 5)`,
      detail: value.evidence,
      fix: value.advice,
      weight: 3,
      severity: value.score <= 1 ? "fail" : "warn",
    };
    if (value.score >= 4) strengths.push(item);
    else if (value.score <= 2) weaknesses.push(item);
  }
  return { strengths, weaknesses };
}

const SEVERITY_RANK = { fail: 2, warn: 1 } as const;

/** Points forts and faibles of a content, most important first. */
export function buildDiagnosis(input: {
  geoResults: GeoCheckResult[];
  seoParts: ScorePart[];
  llm: GeoLlmAnalysis | null;
}): Diagnosis {
  const geo = geoItems(input.geoResults);
  const seo = seoItems(input.seoParts);
  const ia = iaItems(input.llm);

  const strengths = [...geo.strengths, ...seo.strengths, ...ia.strengths];
  strengths.sort((a, b) => b.weight - a.weight);
  const weaknesses = [...geo.weaknesses, ...seo.weaknesses, ...ia.weaknesses];
  weaknesses.sort(
    (a, b) =>
      SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity] ||
      b.weight - a.weight,
  );
  return {
    strengths: strengths.slice(0, MAX_STRENGTHS),
    weaknesses: weaknesses.slice(0, MAX_WEAKNESSES),
    pending: geo.pending,
  };
}
