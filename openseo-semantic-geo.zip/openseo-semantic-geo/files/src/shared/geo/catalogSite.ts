import type { GeoCheckDef } from "./types";

// Site-level controls: architecture, external sources and measurement.
export const GEO_SITE_CHECKS: GeoCheckDef[] = [
  // Architecture du site
  {
    id: "three-clicks",
    block: "architecture",
    scope: "site",
    ref: "25",
    label:
      "Pages de positionnement accessibles en trois clics depuis l’accueil",
    why: "Chaque catégorie du site mène à ses contenus les plus utiles.",
    weight: 2,
    mode: "manual",
    tool: { label: "Site Audit", path: "audit" },
  },

  // Sources externes
  {
    id: "cited-sources",
    block: "sources",
    scope: "site",
    ref: "29",
    label:
      "Sources réellement citées sur vos requêtes cibles, identifiées prompt par prompt",
    why: "Chaque citation obtenue par un concurrent est une source à travailler.",
    weight: 3,
    priority: true,
    mode: "manual",
    tool: { label: "Prompt Tracking", path: "ai-visibility" },
  },
  {
    id: "directories",
    block: "sources",
    scope: "site",
    ref: "30",
    label:
      "Marque présente dans les comparatifs et annuaires du marché, description à jour",
    why: "Les modèles s’appuient sur ces pages tierces.",
    weight: 2,
    mode: "manual",
  },
  {
    id: "reddit",
    block: "sources",
    scope: "site",
    ref: "31",
    label:
      "Fils Reddit du secteur suivis, interventions conformes aux codes de la plateforme",
    why: "Reddit est une source très consultée par les assistants.",
    weight: 1,
    mode: "manual",
  },
  {
    id: "reviews",
    block: "sources",
    scope: "site",
    ref: "32",
    label:
      "Avis clients travaillés sur les plateformes que les modèles consultent",
    why: "Les avis nourrissent la perception de la marque.",
    weight: 2,
    mode: "manual",
  },
  {
    id: "third-party-errors",
    block: "sources",
    scope: "site",
    ref: "33",
    label:
      "Publications tierces qui vous décrivent mal identifiées et corrigées à la source",
    why: "Un modèle reprend leur formulation plutôt que la vôtre.",
    weight: 2,
    mode: "manual",
  },
  {
    id: "business-profile",
    block: "sources",
    scope: "site",
    ref: "34",
    label:
      "Fiche Google Business Profile complète, bonne catégorie, à jour (activité locale)",
    why: "Source de référence pour les requêtes locales.",
    weight: 1,
    mode: "manual",
  },
  {
    id: "editorial-links",
    block: "sources",
    scope: "site",
    ref: "35",
    label:
      "Autorité du domaine par des liens éditoriaux mérités, jamais par échanges systématiques",
    why: "Les moteurs savent repérer les échanges de liens.",
    weight: 2,
    mode: "manual",
    tool: { label: "Backlinks", path: "backlinks" },
  },

  // Mesure
  {
    id: "tracked-queries",
    block: "measure",
    scope: "site",
    ref: "36",
    label:
      "Requêtes cibles par catégorie suivies quotidiennement sur ChatGPT, Perplexity, Claude, Gemini et Copilot",
    why: "Sans cette base, aucun score d’évolution n’est possible.",
    weight: 3,
    priority: true,
    mode: "auto",
    tool: { label: "Prompt Tracking", path: "ai-visibility" },
  },
  {
    id: "mention-rate",
    block: "measure",
    scope: "site",
    ref: "37",
    label:
      "Taux de mention, présence de la marque et position relative face aux concurrents mesurés dans le temps",
    why: "Taux de citation = réponses citant la marque ÷ requêtes testées × 100. Seule la tendance et l’écart avec les concurrents comptent.",
    weight: 2,
    mode: "manual",
    tool: { label: "Prompt Tracking", path: "ai-visibility" },
  },
  {
    id: "ai-crawlers",
    block: "measure",
    scope: "site",
    ref: "38",
    label: "Visites des crawlers IA collectées et distinguées du trafic humain",
    why: "Demande un accès aux journaux du serveur ou du CDN.",
    weight: 1,
    mode: "manual",
  },
  {
    id: "webmaster-tools",
    block: "measure",
    scope: "site",
    ref: "39",
    label: "Google Search Console et Bing Webmaster Tools configurés",
    why: "Bing expose désormais des données de performance IA.",
    weight: 2,
    mode: "auto",
    tool: { label: "Search Console", path: "search-performance" },
  },
  {
    id: "ai-sessions",
    block: "measure",
    scope: "site",
    ref: "40",
    label: "Sessions issues des assistants isolées dans l’outil d’analytique",
    why: "Référents à suivre : chatgpt.com, perplexity.ai, gemini.google.com. Trafic peu volumineux mais qualifié.",
    weight: 2,
    mode: "auto",
  },
];
