import { createFileRoute } from "@tanstack/react-router";
import { SemanticEditorPage } from "@/client/features/semantic/SemanticEditorPage";

export const Route = createFileRoute("/_app/p/$projectId/semantic/$documentId")(
  {
    component: SemanticEditorRoute,
  },
);

function SemanticEditorRoute() {
  const { projectId, documentId } = Route.useParams();
  return (
    <div className="h-full overflow-auto px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8">
      <div className="mx-auto max-w-[96rem]">
        <SemanticEditorPage projectId={projectId} documentId={documentId} />
      </div>
    </div>
  );
}
