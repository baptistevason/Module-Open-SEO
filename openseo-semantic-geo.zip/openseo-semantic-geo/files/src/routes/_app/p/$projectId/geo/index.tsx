import { createFileRoute } from "@tanstack/react-router";
import { GeoLibraryPage } from "@/client/features/geo/GeoLibraryPage";

export const Route = createFileRoute("/_app/p/$projectId/geo/")({
  component: GeoLibraryRoute,
});

function GeoLibraryRoute() {
  const { projectId } = Route.useParams();
  return (
    <div className="h-full overflow-auto px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8">
      <div className="mx-auto max-w-5xl">
        <GeoLibraryPage projectId={projectId} />
      </div>
    </div>
  );
}
