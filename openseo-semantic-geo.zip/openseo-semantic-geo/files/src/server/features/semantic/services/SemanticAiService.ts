import {
  getProjectContext,
  renderProjectContextMarkdown,
} from "@/server/features/project-context/services/ProjectContextService";
import {
  askClaude,
  MODEL_ANALYSIS,
  MODEL_FAST,
  parseJsonResult,
} from "@/server/lib/anthropic";
import { htmlToPlainText } from "@/shared/semantic/html";
import { TICS } from "@/shared/semantic/style-review";
import type {
  FactCheckClaim,
  FactStatus,
  SemanticResult,
} from "@/shared/semantic/types";
import { FACT_STATUSES } from "@/shared/semantic/types";
import { z } from "zod";

// Claude-backed tools of the Sémantique workspace. Every method resolves to a
// SemanticResult: expected failures (no key, refusal, unreadable answer) come
// back as data with copy safe to show, since the client only receives a bare
// error code from server functions.

const CONTEXT_MAX_CHARS = 3_000;
const REPHRASE_MAX_CHARS = 2_000;
const FACT_CHECK_MIN_CHARS = 200;
const FACT_CHECK_MAX_CHARS = 60_000;

export async function siteContext(projectId: string): Promise<string> {
  try {
    const context = await getProjectContext(projectId);
    return renderProjectContextMarkdown(context).slice(0, CONTEXT_MAX_CHARS);
  } catch {
    return "";
  }
}

const REPHRASE_SYSTEM = `Tu es l’éditeur d’un consultant SEO. Tu retravailles un passage d’un contenu web en français pour qu’il sonne comme une vraie plume et non comme un gabarit.

Règles :
- Garde strictement le sens et tous les faits, chiffres, noms et sources du passage. N’ajoute aucune information.
- Si le passage contient le mot-clé principal, garde-le à l’identique.
- Supprime les tics d’écriture génériques et les connecteurs de remplissage, varie le rythme, préfère le concret.
- Longueur proche de l’original (plus courte si le passage est verbeux).
- Pas de tiret cadratin (—) ni de demi-cadratin (–) comme ponctuation.
- Texte brut uniquement : pas de HTML, pas de Markdown, pas de guillemets autour de la proposition.

Tournures à éviter :
${TICS.map((tic) => `- ${tic.label} : ${tic.hint}`).join("\n")}

Réponds uniquement avec 3 propositions différentes, chacune dans une balise <option>…</option>, de la plus fidèle à la plus libre.`;

/** Dashes used as punctuation are banned in the copy; normalise to commas. */
export function cleanProposal(text: string): string {
  return text
    .replace(/\s*[—–]\s*/g, ", ")
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
    .trim();
}

async function rephrase(input: {
  projectId: string;
  text: string;
  context: string;
  keyword: string;
}): Promise<SemanticResult<{ options: string[] }>> {
  const text = input.text.trim();
  if (text.length < 3) {
    return { ok: false, message: "Sélectionnez un passage à reformuler." };
  }
  if (text.length > REPHRASE_MAX_CHARS) {
    return {
      ok: false,
      message: `Passage trop long (${REPHRASE_MAX_CHARS} caractères maximum) : sélectionnez une phrase ou un paragraphe.`,
    };
  }
  const context = await siteContext(input.projectId);
  const parts = [
    context ? `Contexte du projet :\n${context}\n` : null,
    input.keyword ? `Mot-clé principal du contenu : ${input.keyword}` : null,
    input.context && input.context !== text
      ? `Paragraphe où se trouve le passage (pour le contexte, ne pas le réécrire) :\n${input.context}\n`
      : null,
    `Passage à retravailler :\n${text}`,
  ];

  const result = await askClaude({
    model: MODEL_FAST,
    system: REPHRASE_SYSTEM,
    content: parts.filter(Boolean).join("\n"),
    maxTokens: 2_000,
    effort: "low",
  });
  if (!result.ok) return result;

  const options = [...result.text.matchAll(/<option>([\s\S]*?)<\/option>/g)]
    .map((match) => cleanProposal(match[1]))
    .filter(Boolean)
    .slice(0, 3);
  if (options.length === 0) {
    return { ok: false, message: "Aucune proposition exploitable. Réessayez." };
  }
  return { ok: true, options };
}

const FACT_SYSTEM = `Tu es le vérificateur de faits d’un cabinet SEO. Tu contrôles un contenu web en français avant publication.

Méthode :
1. Relève chaque affirmation vérifiable : chiffres, prix, pourcentages, dates, statistiques, études ou organismes cités, textes de loi et réglementation, caractéristiques techniques, affirmations factuelles fortes. Ignore les opinions, conseils et formulations générales.
2. Pour chacune, vérifie par recherche web sur des sources fiables (organismes publics, textes officiels, études, presse reconnue). Privilégie les sources les plus récentes.
3. Attribue un statut :
   - "confirme" : une source externe fiable confirme l’information (donne-la).
   - "a_sourcer" : l’information est plausible mais aucune source n’est citée dans le texte alors qu’elle devrait l’être (chiffre, étude, statistique) ; propose la source trouvée et la mention à ajouter (source + année).
   - "incorrect" : une source fiable la contredit.
   - "obsolete" : l’information était vraie mais a changé (donnée plus récente, loi modifiée).
   - "non_verifiable" : impossible de confirmer ou d’infirmer.
4. Pour "incorrect", "obsolete" et "a_sourcer", propose une reformulation corrigée prête à remplacer l’extrait (même ton, sans tiret cadratin).

Réponds uniquement avec un tableau JSON entre <result> et </result>, sans autre texte :
<result>[{"quote": "extrait EXACT copié du texte, 200 caractères maximum", "claim": "l’affirmation en une phrase", "status": "…", "explanation": "justification courte", "source": {"title": "…", "url": "…"} ou null, "suggestion": "reformulation corrigée" ou null}]</result>
L’extrait "quote" doit être copié caractère pour caractère depuis le texte, pour pouvoir être retrouvé. Maximum 30 éléments, les plus importants d’abord.`;

const claimSchema = z.object({
  quote: z.string(),
  claim: z.string().optional(),
  status: z.string().optional(),
  explanation: z.string().optional(),
  source: z
    .object({ title: z.string().optional(), url: z.string().optional() })
    .nullable()
    .optional(),
  suggestion: z.string().nullable().optional(),
});

function normalizeForMatch(value: string): string {
  return value
    .replace(/[’‘]/g, "'")
    .replace(/[“”«»]/g, '"')
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function isFactStatus(value: string | undefined): value is FactStatus {
  return FACT_STATUSES.some((status) => status === value);
}

async function factCheck(input: {
  projectId: string;
  html: string;
  title: string;
  keyword: string;
}): Promise<SemanticResult<{ claims: FactCheckClaim[]; checkedAt: string }>> {
  const text = htmlToPlainText(input.html).slice(0, FACT_CHECK_MAX_CHARS);
  if (text.length < FACT_CHECK_MIN_CHARS) {
    return {
      ok: false,
      message: "Contenu trop court pour une vérification.",
    };
  }
  const context = await siteContext(input.projectId);
  const parts = [
    context ? `Contexte du projet :\n${context}` : null,
    `Date du jour : ${new Date().toISOString().slice(0, 10)}.`,
    input.title ? `Titre : ${input.title}` : null,
    input.keyword ? `Mot-clé principal : ${input.keyword}` : null,
    `TEXTE À VÉRIFIER :\n"""\n${text}\n"""`,
  ];

  const result = await askClaude({
    model: MODEL_ANALYSIS,
    system: FACT_SYSTEM,
    content: parts.filter(Boolean).join("\n\n"),
    maxTokens: 16_000,
    effort: "medium",
    tools: [
      {
        type: "web_search_20260209",
        name: "web_search",
        max_uses: 10,
        user_location: { type: "approximate", country: "FR" },
      },
    ],
  });
  if (!result.ok) return result;

  const raw = z.array(claimSchema).safeParse(parseJsonResult(result.text));
  if (!raw.success) {
    return { ok: false, message: "Réponse d’analyse illisible. Réessayez." };
  }
  const normalizedText = normalizeForMatch(text);
  const claims = raw.data
    .filter((c) => c.quote.trim())
    .map<FactCheckClaim>((c) => {
      const url = c.source?.url ?? "";
      return {
        quote: c.quote.trim(),
        claim: (c.claim ?? "").trim(),
        status: isFactStatus(c.status) ? c.status : "non_verifiable",
        explanation: (c.explanation ?? "").trim(),
        source: /^https?:\/\//.test(url)
          ? { title: c.source?.title?.trim() || url, url }
          : null,
        suggestion: c.suggestion ? cleanProposal(c.suggestion) : null,
        found: normalizedText.includes(normalizeForMatch(c.quote)),
      };
    });
  return { ok: true, claims, checkedAt: new Date().toISOString() };
}

export const SemanticAiService = { rephrase, factCheck } as const;
export { normalizeForMatch };
