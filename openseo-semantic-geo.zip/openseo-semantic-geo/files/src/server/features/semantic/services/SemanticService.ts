import { waitUntil } from "cloudflare:workers";
import { getSerpAnalysis } from "@/server/features/keywords/services/research";
import type { BillingCustomerContext } from "@/server/billing/subscription";
import { buildCacheKey, getCached, setCached } from "@/server/lib/r2-cache";
import {
  countNgrams,
  detectLanguage,
  stopwordsFor,
  tokenize,
} from "@/shared/semantic/text";
import type {
  SemanticBrief,
  SemanticResult,
  SemanticBriefPage,
  SemanticBriefTerm,
  SemanticTermKind,
} from "@/shared/semantic/types";
import { termDistribution } from "@/shared/semantic/bands";
import { parseBriefValue } from "@/shared/semantic/brief-schema";
import { computeTargets } from "@/shared/semantic/targets";
import {
  competitorScores,
  medianReadability,
  pageMetrics,
  type ReadPage,
} from "./briefMetrics";
import { extractPage, type ExtractedPage } from "./pageExtract";
import { describeFetchFailure, fetchPageHtml } from "./pageFetch";

const BRIEF_CACHE_TTL_SECONDS = 12 * 60 * 60;
const SERP_DEPTH = 20;
const PAGES_TO_READ = 8;
const MIN_WORDS_READABLE = 150;
const MAX_H2_PER_PAGE = 12;
const TERMS_PER_KIND: Record<SemanticTermKind, number> = {
  word: 40,
  bigram: 40,
  trigram: 20,
};

/** Social, video and marketplace hosts rank but have no article outline to learn from. */
const UNREADABLE_DOMAINS =
  /(^|\.)(instagram|facebook|tiktok|youtube|pinterest|linkedin|x|twitter|reddit|amazon)\.(com|fr)$/i;

function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values];
  sorted.sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)];
}

function mean(values: number[]): number | null {
  if (values.length === 0) return null;
  const average = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.round(average * 10) / 10;
}

type TermStats = {
  terms: SemanticBriefTerm[];
  /** Uses of each kept term per page, aligned with the pages (zero if absent). */
  countsByTerm: Map<string, number[]>;
};

function aggregateTerms(pages: ReadPage[], languageCode: string): TermStats {
  const sample = pages.flatMap((page) => page.tokens.slice(0, 600));
  const stopwords = stopwordsFor(detectLanguage(sample, languageCode));
  const stats = new Map<string, { kind: SemanticTermKind; counts: number[] }>();

  pages.forEach((page, pageIndex) => {
    const ngrams = countNgrams(page.tokens, stopwords);
    const sources: [SemanticTermKind, Map<string, number>][] = [
      ["word", ngrams.words],
      ["bigram", ngrams.bigrams],
      ["trigram", ngrams.trigrams],
    ];
    for (const [kind, counts] of sources) {
      for (const [term, count] of counts) {
        const entry = stats.get(term) ?? {
          kind,
          counts: Array.from({ length: pages.length }, () => 0),
        };
        entry.counts[pageIndex] = count;
        stats.set(term, entry);
      }
    }
  });

  // A term only matters if several of the ranking pages agree on it.
  const minPages = pages.length >= 3 ? Math.ceil(pages.length * 0.4) : 1;
  const terms: SemanticBriefTerm[] = [];
  for (const [term, entry] of stats) {
    const present = entry.counts.filter((c) => c > 0);
    const total = present.reduce((sum, c) => sum + c, 0);
    if (present.length < minPages) continue;
    // Phrases must recur to be a real topic, not a one-off coincidence.
    if (entry.kind !== "word" && total < present.length * 1.2) continue;
    terms.push({
      term,
      kind: entry.kind,
      pages: present.length,
      avgCount: Math.round((total / present.length) * 10) / 10,
      ...termDistribution(present, pages.length),
    });
  }

  const byKind = (kind: SemanticTermKind) => {
    const ofKind = terms.filter((t) => t.kind === kind);
    ofKind.sort((a, b) => b.pages - a.pages || b.avgCount - a.avgCount);
    return ofKind.slice(0, TERMS_PER_KIND[kind]);
  };
  const kept = [...byKind("trigram"), ...byKind("bigram"), ...byKind("word")];
  const countsByTerm = new Map<string, number[]>();
  for (const term of kept) {
    countsByTerm.set(term.term, stats.get(term.term)?.counts ?? []);
  }
  return { terms: kept, countsByTerm };
}

async function readCompetitors(
  items: { rank: number; url: string; domain: string }[],
): Promise<ReadPage[]> {
  const candidates = items
    .filter((item) => item.url && !UNREADABLE_DOMAINS.test(item.domain))
    .slice(0, PAGES_TO_READ);
  const settled = await Promise.allSettled(
    candidates.map(async (item): Promise<ReadPage> => {
      const extracted = extractPage(await fetchPageHtml(item.url));
      return {
        rank: item.rank,
        url: item.url,
        domain: item.domain.replace(/^www\./, ""),
        extracted,
        tokens: tokenize(extracted.blocks.join("\n")),
      };
    }),
  );
  return settled
    .filter(
      (r): r is PromiseFulfilledResult<ReadPage> => r.status === "fulfilled",
    )
    .map((r) => r.value)
    .filter((p) => p.tokens.length >= MIN_WORDS_READABLE);
}

function describePages(pages: ReadPage[]): SemanticBriefPage[] {
  return pages.map((p) => {
    const h2 = p.extracted.headings.filter((h) => h.level === 2);
    return {
      rank: p.rank,
      url: p.url,
      domain: p.domain,
      title: p.extracted.title,
      words: p.tokens.length,
      h2Count: h2.length,
      h3Count: p.extracted.headings.filter((h) => h.level === 3).length,
      imageCount: p.extracted.imageCount,
      h2: h2.slice(0, MAX_H2_PER_PAGE).map((h) => h.text.slice(0, 160)),
      metrics: pageMetrics(p),
    };
  });
}

async function getBrief(
  input: {
    projectId: string;
    keyword: string;
    locationCode: number;
    languageCode: string;
  },
  billingCustomer: BillingCustomerContext,
): Promise<SemanticResult<{ brief: SemanticBrief }>> {
  const keyword = input.keyword.trim().toLowerCase();
  const cacheKey = await buildCacheKey("semantic:brief", {
    organizationId: billingCustomer.organizationId,
    projectId: input.projectId,
    keyword,
    locationCode: input.locationCode,
    languageCode: input.languageCode,
  });
  // An entry written before the targets existed is ignored.
  const cached = parseBriefValue(await getCached(cacheKey));
  if (cached?.targets) return { ok: true, brief: cached };

  // Same call, cache and billing as the Keyword Research SERP panel.
  const serp = await getSerpAnalysis(
    {
      projectId: input.projectId,
      keyword,
      locationCode: input.locationCode,
      languageCode: input.languageCode,
      depth: SERP_DEPTH,
    },
    billingCustomer,
  );
  if (serp.items.length === 0) {
    return {
      ok: false,
      message: "Aucun résultat organique pour ce mot-clé sur ce marché.",
    };
  }

  const pages = await readCompetitors(serp.items);
  if (pages.length === 0) {
    return {
      ok: false,
      message:
        "Aucune page concurrente n’a pu être lue (sites bloquant les robots). Essayez un autre mot-clé.",
    };
  }

  const briefPages = describePages(pages);
  const { terms, countsByTerm } = aggregateTerms(pages, input.languageCode);
  const base: SemanticBrief = {
    keyword,
    languageCode: input.languageCode,
    locationCode: input.locationCode,
    fetchedAt: new Date().toISOString(),
    pagesRead: briefPages.length,
    pagesRequested: Math.min(PAGES_TO_READ, serp.items.length),
    pages: briefPages,
    medianWords: median(briefPages.map((p) => p.words)),
    avgH2: mean(briefPages.map((p) => p.h2Count)),
    avgH3: mean(briefPages.map((p) => p.h3Count)),
    avgImages: mean(briefPages.map((p) => p.imageCount)),
    terms,
  };

  const scoreTarget = competitorScores({
    pages,
    base,
    countsByTerm,
    keyword,
    languageCode: input.languageCode,
  });
  const scored = scoreTarget
    ? {
        ...base,
        pages: briefPages.map((page) => ({
          ...page,
          score: scoreTarget.scores.find((s) => s.rank === page.rank)?.score,
        })),
      }
    : base;
  const brief: SemanticBrief = {
    ...scored,
    targets: computeTargets(
      briefPages.flatMap((p) => (p.metrics ? [{ metrics: p.metrics }] : [])),
    ),
    readability: medianReadability(pages, input.languageCode),
    scoreTarget,
  };

  waitUntil(
    setCached(cacheKey, brief, BRIEF_CACHE_TTL_SECONDS).catch((error) => {
      console.error("semantic.brief.cache-write failed:", error);
    }),
  );
  return { ok: true, brief };
}

/** Fetch one of the user's own pages and render it as editable Markdown. */
async function loadPage(
  url: string,
): Promise<SemanticResult<{ title: string; html: string }>> {
  let extracted: ExtractedPage;
  try {
    extracted = extractPage(await fetchPageHtml(url));
  } catch (error) {
    const message = describeFetchFailure(error);
    if (message === null) throw error;
    return { ok: false, message };
  }
  if (extracted.blocks.length === 0) {
    return {
      ok: false,
      message:
        "Aucun contenu lisible sur cette page (contenu généré en JavaScript ?).",
    };
  }
  return { ok: true, title: extracted.title, html: extracted.html };
}

export const SemanticService = { getBrief, loadPage } as const;
