import { AuditRepository } from "@/server/features/audit/repositories/AuditRepository";
import {
  askClaude,
  MODEL_ANALYSIS,
  parseJsonResult,
} from "@/server/lib/anthropic";
import { htmlToPlainText } from "@/shared/semantic/html";
import { stopwordsFor, stripAccents, tokenize } from "@/shared/semantic/text";
import type {
  IncomingLinkSuggestion,
  OutgoingLink,
  SemanticResult,
} from "@/shared/semantic/types";
import { z } from "zod";
import { extractPage } from "./pageExtract";
import { fetchPageHtml } from "./pageFetch";
import { normalizeForMatch } from "./SemanticAiService";

// Internal linking. The index of the project's existing pages comes from its
// latest completed Site Audit (titles and meta descriptions of every crawled
// page), so no CMS connection is needed. Claude then picks:
// - outgoing links to weave into the draft,
// - incoming links: existing pages that should point to the draft, with the
//   exact sentence to edit.

const OUTGOING_CANDIDATES = 30;
const INCOMING_CANDIDATES = 8;
const INCOMING_MIN_PAGE_CHARS = 200;
const PAGE_TEXT_CHARS = 6_000;

const NO_AUDIT_MESSAGE =
  "Aucun audit de site terminé pour ce projet : lancez un Site Audit pour que OpenSEO connaisse les pages à relier.";

type IndexPage = { url: string; title: string; description: string };

async function loadIndex(projectId: string): Promise<IndexPage[] | null> {
  const audits = await AuditRepository.getAuditsByProject(projectId);
  const audit = audits.find((a) => a.status === "completed");
  if (!audit) return null;
  const pages = await AuditRepository.getPagesForAudit(audit.id);
  return pages
    .filter(
      (p) =>
        p.statusCode === 200 && p.isIndexable && (p.title ?? "").trim() !== "",
    )
    .map((p) => ({
      url: p.url,
      title: (p.title ?? "").trim(),
      description: (p.metaDescription ?? "").trim().slice(0, 300),
    }));
}

const sameUrl = (a: string, b: string) =>
  a.replace(/\/$/, "").toLowerCase() === b.replace(/\/$/, "").toLowerCase();

// Titles are short, so the stopwords of both languages are dropped.
function termSet(text: string): Set<string> {
  const french = stopwordsFor("fr");
  const english = stopwordsFor("en");
  return new Set(
    tokenize(text)
      .filter((t) => t.length >= 3 && !french.has(t) && !english.has(t))
      .map(stripAccents),
  );
}

/** Ranks index pages by term overlap with the query (title weighs double). */
function rankPages(
  pages: IndexPage[],
  query: string,
  options: { exclude: string[]; limit: number },
): IndexPage[] {
  const q = termSet(query);
  if (q.size === 0) return [];
  const scored = pages
    .filter((p) => !options.exclude.some((e) => e && sameUrl(p.url, e)))
    .map((p) => {
      const title = termSet(p.title);
      const description = termSet(p.description);
      let score = 0;
      for (const term of q) {
        score += (title.has(term) ? 2 : 0) + (description.has(term) ? 1 : 0);
      }
      return { page: p, score: score / Math.sqrt(q.size) };
    })
    .filter((entry) => entry.score > 0);
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, options.limit).map((entry) => entry.page);
}

const outgoingSchema = z.array(
  z.object({
    url: z.string(),
    anchor: z.string().optional(),
    reason: z.string().optional(),
  }),
);

async function outgoing(input: {
  projectId: string;
  languageCode: string;
  title: string;
  keyword: string;
  html: string;
  currentUrl: string;
}): Promise<SemanticResult<{ links: OutgoingLink[]; candidates: number }>> {
  const index = await loadIndex(input.projectId);
  if (!index) return { ok: false, message: NO_AUDIT_MESSAGE };

  const plain = htmlToPlainText(input.html);
  const candidates = rankPages(
    index,
    [input.title, input.keyword, plain.slice(0, 3000)].join(" "),
    { exclude: [input.currentUrl], limit: OUTGOING_CANDIDATES },
  );
  if (candidates.length === 0) return { ok: true, links: [], candidates: 0 };

  const result = await askClaude({
    model: MODEL_ANALYSIS,
    effort: "low",
    maxTokens: 8_000,
    system: `Tu es consultant SEO. Tu choisis les liens internes les plus utiles au lecteur pour un contenu, parmi des pages existantes du même site. Choisis jusqu’à 6 pages réellement utiles au lecteur sur ce sujet précis. Un lien forcé nuit au contenu : si seules 1 ou 2 pages sont pertinentes, n’en propose que celles-là, et renvoie un tableau vide si aucune ne l’est. Pour chacune, propose une ancre descriptive et naturelle en français (2 à 6 mots, jamais « cliquez ici », pas l’ancre exacte du mot-clé du contenu). Réponds uniquement avec un tableau JSON entre <result> et </result> : [{"url": "…", "anchor": "…", "reason": "pourquoi ce lien aide le lecteur"}]. N’utilise que des URL de la liste.`,
    content: [
      `Sujet du contenu : ${input.title || "(non précisé)"}`,
      input.keyword ? `Mot-clé principal : ${input.keyword}` : null,
      plain ? `Début du contenu :\n${plain.slice(0, 2500)}` : null,
      `Pages candidates :\n${candidates
        .map(
          (p) =>
            `- ${p.url} | ${p.title}${p.description ? ` | ${p.description.slice(0, 160)}` : ""}`,
        )
        .join("\n")}`,
    ]
      .filter(Boolean)
      .join("\n\n"),
  });
  if (!result.ok) return result;

  const parsed = outgoingSchema.safeParse(parseJsonResult(result.text));
  if (!parsed.success) {
    return { ok: false, message: "Réponse d’analyse illisible. Réessayez." };
  }
  const byUrl = new Map(candidates.map((p) => [p.url, p]));
  const links: OutgoingLink[] = [];
  for (const link of parsed.data) {
    const page = byUrl.get(link.url);
    if (!page || !link.anchor?.trim()) continue;
    links.push({
      url: page.url,
      title: page.title,
      anchor: link.anchor.trim(),
      reason: (link.reason ?? "").trim(),
    });
  }
  return { ok: true, links: links.slice(0, 6), candidates: candidates.length };
}

const incomingSchema = z.array(
  z.object({
    url: z.string(),
    sentence: z.string().optional(),
    anchor: z.string().optional(),
    newSentence: z.string().optional(),
    reason: z.string().optional(),
  }),
);

async function pageText(url: string): Promise<string> {
  const page = extractPage(await fetchPageHtml(url));
  return page.blocks.join("\n").slice(0, PAGE_TEXT_CHARS);
}

async function incoming(input: {
  projectId: string;
  languageCode: string;
  title: string;
  keyword: string;
  html: string;
  targetUrl: string;
}): Promise<
  SemanticResult<{ suggestions: IncomingLinkSuggestion[]; candidates: number }>
> {
  const index = await loadIndex(input.projectId);
  if (!index) return { ok: false, message: NO_AUDIT_MESSAGE };

  const plain = htmlToPlainText(input.html);
  const candidates = rankPages(
    index,
    [input.title, input.keyword, plain.slice(0, 1500)].join(" "),
    { exclude: [input.targetUrl], limit: INCOMING_CANDIDATES },
  );
  if (candidates.length === 0) {
    return { ok: true, suggestions: [], candidates: 0 };
  }

  const texts = await Promise.allSettled(
    candidates.map((p) => pageText(p.url)),
  );
  const readable = candidates
    .map((page, i) => {
      const text = texts[i];
      return { ...page, text: text.status === "fulfilled" ? text.value : "" };
    })
    .filter((p) => p.text.length >= INCOMING_MIN_PAGE_CHARS);
  if (readable.length === 0) {
    return { ok: true, suggestions: [], candidates: candidates.length };
  }

  const result = await askClaude({
    model: MODEL_ANALYSIS,
    effort: "medium",
    maxTokens: 12_000,
    system: `Tu es consultant SEO. Un nouveau contenu vient d’être créé sur un site. Parmi des pages existantes du même site, trouve celles qui devraient pointer vers lui, et pour chacune UNE phrase existante où un lien s’insère naturellement.
Règles :
- "sentence" est copiée caractère pour caractère depuis le texte de la page.
- "newSentence" reprend cette phrase avec une ancre de 2 à 6 mots intégrée, entourée de [[ et ]] ; la phrase peut être légèrement reformulée pour accueillir l’ancre, sans changer son sens.
- Ancre descriptive, jamais « cliquez ici ». Ne propose rien si le lien serait forcé.
- Maximum une suggestion par page, 8 au total, les plus pertinentes d’abord.
Réponds uniquement avec un tableau JSON entre <result> et </result> : [{"url": "…", "sentence": "…", "anchor": "…", "newSentence": "… [[ancre]] …", "reason": "…"}].`,
    content: [
      `NOUVEAU CONTENU : ${input.title}${input.keyword ? ` (mot-clé : ${input.keyword})` : ""}`,
      input.targetUrl ? `URL : ${input.targetUrl}` : null,
      `Résumé :\n${plain.slice(0, 2000)}`,
      `PAGES EXISTANTES :\n\n${readable
        .map((p) => `=== ${p.url} | ${p.title} ===\n${p.text}`)
        .join("\n\n")}`,
    ]
      .filter(Boolean)
      .join("\n\n"),
  });
  if (!result.ok) return result;

  const parsed = incomingSchema.safeParse(parseJsonResult(result.text));
  if (!parsed.success) {
    return { ok: false, message: "Réponse d’analyse illisible. Réessayez." };
  }
  const byUrl = new Map(readable.map((p) => [p.url, p]));
  const suggestions: IncomingLinkSuggestion[] = [];
  for (const s of parsed.data) {
    const page = byUrl.get(s.url);
    if (!page || !s.sentence || !s.newSentence?.includes("[[")) continue;
    suggestions.push({
      url: page.url,
      title: page.title,
      sentence: s.sentence.trim(),
      anchor: (s.anchor ?? "").trim(),
      newSentence: s.newSentence.trim(),
      reason: (s.reason ?? "").trim(),
      found: normalizeForMatch(page.text).includes(
        normalizeForMatch(s.sentence),
      ),
    });
  }
  return {
    ok: true,
    suggestions: suggestions.slice(0, 8),
    candidates: candidates.length,
  };
}

export const SemanticLinksService = { outgoing, incoming } as const;
