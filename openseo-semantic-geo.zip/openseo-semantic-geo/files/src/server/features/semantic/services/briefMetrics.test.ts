import { describe, expect, it } from "vitest";
import { tokenize } from "@/shared/semantic/text";
import type { SemanticBrief } from "@/shared/semantic/types";
import {
  competitorScores,
  medianReadability,
  pageMetrics,
  type ReadPage,
} from "./briefMetrics";
import { extractPage } from "./pageExtract";

const sentence = "Le chien dort sur le canapé du salon toute la journée.";
const paragraph = Array.from({ length: 4 }, () => sentence).join(" ");

function pageHtml(extra: string): string {
  return `<html><head><title>Guide du chien de garde</title>
<meta name="description" content="Tout savoir sur le chien de garde."></head>
<body><nav><a href="/menu">Menu</a></nav><main>
<h1>Le chien de garde</h1><p>${paragraph}</p>
<h2>Origine</h2><p>${paragraph}</p>
<h2>Soins</h2><p>${paragraph}</p>
${extra}
</main></body></html>`;
}

function readPage(rank: number, url: string, extra: string): ReadPage {
  const extracted = extractPage(pageHtml(extra));
  return {
    rank,
    url,
    domain: new URL(url).hostname,
    extracted,
    tokens: tokenize(extracted.blocks.join("\n")),
  };
}

const RICH = `<img src="a.png" alt="chien"><img src="b.png" alt="garde">
<iframe src="https://www.youtube.com/embed/abc"></iframe>
<table><tr><td>x</td></tr></table><ul><li>un</li><li>deux</li></ul>
<p><strong>gras</strong> <a href="/interne">lien</a> <a href="https://autre.org/x">externe</a></p>`;

describe("extractPage counts", () => {
  it("counts media, tables, lists, bold, links and reads the meta description", () => {
    const page = extractPage(pageHtml(RICH));
    expect(page.metaDescription).toBe("Tout savoir sur le chien de garde.");
    expect(page.imageCount).toBe(2);
    expect(page.videoCount).toBe(1);
    expect(page.tableCount).toBe(1);
    expect(page.listCount).toBe(1);
    expect(page.boldCount).toBe(1);
    // The menu link sits outside the main content.
    expect(page.hrefs).toEqual(["/interne", "https://autre.org/x"]);
  });

  it("ignores a social embed that is not a video player", () => {
    const page = extractPage(
      pageHtml('<iframe src="https://www.google.com/maps/embed?x=1"></iframe>'),
    );
    expect(page.videoCount).toBe(0);
  });
});

describe("pageMetrics", () => {
  it("measures a page like a draft", () => {
    const metrics = pageMetrics(readPage(1, "https://exemple.fr/guide", RICH));
    expect(metrics).toMatchObject({
      h2: 2,
      images: 2,
      videos: 1,
      tables: 1,
      lists: 1,
      bold: 1,
      internalLinks: 1,
      externalLinks: 1,
    });
    expect(metrics.paragraphs).toBeGreaterThanOrEqual(3);
  });
});

describe("medianReadability", () => {
  it("returns the median of the pages long enough to measure", () => {
    const pages = [1, 2, 3].map((n) =>
      readPage(n, `https://s${n}.fr/p`, `<p>${paragraph}</p>`),
    );
    const readability = medianReadability(pages, "fr");
    expect(readability?.flesch).toBeGreaterThan(0);
    expect(readability?.avgSentence).toBeGreaterThan(5);
    expect(medianReadability([], "fr")).toBeUndefined();
  });
});

describe("competitorScores", () => {
  const pages = [1, 2, 3].map((n) =>
    readPage(n, `https://s${n}.fr/chien-de-garde`, `<p>${paragraph}</p>`),
  );
  const base: SemanticBrief = {
    keyword: "chien de garde",
    languageCode: "fr",
    locationCode: 2250,
    fetchedAt: "2026-10-21T00:00:00.000Z",
    pagesRead: 3,
    pagesRequested: 3,
    pages: [],
    medianWords: 150,
    avgH2: 2,
    avgH3: 0,
    avgImages: 0,
    terms: [
      {
        term: "chien",
        kind: "word",
        pages: 3,
        avgCount: 12,
        q1: 10,
        median: 12,
        q3: 14,
        max: 16,
      },
      {
        term: "canapé",
        kind: "word",
        pages: 3,
        avgCount: 12,
        q1: 10,
        median: 12,
        q3: 14,
        max: 16,
      },
    ],
  };
  const countsByTerm = new Map([
    ["chien", [12, 11, 13]],
    ["canapé", [12, 12, 12]],
  ]);

  it("scores every page with the draft method and summarises the spread", () => {
    const result = competitorScores({
      pages,
      base,
      countsByTerm,
      keyword: "chien de garde",
      languageCode: "fr",
    });
    expect(result?.scores).toHaveLength(3);
    for (const entry of result?.scores ?? []) {
      expect(entry.score).toBeGreaterThanOrEqual(0);
      expect(entry.score).toBeLessThanOrEqual(100);
    }
    expect(result?.min).toBeLessThanOrEqual(result?.median ?? 0);
    expect(result?.median).toBeLessThanOrEqual(result?.max ?? 0);
  });

  it("needs at least two pages to say what to aim for", () => {
    expect(
      competitorScores({
        pages: pages.slice(0, 1),
        base,
        countsByTerm,
        keyword: "chien",
        languageCode: "fr",
      }),
    ).toBeUndefined();
  });
});
