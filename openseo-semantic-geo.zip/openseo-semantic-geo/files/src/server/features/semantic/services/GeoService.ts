import { z } from "zod";
import { GscConnectionRepository } from "@/server/features/gsc/repositories/GscConnectionRepository";
import { Ga4ConnectionRepository } from "@/server/features/ga4/repositories/Ga4ConnectionRepository";
import { getConfiguration } from "@/server/features/ai-visibility/repositories/aiVisibilityConfigurationRepository";
import { GeoSiteRepository } from "@/server/features/semantic/repositories/GeoSiteRepository";
import {
  askClaude,
  MODEL_ANALYSIS,
  parseJsonResult,
} from "@/server/lib/anthropic";
import { AppError } from "@/server/lib/errors";
import { GEO_CHECK_BY_ID, GEO_LLM_CHECK_IDS } from "@/shared/geo/catalog";
import type {
  GeoLiveFacts,
  GeoLlmAnalysis,
  GeoSiteFacts,
} from "@/shared/geo/types";
import { LOCATIONS } from "@/shared/keyword-locations";
import { htmlToPlainText } from "@/shared/semantic/html";
import type { SemanticResult } from "@/shared/semantic/types";
import { probeHtml } from "./liveProbe";
import { describeFetchFailure, fetchPageHtml } from "./pageFetch";

// Server side of the GEO module: reading the published page, asking an LLM
// for the judgement controls, and collecting what OpenSEO already knows about
// the project. Expected failures come back as data (see SemanticResult).

async function probeLive(
  url: string,
): Promise<SemanticResult<{ facts: GeoLiveFacts }>> {
  try {
    const html = await fetchPageHtml(url);
    return { ok: true, facts: probeHtml(html, url) };
  } catch (error) {
    const message = describeFetchFailure(error);
    if (message === null) throw error;
    return { ok: false, message };
  }
}

async function siteFacts(projectId: string): Promise<GeoSiteFacts> {
  const [gsc, ga4, configuration] = await Promise.all([
    GscConnectionRepository.getByProjectId(projectId),
    Ga4ConnectionRepository.getByProjectId(projectId),
    getConfiguration(projectId),
  ]);
  const tracker = configuration?.tracker;
  return {
    gscConnected: gsc !== null,
    ga4Connected: ga4 !== null,
    tracker: tracker
      ? {
          enabled: tracker.enabled,
          engines: [
            tracker.chatgpt,
            tracker.gemini,
            tracker.claude,
            tracker.perplexity,
            tracker.googleAiOverview,
          ].filter(Boolean).length,
          interval: tracker.scheduleInterval,
          promptCount:
            configuration?.prompts.filter((p) => !p.paused && !p.archived)
              .length ?? 0,
        }
      : null,
  };
}

async function siteState(projectId: string) {
  const [facts, checks] = await Promise.all([
    siteFacts(projectId),
    GeoSiteRepository.list(projectId),
  ]);
  return { facts, checks };
}

async function setSiteCheck(params: {
  projectId: string;
  checkId: string;
  done: boolean;
}): Promise<void> {
  // Only the site-level controls are stored per project.
  if (GEO_CHECK_BY_ID.get(params.checkId)?.scope !== "site") {
    throw new AppError("VALIDATION_ERROR");
  }
  await GeoSiteRepository.setCheck(params);
}

const MAX_TEXT_CHARS = 30_000;

const LLM_SYSTEM = `Tu es un évaluateur de contenus web pour les moteurs génératifs (ChatGPT, Perplexity, Gemini, Copilot, AI Overviews). Tu lis un contenu en français et tu l’évalues comme le ferait un moteur de réponse qui cherche des passages fiables à citer.

Tu juges uniquement ce que le texte permet de juger. Appuie-toi sur des éléments précis du texte, jamais sur des suppositions.

Évalue :
1. Un score global sur 20 : qualité du contenu telle qu’un LLM la perçoit (réponse directe, faits vérifiables, expertise démontrée, originalité, clarté).
2. Un diagnostic E-E-A-T : pour chacun des quatre axes (experience, expertise, authority, trust), un score de 0 à 5, ce qui le prouve dans le texte ("evidence", une phrase) et le conseil pour l’améliorer ("advice", une phrase).
3. Un verdict pour chacun de ces contrôles : status "ok", "warn" ou "fail" et une note courte ("note") qui cite le texte :
{{CHECKS}}
4. Jusqu’à 8 recommandations priorisées (priority 1 = la plus importante, 3 = secondaire), concrètes et actionnables : angles manquants, preuves à ajouter, structure, mentions d’auteur, sources, données.

Règles : pas de tiret cadratin dans tes textes ; "evidence", "advice" et "note" font une phrase. Réponds uniquement avec un objet JSON entre <result> et </result> :
<result>{"score": 14, "summary": "2 phrases", "eeat": {"experience": {"score": 3, "evidence": "…", "advice": "…"}, "expertise": {…}, "authority": {…}, "trust": {…}}, "checks": {"experience": {"status": "warn", "note": "…"}}, "recommendations": [{"priority": 1, "text": "…"}]}</result>`;

const axisSchema = z.object({
  score: z.number().min(0).max(5),
  evidence: z.string().default(""),
  advice: z.string().default(""),
});

const analysisSchema = z.object({
  score: z.number().min(0).max(20),
  summary: z.string().default(""),
  eeat: z.object({
    experience: axisSchema,
    expertise: axisSchema,
    authority: axisSchema,
    trust: axisSchema,
  }),
  checks: z.record(
    z.string(),
    z.object({
      status: z.enum(["ok", "warn", "fail"]),
      note: z.string().default(""),
    }),
  ),
  recommendations: z
    .array(
      z.object({
        priority: z.number().int().min(1).max(3),
        text: z.string(),
      }),
    )
    .default([]),
});

function asPriority(value: number): 1 | 2 | 3 {
  if (value <= 1) return 1;
  return value === 2 ? 2 : 3;
}

async function analyzeLlm(input: {
  html: string;
  title: string;
  keyword: string;
  locationCode: number;
  languageCode: string;
}): Promise<SemanticResult<{ analysis: GeoLlmAnalysis }>> {
  const text = htmlToPlainText(input.html).slice(0, MAX_TEXT_CHARS);
  if (text.length < 200) {
    return { ok: false, message: "Contenu trop court pour une analyse." };
  }
  const checks = GEO_LLM_CHECK_IDS.map((id) => {
    const def = GEO_CHECK_BY_ID.get(id);
    return `- "${id}" : ${def?.label ?? id}`;
  }).join("\n");

  const result = await askClaude({
    model: MODEL_ANALYSIS,
    system: LLM_SYSTEM.replace("{{CHECKS}}", checks),
    content: [
      input.title ? `Titre : ${input.title}` : null,
      input.keyword ? `Mot-clé principal : ${input.keyword}` : null,
      `Marché visé : ${LOCATIONS[input.locationCode] ?? input.locationCode}, langue « ${input.languageCode} ». Jugez le contenu pour ce public et rédigez votre réponse en français.`,
      `CONTENU À ÉVALUER :\n"""\n${text}\n"""`,
    ]
      .filter(Boolean)
      .join("\n\n"),
    maxTokens: 8_000,
    effort: "medium",
  });
  if (!result.ok) return result;

  const parsed = analysisSchema.safeParse(parseJsonResult(result.text));
  if (!parsed.success) {
    return { ok: false, message: "Réponse d’analyse illisible. Réessayez." };
  }
  const known = new Set(GEO_LLM_CHECK_IDS);
  const verdicts: GeoLlmAnalysis["checks"] = {};
  for (const [id, verdict] of Object.entries(parsed.data.checks)) {
    if (known.has(id)) verdicts[id] = verdict;
  }
  return {
    ok: true,
    analysis: {
      analyzedAt: new Date().toISOString(),
      score: Math.round(parsed.data.score),
      summary: parsed.data.summary,
      eeat: parsed.data.eeat,
      checks: verdicts,
      recommendations: parsed.data.recommendations
        .slice(0, 8)
        .map((r) => ({ priority: asPriority(r.priority), text: r.text })),
    },
  };
}

export const GeoService = {
  probeLive,
  siteState,
  setSiteCheck,
  analyzeLlm,
} as const;
