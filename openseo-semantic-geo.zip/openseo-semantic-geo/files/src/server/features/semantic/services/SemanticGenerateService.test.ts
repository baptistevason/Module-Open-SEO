import { beforeEach, describe, expect, it, vi } from "vitest";

const askClaude = vi.fn<(request: { model: string }) => Promise<unknown>>();

vi.mock("@/server/lib/anthropic", () => ({
  askClaude,
  MODEL_ANALYSIS: "analysis",
  MODEL_FAST: "fast",
  parseJsonResult: (text: string): unknown => {
    const tagged = /<result>([\s\S]*?)<\/result>/.exec(text);
    try {
      return JSON.parse((tagged ? tagged[1] : text).trim());
    } catch {
      return null;
    }
  },
}));

vi.mock("./SemanticAiService", () => ({
  siteContext: async () => "",
  cleanProposal: (text: string) => text.replace(/\s*[—–]\s*/g, ", ").trim(),
}));

const { SemanticGenerateService } = await import("./SemanticGenerateService");

const base = {
  projectId: "p",
  html: "<h1>Dogue</h1><p>Texte du contenu.</p>",
  title: "Dogue de Majorque",
  keyword: "dogue de majorque",
  terms: ["gardien"],
  headings: ["Origine"],
};

const reply = (value: unknown) =>
  askClaude.mockResolvedValue({
    ok: true,
    text: `<result>${JSON.stringify(value)}</result>`,
    inputTokens: 1,
    outputTokens: 1,
  });

const words = (n: number) => Array.from({ length: n }, () => "mot").join(" ");

beforeEach(() => askClaude.mockReset());

describe("SemanticGenerateService.generate", () => {
  it("returns a cleaned FAQ", async () => {
    reply([
      {
        question: "Quelle est sa taille ?",
        answer: "Environ 60 cm — selon le sexe.",
      },
      { question: "", answer: "ignorée" },
    ]);
    const result = await SemanticGenerateService.generate({
      ...base,
      kind: "faq",
    });
    if (!result.ok || result.content.kind !== "faq")
      throw new Error("expected faq");
    expect(result.content.items).toHaveLength(1);
    expect(result.content.items[0].answer).toBe(
      "Environ 60 cm, selon le sexe.",
    );
    expect(askClaude.mock.calls[0][0].model).toBe("analysis");
  });

  it("keeps the blurb versions of the right length", async () => {
    reply([words(60), words(10), words(75)]);
    const result = await SemanticGenerateService.generate({
      ...base,
      kind: "blurb",
    });
    if (!result.ok || result.content.kind !== "blurb")
      throw new Error("expected blurb");
    expect(result.content.options).toHaveLength(2);
    expect(askClaude.mock.calls[0][0].model).toBe("fast");
  });

  it("returns title and meta description options", async () => {
    reply({ titles: ["Un titre"], descriptions: ["Une méta", "Une autre"] });
    const result = await SemanticGenerateService.generate({
      ...base,
      kind: "meta",
    });
    if (!result.ok || result.content.kind !== "meta")
      throw new Error("expected meta");
    expect(result.content.titles).toEqual(["Un titre"]);
    expect(result.content.descriptions).toHaveLength(2);
  });

  it("returns an outline, tolerating sections without sub-headings", async () => {
    reply([{ h2: "Origine", h3: ["Histoire"] }, { h2: "Soins" }]);
    const result = await SemanticGenerateService.generate({
      ...base,
      kind: "outline",
    });
    if (!result.ok || result.content.kind !== "outline")
      throw new Error("expected outline");
    expect(result.content.sections).toEqual([
      { h2: "Origine", h3: ["Histoire"] },
      { h2: "Soins", h3: [] },
    ]);
  });

  it("explains an unreadable answer and passes failures through", async () => {
    askClaude.mockResolvedValue({
      ok: true,
      text: "pas du json",
      inputTokens: 0,
      outputTokens: 0,
    });
    expect(
      await SemanticGenerateService.generate({ ...base, kind: "faq" }),
    ).toMatchObject({ ok: false });
    askClaude.mockResolvedValue({ ok: false, message: "Clé refusée" });
    expect(
      await SemanticGenerateService.generate({ ...base, kind: "faq" }),
    ).toEqual({
      ok: false,
      message: "Clé refusée",
    });
  });

  it("asks for a keyword or a title before spending a call", async () => {
    const result = await SemanticGenerateService.generate({
      ...base,
      kind: "faq",
      keyword: "",
      title: "",
    });
    expect(result).toMatchObject({ ok: false });
    expect(askClaude).not.toHaveBeenCalled();
  });
});
