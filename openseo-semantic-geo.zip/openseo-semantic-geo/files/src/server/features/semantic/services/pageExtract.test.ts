import { describe, expect, it } from "vitest";
import { extractPage } from "./pageExtract";

describe("extractPage", () => {
  it("keeps headings and paragraphs and drops navigation and scripts", () => {
    const page =
      extractPage(`<html><head><title> Mon  titre </title></head><body>
      <nav><a>Accueil</a></nav>
      <h1>Collier de dressage</h1>
      <p>Un texte <b>important</b> sur le collier.</p>
      <script>var x = 1;</script>
      <h2>Bien choisir</h2><p>Deuxième paragraphe.</p>
      <img src="a.png"><footer>Mentions légales</footer>
    </body></html>`);
    expect(page.title).toBe("Mon titre");
    expect(page.headings).toEqual([
      { level: 1, text: "Collier de dressage" },
      { level: 2, text: "Bien choisir" },
    ]);
    expect(page.blocks.join(" ")).not.toMatch(/Accueil|Mentions|var x/);
    expect(page.imageCount).toBe(1);
    expect(page.html).toContain("<h2>Bien choisir</h2>");
  });

  it("reads only inside <main> when the page declares one", () => {
    const page = extractPage(`<body>
      <div>Liste des langues : Deutsch English Español</div>
      <main><h1>Chien</h1><p>Le chien est un mammifère.</p></main>
      <div>Autre bloc hors contenu</div></body>`);
    expect(page.blocks).toEqual(["Chien", "Le chien est un mammifère."]);
  });

  it("drops long runs of short link-only items (menus, language lists)", () => {
    const langs = [
      "Deutsch",
      "English",
      "Español",
      "Italiano",
      "Nederlands",
      "Polski",
      "Svenska",
    ]
      .map((l) => `<li><a href="/${l}">${l}</a></li>`)
      .join("");
    const page = extractPage(
      `<main><h1>Chien</h1><ul>${langs}</ul><p>Le chien est un mammifère domestique.</p>` +
        `<ul><li><a href="/x">Un lien</a></li><li>Une vraie phrase de liste</li></ul></main>`,
    );
    expect(page.blocks).toEqual([
      "Chien",
      "Le chien est un mammifère domestique.",
      "Un lien",
      "Une vraie phrase de liste",
    ]);
  });

  it("ignores ARIA landmarks and hidden elements", () => {
    const page = extractPage(
      `<main><div role="navigation">Menu</div><p aria-hidden="true">Caché</p><p>Visible</p></main>`,
    );
    expect(page.blocks).toEqual(["Visible"]);
  });
});
