import { beforeEach, describe, expect, it, vi } from "vitest";

const getPerformance = vi.fn();

class GscNotConnectedError extends Error {}

vi.mock("@/server/features/gsc/services/GscService", () => ({
  GscService: { getPerformance },
  GscNotConnectedError,
  isExpectedGrantFailure: () => false,
}));

const { SemanticGscService } = await import("./SemanticGscService");

const DAY_MS = 24 * 60 * 60 * 1000;
const iso = (offsetDays: number) =>
  new Date(Date.now() + offsetDays * DAY_MS).toISOString();

function rowsFor(clicks: number, impressions: number, position: number) {
  return { rows: [{ clicks, impressions, ctr: 0, position }] };
}

beforeEach(() => {
  getPerformance.mockReset();
});

describe("SemanticGscService.afterPublish", () => {
  it("rejects a URL that cannot be a page", async () => {
    const result = await SemanticGscService.afterPublish({
      projectId: "p",
      pageUrl: "pas une url",
      publishedAt: iso(-30),
      keyword: "",
    });
    expect(result).toEqual({ connected: true, status: "no_url" });
    expect(getPerformance).not.toHaveBeenCalled();
  });

  it("says it is too early before a week of data exists", async () => {
    const result = await SemanticGscService.afterPublish({
      projectId: "p",
      pageUrl: "https://exemple.fr/a",
      publishedAt: iso(-2),
      keyword: "",
    });
    expect(result).toMatchObject({ status: "too_early" });
    expect(getPerformance).not.toHaveBeenCalled();
  });

  it("compares equal windows around the publication day", async () => {
    getPerformance
      .mockResolvedValueOnce(rowsFor(10, 100, 12))
      .mockResolvedValueOnce(rowsFor(30, 300, 8))
      .mockResolvedValueOnce(rowsFor(4, 40, 15))
      .mockResolvedValueOnce(rowsFor(9, 90, 9));
    const result = await SemanticGscService.afterPublish({
      projectId: "p",
      pageUrl: "https://exemple.fr/a",
      publishedAt: iso(-40),
      keyword: "collier",
    });
    if (!result.connected || result.status !== "ready") {
      throw new Error("expected a ready result");
    }
    expect(result.windowDays).toBe(28);
    expect(result.before.clicks).toBe(10);
    expect(result.after.clicks).toBe(30);
    expect(result.keywordAfter?.impressions).toBe(90);
    // Publication day excluded, both windows 28 days long.
    const days = (a: string, b: string) =>
      (Date.parse(b) - Date.parse(a)) / DAY_MS + 1;
    expect(days(result.before.startDate, result.before.endDate)).toBe(28);
    expect(days(result.after.startDate, result.after.endDate)).toBe(28);
    expect(result.before.endDate < result.after.startDate).toBe(true);
  });

  it("retries the trailing-slash variant when the first finds nothing", async () => {
    getPerformance.mockResolvedValue(rowsFor(0, 0, 0));
    getPerformance
      .mockResolvedValueOnce(rowsFor(0, 0, 0))
      .mockResolvedValueOnce(rowsFor(0, 0, 0))
      .mockResolvedValueOnce(rowsFor(5, 50, 10))
      .mockResolvedValueOnce(rowsFor(8, 80, 9));
    const result = await SemanticGscService.afterPublish({
      projectId: "p",
      pageUrl: "https://exemple.fr/a",
      publishedAt: iso(-40),
      keyword: "",
    });
    if (!result.connected || result.status !== "ready") {
      throw new Error("expected a ready result");
    }
    expect(result.after.clicks).toBe(8);
    const filters = getPerformance.mock.calls.map((call: unknown[]) =>
      JSON.stringify(call[0]),
    );
    expect(filters.some((f) => f.includes("https://exemple.fr/a/"))).toBe(true);
  });

  it("reports Search Console as not connected", async () => {
    getPerformance.mockRejectedValue(new GscNotConnectedError("p"));
    const result = await SemanticGscService.afterPublish({
      projectId: "p",
      pageUrl: "https://exemple.fr/a",
      publishedAt: iso(-40),
      keyword: "",
    });
    expect(result).toEqual({ connected: false });
  });
});

describe("SemanticGscService.cannibalization", () => {
  it("lists the ranking pages by impressions", async () => {
    getPerformance.mockResolvedValue({
      rows: [
        {
          keys: ["https://a.fr/1"],
          clicks: 1,
          impressions: 20,
          ctr: 0,
          position: 9,
        },
        {
          keys: ["https://a.fr/2"],
          clicks: 5,
          impressions: 200,
          ctr: 0,
          position: 4,
        },
      ],
    });
    const result = await SemanticGscService.cannibalization({
      projectId: "p",
      keyword: "Collier",
    });
    if (!result.connected) throw new Error("expected connected");
    expect(result.pages.map((p) => p.page)).toEqual([
      "https://a.fr/2",
      "https://a.fr/1",
    ]);
    expect(JSON.stringify(getPerformance.mock.calls[0][0])).toContain(
      "collier",
    );
  });

  it("reports Search Console as not connected", async () => {
    getPerformance.mockRejectedValue(new GscNotConnectedError("p"));
    const result = await SemanticGscService.cannibalization({
      projectId: "p",
      keyword: "collier",
    });
    expect(result).toEqual({ connected: false });
  });
});
