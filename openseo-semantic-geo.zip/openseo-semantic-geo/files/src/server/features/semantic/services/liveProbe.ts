/**
 * Reads the GEO-relevant facts of a published page: head metadata, structured
 * data, images, share tags. Built on htmlparser2's tokenizer like the other
 * page readers (no DOM, bounded memory).
 */
import { Parser } from "htmlparser2";
import type { GeoLiveFacts } from "@/shared/geo/types";

const MAX_JSON_LD_CHARS = 200_000;
const READING_TIME =
  /temps de lecture|\b\d+\s*(?:min|mn|minutes?)\s*(?:de lecture|read)|\bmin(?:utes?)?\s+read\b/i;
const SKIPPED_TEXT_TAGS = new Set(["script", "style", "noscript", "svg"]);

type JsonLdSummary = {
  types: Set<string>;
  author: boolean;
  datePublished: boolean;
  dateModified: boolean;
  publisher: boolean;
};

function collectTypes(value: unknown, out: JsonLdSummary, depth = 0): void {
  if (depth > 8 || value === null || typeof value !== "object") return;
  if (Array.isArray(value)) {
    for (const item of value) collectTypes(item, out, depth + 1);
    return;
  }
  const node: Record<string, unknown> = Object.fromEntries(
    Object.entries(value),
  );
  const type = node["@type"];
  const types = Array.isArray(type) ? type : [type];
  for (const t of types) if (typeof t === "string") out.types.add(t);
  if (node.author) out.author = true;
  if (node.datePublished) out.datePublished = true;
  if (node.dateModified) out.dateModified = true;
  if (node.publisher) out.publisher = true;
  if (types.includes("Organization")) out.publisher = true;
  for (const child of Object.values(node)) collectTypes(child, out, depth + 1);
}

export function summarizeJsonLd(blocks: string[]): JsonLdSummary {
  const out: JsonLdSummary = {
    types: new Set(),
    author: false,
    datePublished: false,
    dateModified: false,
    publisher: false,
  };
  for (const raw of blocks) {
    try {
      collectTypes(JSON.parse(raw), out);
    } catch {
      // A malformed block simply contributes nothing.
    }
  }
  return out;
}

export function probeHtml(html: string, url: string): GeoLiveFacts {
  let title = "";
  let inTitle = false;
  let metaDescription = "";
  let canonical: string | null = null;
  let lang: string | null = null;
  const hreflangs: string[] = [];
  const flags = {
    ogTitle: false,
    ogDescription: false,
    ogImage: false,
    twitterCard: false,
    metaAuthor: false,
    hasTimeTag: false,
    breadcrumbMarkup: false,
  };
  let imageCount = 0;
  let imagesMissingAlt = 0;
  let tableCount = 0;
  const jsonLd: string[] = [];
  let jsonLdBuffer: string | null = null;
  let skipDepth = 0;
  let text = "";

  const parser = new Parser(
    {
      onopentag(name, attribs) {
        if (name === "html") lang = attribs.lang ?? null;
        if (name === "title") inTitle = true;
        if (name === "meta") {
          const key = (attribs.name ?? attribs.property ?? "").toLowerCase();
          const content = attribs.content ?? "";
          if (key === "description") metaDescription = content;
          else if (key === "og:title") flags.ogTitle = content !== "";
          else if (key === "og:description")
            flags.ogDescription = content !== "";
          else if (key === "og:image") flags.ogImage = content !== "";
          else if (key === "twitter:card") flags.twitterCard = content !== "";
          else if (key === "author") flags.metaAuthor = content !== "";
        }
        if (name === "link") {
          if (attribs.rel === "canonical") canonical = attribs.href ?? null;
          if (attribs.rel === "alternate" && attribs.hreflang) {
            hreflangs.push(attribs.hreflang);
          }
        }
        if (name === "script" && (attribs.type ?? "").includes("ld+json")) {
          jsonLdBuffer = "";
        }
        if (name === "img") {
          imageCount++;
          if (!(attribs.alt ?? "").trim()) imagesMissingAlt++;
        }
        if (name === "table") tableCount++;
        if (name === "time") flags.hasTimeTag = true;
        const marker =
          `${attribs.class ?? ""} ${attribs["aria-label"] ?? ""}`.toLowerCase();
        if (/breadcrumb|fil[- ]d.?ariane/.test(marker))
          flags.breadcrumbMarkup = true;
        if (SKIPPED_TEXT_TAGS.has(name)) skipDepth++;
      },
      ontext(chunk) {
        if (inTitle) title += chunk;
        else if (jsonLdBuffer !== null) {
          if (jsonLdBuffer.length < MAX_JSON_LD_CHARS) jsonLdBuffer += chunk;
        } else if (skipDepth === 0 && text.length < 400_000)
          text += ` ${chunk}`;
      },
      onclosetag(name) {
        if (name === "title") inTitle = false;
        if (name === "script" && jsonLdBuffer !== null) {
          jsonLd.push(jsonLdBuffer);
          jsonLdBuffer = null;
        }
        if (SKIPPED_TEXT_TAGS.has(name)) skipDepth = Math.max(0, skipDepth - 1);
      },
    },
    { decodeEntities: true },
  );
  parser.write(html);
  parser.end();

  const schema = summarizeJsonLd(jsonLd);
  const plain = text.replace(/\s+/g, " ").trim();
  return {
    url,
    fetchedAt: new Date().toISOString(),
    title: title.replace(/\s+/g, " ").trim(),
    metaDescription: metaDescription.trim(),
    canonical,
    lang,
    hreflangs,
    ogTitle: flags.ogTitle,
    ogDescription: flags.ogDescription,
    ogImage: flags.ogImage,
    twitterCard: flags.twitterCard,
    jsonLdTypes: [...schema.types],
    jsonLdAuthor: schema.author,
    jsonLdDatePublished: schema.datePublished,
    jsonLdDateModified: schema.dateModified,
    hasBreadcrumb: schema.types.has("BreadcrumbList") || flags.breadcrumbMarkup,
    hasPublisher: schema.publisher,
    metaAuthor: flags.metaAuthor,
    imageCount,
    imagesMissingAlt,
    hasTimeTag: flags.hasTimeTag,
    readingTimeShown: READING_TIME.test(plain),
    wordCount: plain ? plain.split(" ").length : 0,
    tableCount,
  };
}
