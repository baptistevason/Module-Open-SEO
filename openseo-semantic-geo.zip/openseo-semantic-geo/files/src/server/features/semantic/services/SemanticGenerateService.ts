import { z } from "zod";
import {
  askClaude,
  MODEL_ANALYSIS,
  MODEL_FAST,
  parseJsonResult,
} from "@/server/lib/anthropic";
import { countWords } from "@/shared/semantic/geo";
import { htmlToPlainText } from "@/shared/semantic/html";
import type {
  GenerateKind,
  GeneratedContent,
  OutlineSection,
} from "@/shared/semantic/generate";
import type { SemanticResult } from "@/shared/semantic/types";
import { cleanProposal, siteContext } from "./SemanticAiService";

// Text generation for the editor: FAQ, GEO introduction (blurb), title and
// meta description, article outline. Expected failures come back as data.

const TEXT_CHARS = 8_000;
const BLURB_MIN_WORDS = 40;
const BLURB_MAX_WORDS = 80;

export type GenerateInput = {
  projectId: string;
  kind: GenerateKind;
  html: string;
  title: string;
  keyword: string;
  /** Terms of the lexical field the text should weave in naturally. */
  terms: string[];
  /** Sub-headings of the pages that rank, as a hint of the topics expected. */
  headings: string[];
};

const COMMON_RULES = `Règles communes : français, ton clair et direct, aucun fait, chiffre, date, nom ou source inventé (si une donnée est incertaine, formule sans chiffre), pas de tiret cadratin (—) ni demi-cadratin (–), pas de tournure creuse du type « il est essentiel de » ou « dans un monde où », texte brut sans HTML ni Markdown.`;

const SYSTEMS: Record<GenerateKind, string> = {
  faq: `Tu rédiges la FAQ d’une page web, pour les internautes et pour les moteurs génératifs (ChatGPT, Perplexity, Gemini).
Propose 6 questions que les internautes se posent réellement sur le sujet, formulées comme ils les tapent, qui couvrent des angles différents de ceux déjà traités dans le contenu fourni. Chaque réponse fait 35 à 60 mots, commence par la réponse directe, puis précise.
${COMMON_RULES}
Réponds uniquement avec un tableau JSON entre <result> et </result> : <result>[{"question": "…?", "answer": "…"}]</result>`,
  blurb: `Tu rédiges l’introduction d’une page (le « blurb GEO ») : le passage qu’un moteur génératif reprendra tel quel.
Propose 3 versions différentes de ${BLURB_MIN_WORDS} à ${BLURB_MAX_WORDS} mots (idéalement 55 à 70). Chacune répond directement à la question de la page dès la première phrase, contient le mot-clé exact, sans mise en contexte ni annonce de plan. Appuie-toi uniquement sur le contenu fourni pour les faits.
${COMMON_RULES}
Réponds uniquement avec un tableau JSON entre <result> et </result> : <result>["version 1", "version 2", "version 3"]</result>`,
  meta: `Tu rédiges le title et la méta description d’une page.
Propose 3 titres de 40 à 60 caractères avec le mot-clé exact au début ou dans la première moitié (si le mot-clé contient un sigle, ajoute sa forme développée entre parenthèses quand elle tient dans la limite), et 3 méta descriptions de 130 à 150 caractères qui décrivent réellement la page et donnent envie de cliquer, avec une incitation à l’action.
${COMMON_RULES}
Réponds uniquement avec un objet JSON entre <result> et </result> : <result>{"titles": ["…"], "descriptions": ["…"]}</result>`,
  outline: `Tu conçois le plan d’un article web.
Propose 5 à 8 sections H2, dont certaines avec 2 à 3 sous-sections H3. Les titres sont informatifs (on comprend la section sans lire le texte), répondent à l’intention de recherche et couvrent les sujets que les pages concurrentes traitent (liste fournie) sans les recopier, en apportant un angle utile. Pas de numérotation, pas de section FAQ ni de conclusion générique.
${COMMON_RULES}
Réponds uniquement avec un tableau JSON entre <result> et </result> : <result>[{"h2": "…", "h3": ["…"]}]</result>`,
};

const faqSchema = z.array(
  z.object({ question: z.string(), answer: z.string() }),
);
const blurbSchema = z.array(z.string());
const metaSchema = z.object({
  titles: z.array(z.string()),
  descriptions: z.array(z.string()),
});
const outlineSchema = z.array(
  z.object({ h2: z.string(), h3: z.array(z.string()).default([]) }),
);

const UNREADABLE = "Réponse illisible. Réessayez.";

function buildContent(input: GenerateInput, context: string): string {
  const text = htmlToPlainText(input.html).slice(0, TEXT_CHARS);
  return [
    context ? `Contexte du projet :\n${context}` : null,
    input.title ? `Titre : ${input.title}` : null,
    input.keyword ? `Mot-clé principal : ${input.keyword}` : null,
    input.terms.length > 0
      ? `Termes à intégrer naturellement quand c’est pertinent : ${input.terms.join(", ")}`
      : null,
    input.headings.length > 0
      ? `Sous-titres des pages concurrentes (sujets attendus) :\n${input.headings.map((h) => `- ${h}`).join("\n")}`
      : null,
    text
      ? `CONTENU ACTUEL (ne pas recopier, éviter les redites) :\n"""\n${text}\n"""`
      : "Le contenu est encore vide.",
  ]
    .filter(Boolean)
    .join("\n\n");
}

function clean(values: string[], limit: number): string[] {
  return values
    .map((value) => cleanProposal(value))
    .filter(Boolean)
    .slice(0, limit);
}

function parseResult(
  kind: GenerateKind,
  raw: unknown,
): GeneratedContent | null {
  if (kind === "faq") {
    const parsed = faqSchema.safeParse(raw);
    if (!parsed.success) return null;
    const items = parsed.data
      .map((item) => ({
        question: cleanProposal(item.question),
        answer: cleanProposal(item.answer),
      }))
      .filter((item) => item.question && item.answer)
      .slice(0, 8);
    return items.length > 0 ? { kind, items } : null;
  }
  if (kind === "blurb") {
    const parsed = blurbSchema.safeParse(raw);
    if (!parsed.success) return null;
    const options = clean(parsed.data, 3);
    // Prefer the versions inside the target length; keep all if none is.
    const inRange = options.filter((o) => {
      const words = countWords(o);
      return words >= BLURB_MIN_WORDS - 5 && words <= BLURB_MAX_WORDS + 10;
    });
    const kept = inRange.length > 0 ? inRange : options;
    return kept.length > 0 ? { kind, options: kept } : null;
  }
  if (kind === "meta") {
    const parsed = metaSchema.safeParse(raw);
    if (!parsed.success) return null;
    const titles = clean(parsed.data.titles, 3);
    const descriptions = clean(parsed.data.descriptions, 3);
    return titles.length + descriptions.length > 0
      ? { kind, titles, descriptions }
      : null;
  }
  const parsed = outlineSchema.safeParse(raw);
  if (!parsed.success) return null;
  const sections: OutlineSection[] = parsed.data
    .map((section) => ({
      h2: cleanProposal(section.h2),
      h3: clean(section.h3, 4),
    }))
    .filter((section) => section.h2)
    .slice(0, 10);
  return sections.length > 0 ? { kind, sections } : null;
}

async function generate(
  input: GenerateInput,
): Promise<SemanticResult<{ content: GeneratedContent }>> {
  if (!input.keyword.trim() && !input.title.trim()) {
    return {
      ok: false,
      message: "Renseignez le mot-clé ou le titre pour guider la génération.",
    };
  }
  const context = await siteContext(input.projectId);
  const result = await askClaude({
    model:
      input.kind === "faq" || input.kind === "outline"
        ? MODEL_ANALYSIS
        : MODEL_FAST,
    system: SYSTEMS[input.kind],
    content: buildContent(input, context),
    maxTokens: 4_000,
    effort: "low",
  });
  if (!result.ok) return result;

  const content = parseResult(input.kind, parseJsonResult(result.text));
  if (!content) return { ok: false, message: UNREADABLE };
  return { ok: true, content };
}

export const SemanticGenerateService = { generate } as const;
