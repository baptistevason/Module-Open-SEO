import { AppError } from "@/server/lib/errors";
import { SemanticDocumentRepository } from "@/server/features/semantic/repositories/SemanticDocumentRepository";
import {
  SEMANTIC_MAX_DOCUMENTS_PER_PROJECT,
  type SemanticDocument,
  type SemanticDocumentSummary,
} from "@/types/schemas/semantic-documents";

// Authorization is NOT done here: the caller has already authorized
// `projectId`, and every query is scoped to it.

async function list(projectId: string): Promise<SemanticDocumentSummary[]> {
  return SemanticDocumentRepository.list(projectId);
}

async function get(projectId: string, id: string): Promise<SemanticDocument> {
  const document = await SemanticDocumentRepository.get(projectId, id);
  if (!document) throw new AppError("NOT_FOUND");
  return document;
}

type SaveParams = {
  projectId: string;
  id?: string;
  createdBy: string;
  fields: {
    title: string;
    keyword: string;
    titleTag: string;
    metaDescription: string;
    slug: string;
    pageUrl: string;
    contentHtml: string;
    score: number | null;
    brief: string | null;
    locationCode?: number | null;
    languageCode?: string | null;
  };
};

/** Creates the draft, or updates it when `id` is given. */
async function save(params: SaveParams): Promise<{
  id: string;
  updatedAt: string;
}> {
  const fields = {
    ...params.fields,
    title: params.fields.title || params.fields.keyword || "Sans titre",
  };

  if (params.id) {
    const updatedAt = await SemanticDocumentRepository.update({
      id: params.id,
      projectId: params.projectId,
      fields,
    });
    if (!updatedAt) throw new AppError("NOT_FOUND");
    return { id: params.id, updatedAt };
  }

  const total = await SemanticDocumentRepository.countForProject(
    params.projectId,
  );
  if (total >= SEMANTIC_MAX_DOCUMENTS_PER_PROJECT) {
    throw new AppError("CONFLICT");
  }
  const id = crypto.randomUUID();
  const updatedAt = await SemanticDocumentRepository.insert({
    id,
    projectId: params.projectId,
    createdBy: params.createdBy,
    fields,
  });
  return { id, updatedAt };
}

/** Marks the content as pushed to production, or takes it back out. */
async function setPublished(params: {
  projectId: string;
  id: string;
  published: boolean;
}): Promise<{ publishedAt: string | null }> {
  const result = await SemanticDocumentRepository.setPublished(params);
  if (!result) throw new AppError("NOT_FOUND");
  return result;
}

async function saveGeoState(params: {
  projectId: string;
  id: string;
  checks: Record<string, boolean>;
  live: string | null;
  llm: string | null;
  score: number;
  llmScore: number | null;
}): Promise<{ analyzedAt: string }> {
  const analyzedAt = await SemanticDocumentRepository.saveGeoState({
    ...params,
    checks: JSON.stringify(params.checks),
  });
  if (!analyzedAt) throw new AppError("NOT_FOUND");
  return { analyzedAt };
}

async function remove(projectId: string, id: string): Promise<void> {
  const removed = await SemanticDocumentRepository.remove(projectId, id);
  if (!removed) throw new AppError("NOT_FOUND");
}

export const SemanticDocumentService = {
  list,
  get,
  save,
  setPublished,
  saveGeoState,
  remove,
} as const;
