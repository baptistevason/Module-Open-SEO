import {
  analyzeDraft,
  compareWithCounts,
  scoreDraft,
  type TermComparison,
} from "@/shared/semantic/analyze";
import { termDistribution } from "@/shared/semantic/bands";
import { countWords } from "@/shared/semantic/geo";
import { parseHtmlDraft } from "@/shared/semantic/html";
import { analyzeReadability } from "@/shared/semantic/readability";
import {
  countLinks,
  hostOf,
  PARAGRAPH_MIN_WORDS,
  type MetricCounts,
} from "@/shared/semantic/targets";
import type {
  BriefReadability,
  BriefScoreTarget,
  SemanticBrief,
} from "@/shared/semantic/types";
import type { ExtractedPage } from "./pageExtract";

// What is measured on each ranking page beyond its words and terms: the counts
// that become targets, the readability, and a score computed with the same
// method as the draft's, so the score to aim for comes from the pages that rank.

export type ReadPage = {
  rank: number;
  url: string;
  domain: string;
  extracted: ExtractedPage;
  tokens: string[];
};

function median(values: number[]): number {
  const sorted = [...values];
  sorted.sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] ?? 0;
}

/** The counts of one ranking page, measured like the draft's. */
export function pageMetrics(page: ReadPage): MetricCounts {
  const { extracted } = page;
  const doc = parseHtmlDraft(extracted.html);
  const links = countLinks(extracted.hrefs, hostOf(page.url));
  return {
    words: page.tokens.length,
    h2: extracted.headings.filter((h) => h.level === 2).length,
    h3: extracted.headings.filter((h) => h.level === 3).length,
    paragraphs: doc.paragraphs.filter(
      (p) => countWords(p) >= PARAGRAPH_MIN_WORDS,
    ).length,
    images: extracted.imageCount,
    videos: extracted.videoCount,
    tables: extracted.tableCount,
    lists: extracted.listCount,
    bold: extracted.boldCount,
    internalLinks: links.internal,
    externalLinks: links.external,
  };
}

/** Median readability of the pages whose text is long enough to measure. */
export function medianReadability(
  pages: ReadPage[],
  languageCode: string,
): BriefReadability | undefined {
  const measured = pages
    .map((p) => analyzeReadability(p.extracted.blocks.join("\n"), languageCode))
    .filter((r): r is NonNullable<typeof r> => r !== null);
  if (measured.length === 0) return undefined;
  return {
    flesch: median(measured.map((r) => r.flesch)),
    avgSentence: median(measured.map((r) => r.avgSentence)),
    longSentenceShare: median(measured.map((r) => r.longSentenceShare)),
    passiveShare: median(measured.map((r) => r.passiveShare)),
  };
}

function slugOf(url: string): string {
  try {
    return (
      new URL(url).pathname.split("/").filter(Boolean).at(-1)?.toLowerCase() ??
      ""
    );
  } catch {
    return "";
  }
}

/**
 * Score of each ranking page with the draft's method. The lexical part of a
 * page is judged against the other pages only (leave-one-out): a page must not
 * be graded against zones it helped to draw.
 */
export function competitorScores(input: {
  pages: ReadPage[];
  base: SemanticBrief;
  /** Uses of each term per page, aligned with `pages` (zero when absent). */
  countsByTerm: Map<string, number[]>;
  keyword: string;
  languageCode: string;
}): BriefScoreTarget | undefined {
  const { pages, base, countsByTerm } = input;
  if (pages.length < 2) return undefined;

  const scores = pages.map((page, index) => {
    const analysis = analyzeDraft({
      title: page.extracted.title,
      meta: page.extracted.metaDescription,
      slug: slugOf(page.url),
      html: page.extracted.html,
      keyword: input.keyword,
      languageCode: input.languageCode,
    });
    const terms = base.terms.map<TermComparison>((term) => {
      const all = countsByTerm.get(term.term) ?? [];
      const others = all.filter((_, j) => j !== index && all[j] > 0);
      const yours = all[index] ?? 0;
      return {
        ...term,
        ...termDistribution(others, pages.length - 1),
        yours,
        covered: yours > 0,
      };
    });
    const comparison = compareWithCounts(
      terms,
      analysis.totalWords,
      base.medianWords,
    );
    return {
      rank: page.rank,
      domain: page.domain,
      score: scoreDraft(analysis, base, comparison).score,
    };
  });

  const values = scores.map((s) => s.score);
  return {
    median: median(values),
    min: Math.min(...values),
    max: Math.max(...values),
    scores,
  };
}
