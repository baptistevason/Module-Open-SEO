import { AppError } from "@/server/lib/errors";
import {
  isCrawlableUrl,
  normalizeAndValidateStartUrl,
} from "@/server/lib/audit/url-policy";
import { MAX_HTML_BYTES, readTextUpTo } from "@/server/lib/audit/html-response";

/** A fetch failure whose message is safe and useful to show the user. */
export class PageFetchError extends Error {}

const FETCH_TIMEOUT_MS = 10_000;
const MAX_REDIRECTS = 3;

/**
 * Download one page's HTML for analysis. The start URL is fully validated
 * (scheme, blocked hosts, DNS), and every redirect hop is re-checked so a
 * public URL cannot bounce the worker to an internal address.
 */
export async function fetchPageHtml(inputUrl: string): Promise<string> {
  let current = await normalizeAndValidateStartUrl(inputUrl);

  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const response = await fetch(current, {
      redirect: "manual",
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; OpenSEO-Semantic/1.0)",
        Accept: "text/html,application/xhtml+xml",
      },
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });

    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) break;
      const next = new URL(location, current).toString();
      if (!isCrawlableUrl(next)) throw new AppError("CRAWL_TARGET_BLOCKED");
      current = next;
      continue;
    }
    if (!response.ok) {
      throw new PageFetchError(`La page a répondu ${response.status}.`);
    }
    const type = response.headers.get("content-type") ?? "";
    if (!/html|xml/i.test(type)) {
      throw new PageFetchError("Cette URL n’est pas une page HTML.");
    }
    return readTextUpTo(response, MAX_HTML_BYTES);
  }
  throw new PageFetchError("Trop de redirections.");
}

/** User-facing reason for a page that could not be fetched, or null if unexpected. */
export function describeFetchFailure(error: unknown): string | null {
  if (error instanceof PageFetchError) return error.message;
  if (error instanceof AppError) {
    if (error.code === "CRAWL_TARGET_BLOCKED") {
      return "Cette adresse est bloquée par la politique de sécurité.";
    }
    if (error.code === "VALIDATION_ERROR") return "URL invalide.";
  }
  if (
    error instanceof Error &&
    /timeout|abort/i.test(error.name + error.message)
  ) {
    return "La page a mis trop de temps à répondre.";
  }
  if (error instanceof TypeError) return "Impossible de joindre cette page.";
  return null;
}
