/**
 * Readable-content extraction for the Sémantique module, built on htmlparser2's
 * tokenizer like the audit analyzer (no DOM, bounded memory). It keeps the
 * headings and the visible text blocks of the main content, and drops
 * navigation, footers, forms and scripts.
 */
import { Parser } from "htmlparser2";
import { escapeHtml, VIDEO_HOST } from "@/shared/semantic/html";

const SKIPPED_TAGS = new Set([
  "script",
  "style",
  "noscript",
  "svg",
  "template",
  "iframe",
  "nav",
  "footer",
  "aside",
  "form",
  "select",
  "button",
]);
/** ARIA landmarks that are page chrome, not content. */
const SKIPPED_ROLES = new Set([
  "navigation",
  "banner",
  "complementary",
  "contentinfo",
  "search",
]);
const BLOCK_TAGS = new Set([
  "p",
  "li",
  "td",
  "th",
  "dt",
  "dd",
  "blockquote",
  "figcaption",
  "tr",
  "div",
  "section",
  "article",
  "br",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
]);
const MAX_BLOCKS = 4_000;

export type ExtractedPage = {
  title: string;
  headings: { level: number; text: string }[];
  /** Visible text blocks, in document order (headings included). */
  blocks: string[];
  imageCount: number;
  /** Meta description of the head, empty when none. */
  metaDescription: string;
  /** Counted inside the main content only, like images. */
  videoCount: number;
  tableCount: number;
  listCount: number;
  boldCount: number;
  /** Every link target found in the main content. */
  hrefs: string[];
  /** Editor-ready HTML: headings and one paragraph per block. */
  html: string;
};

/**
 * Pages that declare a <main> (or, failing that, an <article>) are read from
 * inside it only: that drops language lists, menus and promo blocks that a
 * generic "skip nav/footer" rule misses.
 */
function pickContentRoot(html: string): "main" | "article" | null {
  if (/<main[\s>]/i.test(html)) return "main";
  if (/<article[\s>]/i.test(html)) return "article";
  return null;
}

type OpenElement = { skipped: boolean; root: boolean };
type Block = { text: string; level: number; linkOnly: boolean };

/** A run this long of short, link-only blocks is a menu or a language list. */
const MENU_RUN_LENGTH = 6;
const MENU_ITEM_MAX_WORDS = 4;

function isMenuItem(block: Block): boolean {
  return (
    block.level === 0 &&
    block.linkOnly &&
    block.text.split(" ").length <= MENU_ITEM_MAX_WORDS
  );
}

/** Drop every run of MENU_RUN_LENGTH or more consecutive menu-like blocks. */
function dropMenuRuns(blocks: Block[]): Block[] {
  const kept: Block[] = [];
  let run: Block[] = [];
  const endRun = () => {
    if (run.length < MENU_RUN_LENGTH) kept.push(...run);
    run = [];
  };
  for (const block of blocks) {
    if (isMenuItem(block)) {
      run.push(block);
    } else {
      endRun();
      kept.push(block);
    }
  }
  endRun();
  return kept;
}

export function extractPage(html: string): ExtractedPage {
  const rawBlocks: Block[] = [];
  const contentRoot = pickContentRoot(html);
  const open: OpenElement[] = [];
  let title = "";
  let imageCount = 0;
  let metaDescription = "";
  let videoCount = 0;
  let tableCount = 0;
  let listCount = 0;
  let boldCount = 0;
  const hrefs: string[] = [];
  let skipDepth = 0;
  let rootDepth = contentRoot ? 0 : 1;
  let anchorDepth = 0;
  let inTitle = false;
  let headingLevel = 0;
  let buffer = "";
  let linkText = "";

  const collecting = () => skipDepth === 0 && rootDepth > 0;

  const flush = () => {
    const text = buffer.replace(/\s+/g, " ").trim();
    const links = linkText.replace(/\s+/g, " ").trim();
    buffer = "";
    linkText = "";
    if (!text || rawBlocks.length >= MAX_BLOCKS) return;
    rawBlocks.push({
      text,
      level: headingLevel,
      linkOnly: links.length >= text.length,
    });
  };

  const parser = new Parser(
    {
      onopentag(name, attribs) {
        if (name === "title") inTitle = true;
        if (
          name === "meta" &&
          (attribs.name ?? "").toLowerCase() === "description"
        ) {
          metaDescription = attribs.content ?? "";
        }
        // Measured before this element changes the state: an iframe is itself
        // a skipped tag, but a video embedded in the content still counts.
        const inContent = collecting();
        if (inContent) {
          const source = attribs.src ?? attribs["data-src"] ?? "";
          if (
            name === "video" ||
            name === "lite-youtube" ||
            name === "lite-vimeo" ||
            (name === "iframe" && VIDEO_HOST.test(source))
          ) {
            videoCount++;
          }
          if (name === "table") tableCount++;
          if (name === "ul" || name === "ol") listCount++;
          if (name === "strong" || name === "b") boldCount++;
          if (name === "a" && attribs.href) hrefs.push(attribs.href);
        }
        const skipped =
          SKIPPED_TAGS.has(name) ||
          SKIPPED_ROLES.has((attribs.role ?? "").toLowerCase()) ||
          attribs["aria-hidden"] === "true";
        const root = name === contentRoot;
        open.push({ skipped, root });
        if (skipped) skipDepth++;
        if (root) rootDepth++;
        if (name === "a") anchorDepth++;
        if (!collecting()) return;
        if (name === "img") imageCount++;
        if (BLOCK_TAGS.has(name)) {
          flush();
          headingLevel = /^h[1-6]$/.test(name) ? Number(name[1]) : 0;
        }
      },
      ontext(text) {
        if (inTitle) {
          title += text;
          return;
        }
        if (!collecting()) return;
        buffer += text;
        if (anchorDepth > 0) linkText += text;
      },
      onclosetag(name) {
        if (name === "title") inTitle = false;
        const element = open.pop();
        if (collecting() && BLOCK_TAGS.has(name)) {
          flush();
          headingLevel = 0;
        }
        if (element?.skipped) skipDepth = Math.max(0, skipDepth - 1);
        if (element?.root) rootDepth = Math.max(0, rootDepth - 1);
        if (name === "a") anchorDepth = Math.max(0, anchorDepth - 1);
      },
    },
    { decodeEntities: true },
  );
  parser.write(html);
  parser.end();
  flush();

  const blocks = dropMenuRuns(rawBlocks);
  return {
    title: title.replace(/\s+/g, " ").trim(),
    headings: blocks
      .filter((b) => b.level > 0)
      .map((b) => ({ level: b.level, text: b.text })),
    blocks: blocks.map((b) => b.text),
    imageCount,
    metaDescription: metaDescription.trim(),
    videoCount,
    tableCount,
    listCount,
    boldCount,
    hrefs,
    html: blocks
      .map((b) =>
        b.level > 0
          ? `<h${Math.min(b.level, 3)}>${escapeHtml(b.text)}</h${Math.min(b.level, 3)}>`
          : `<p>${escapeHtml(b.text)}</p>`,
      )
      .join(""),
  };
}
