import {
  GscNotConnectedError,
  GscService,
  isExpectedGrantFailure,
} from "@/server/features/gsc/services/GscService";
import { resolveDateRange } from "@/server/features/gsc/searchAnalytics";
import type { GscPerformanceFilter } from "@/server/features/gsc/searchAnalytics";
import { sumSearchTotals } from "@/server/features/gsc/searchPerformanceReport";
import type {
  AfterPublishResult,
  CannibalizationResult,
  PeriodTotals,
} from "@/shared/semantic/types";

// Search Console reads for the Sémantique workspace. First-party data, free.
// Not connected, or a dead grant, comes back as `connected: false` so the page
// shows its connect hint; any other failure is a real fault and propagates.

const DAY_MS = 24 * 60 * 60 * 1000;
const GSC_DATA_LAG_DAYS = 3;
const MIN_AFTER_DAYS = 7;
const MAX_WINDOW_DAYS = 28;
const CANNIBAL_PAGES = 10;
const CANNIBAL_FETCH = 50;
const DAILY_ROW_LIMIT = 200;

function isExpectedConnectionFailure(error: unknown): boolean {
  return error instanceof GscNotConnectedError || isExpectedGrantFailure(error);
}

function isoDate(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

function startOfUtcDay(ms: number): number {
  return Date.parse(`${isoDate(ms)}T00:00:00Z`);
}

async function cannibalization(input: {
  projectId: string;
  keyword: string;
}): Promise<CannibalizationResult> {
  const { startDate, endDate } = resolveDateRange({
    dateRange: "last_3_months",
  });
  try {
    const result = await GscService.getPerformance({
      projectId: input.projectId,
      startDate,
      endDate,
      dimensions: ["page"],
      filters: [
        {
          dimension: "query",
          operator: "contains",
          expression: input.keyword.toLowerCase(),
        },
      ],
      rowLimit: CANNIBAL_FETCH,
    });
    const pages = result.rows
      .map((row) => ({
        page: row.keys?.[0] ?? "",
        clicks: row.clicks,
        impressions: row.impressions,
        position: row.position,
      }))
      .filter((row) => row.page);
    pages.sort((a, b) => b.impressions - a.impressions);
    return {
      connected: true,
      startDate,
      endDate,
      pages: pages.slice(0, CANNIBAL_PAGES),
    };
  } catch (error) {
    if (isExpectedConnectionFailure(error)) return { connected: false };
    throw error;
  }
}

async function periodTotals(
  projectId: string,
  startDate: string,
  endDate: string,
  filters: GscPerformanceFilter[],
): Promise<PeriodTotals> {
  const result = await GscService.getPerformance({
    projectId,
    startDate,
    endDate,
    dimensions: ["date"],
    filters,
    rowLimit: DAILY_ROW_LIMIT,
  });
  const totals = sumSearchTotals(result.rows);
  return {
    startDate,
    endDate,
    clicks: totals.clicks,
    impressions: totals.impressions,
    position: totals.position,
  };
}

/** The URL as Search Console reports it, plus the trailing-slash variant. */
function pageVariants(pageUrl: string): string[] | null {
  let parsed: URL;
  try {
    parsed = new URL(pageUrl);
  } catch {
    return null;
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
  parsed.hash = "";
  const exact = parsed.toString();
  const toggled = exact.endsWith("/") ? exact.slice(0, -1) : `${exact}/`;
  return [exact, toggled];
}

async function afterPublish(input: {
  projectId: string;
  pageUrl: string;
  publishedAt: string;
  keyword: string;
}): Promise<AfterPublishResult> {
  const variants = pageVariants(input.pageUrl);
  const publishedMs = Date.parse(input.publishedAt);
  if (!variants || Number.isNaN(publishedMs)) {
    return { connected: true, status: "no_url" };
  }

  // Same-length windows on each side of the publication day, which is left out.
  const publishedDay = startOfUtcDay(publishedMs);
  const lastDataDay = startOfUtcDay(Date.now()) - GSC_DATA_LAG_DAYS * DAY_MS;
  const availableDays = Math.floor((lastDataDay - publishedDay) / DAY_MS);
  if (availableDays < MIN_AFTER_DAYS) {
    return {
      connected: true,
      status: "too_early",
      daysLeft: MIN_AFTER_DAYS - Math.max(availableDays, 0),
    };
  }
  const windowDays = Math.min(availableDays, MAX_WINDOW_DAYS);
  const afterStart = isoDate(publishedDay + DAY_MS);
  const afterEnd = isoDate(publishedDay + windowDays * DAY_MS);
  const beforeStart = isoDate(publishedDay - windowDays * DAY_MS);
  const beforeEnd = isoDate(publishedDay - DAY_MS);

  const forUrl = async (url: string) => {
    const pageFilter: GscPerformanceFilter = {
      dimension: "page",
      operator: "equals",
      expression: url,
    };
    const keywordFilter: GscPerformanceFilter[] = input.keyword
      ? [
          pageFilter,
          {
            dimension: "query",
            operator: "equals",
            expression: input.keyword.toLowerCase(),
          },
        ]
      : [];
    const [before, after, keywordBefore, keywordAfter] = await Promise.all([
      periodTotals(input.projectId, beforeStart, beforeEnd, [pageFilter]),
      periodTotals(input.projectId, afterStart, afterEnd, [pageFilter]),
      keywordFilter.length > 0
        ? periodTotals(input.projectId, beforeStart, beforeEnd, keywordFilter)
        : Promise.resolve(null),
      keywordFilter.length > 0
        ? periodTotals(input.projectId, afterStart, afterEnd, keywordFilter)
        : Promise.resolve(null),
    ]);
    return { before, after, keywordBefore, keywordAfter };
  };

  try {
    let totals = await forUrl(variants[0]);
    const empty = totals.before.impressions + totals.after.impressions === 0;
    if (empty) {
      // The property may list the page with or without its trailing slash.
      const alternative = await forUrl(variants[1]);
      if (alternative.before.impressions + alternative.after.impressions > 0) {
        totals = alternative;
      }
    }
    return { connected: true, status: "ready", windowDays, ...totals };
  } catch (error) {
    if (isExpectedConnectionFailure(error)) return { connected: false };
    throw error;
  }
}

export const SemanticGscService = { cannibalization, afterPublish } as const;
