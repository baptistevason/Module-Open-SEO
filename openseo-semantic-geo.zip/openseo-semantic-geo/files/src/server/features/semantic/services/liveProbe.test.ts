import { describe, expect, it } from "vitest";
import { probeHtml } from "./liveProbe";

const PAGE = `<!doctype html><html lang="fr"><head>
<title> Dogue de Majorque : le guide </title>
<meta name="description" content="Tout savoir sur la race.">
<link rel="canonical" href="https://exemple.fr/dogue">
<link rel="alternate" hreflang="en" href="https://exemple.fr/en/dogue">
<meta property="og:title" content="Dogue"><meta property="og:image" content="x.png">
<meta name="twitter:card" content="summary">
<meta name="author" content="Dr Martin">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[
 {"@type":"Article","author":{"@type":"Person","name":"Dr Martin"},"datePublished":"2026-01-01","publisher":{"@type":"Organization","name":"X"}},
 {"@type":"BreadcrumbList"}]}</script>
</head><body>
<nav class="breadcrumb"><a href="/">Accueil</a></nav>
<main><h1>Dogue</h1><p>Temps de lecture : 6 min</p>
<img src="a.png" alt="Un dogue"><img src="b.png"><img src="c.png" alt="">
<table><tr><td>x</td></tr></table><time datetime="2026-01-01">1 janvier</time></main>
<script>var ignored = "temps de lecture 99 min";</script>
</body></html>`;

describe("probeHtml", () => {
  const facts = probeHtml(PAGE, "https://exemple.fr/dogue");

  it("reads the head metadata", () => {
    expect(facts.title).toBe("Dogue de Majorque : le guide");
    expect(facts.metaDescription).toBe("Tout savoir sur la race.");
    expect(facts.canonical).toBe("https://exemple.fr/dogue");
    expect(facts.lang).toBe("fr");
    expect(facts.hreflangs).toEqual(["en"]);
    expect(facts.ogTitle).toBe(true);
    expect(facts.ogDescription).toBe(false);
    expect(facts.ogImage).toBe(true);
    expect(facts.twitterCard).toBe(true);
    expect(facts.metaAuthor).toBe(true);
  });

  it("summarises the JSON-LD graph", () => {
    expect(facts.jsonLdTypes).toEqual(
      expect.arrayContaining([
        "Article",
        "Person",
        "Organization",
        "BreadcrumbList",
      ]),
    );
    expect(facts.jsonLdAuthor).toBe(true);
    expect(facts.jsonLdDatePublished).toBe(true);
    expect(facts.jsonLdDateModified).toBe(false);
    expect(facts.hasPublisher).toBe(true);
    expect(facts.hasBreadcrumb).toBe(true);
  });

  it("counts images without a usable alt, tables and the time tag", () => {
    expect(facts.imageCount).toBe(3);
    expect(facts.imagesMissingAlt).toBe(2);
    expect(facts.tableCount).toBe(1);
    expect(facts.hasTimeTag).toBe(true);
  });

  it("finds a reading time in the visible text only", () => {
    expect(facts.readingTimeShown).toBe(true);
    const hidden = probeHtml(
      "<html><body><script>temps de lecture 5 min</script><p>Rien</p></body></html>",
      "https://exemple.fr/",
    );
    expect(hidden.readingTimeShown).toBe(false);
  });

  it("survives a malformed JSON-LD block", () => {
    const broken = probeHtml(
      '<script type="application/ld+json">{not json</script>',
      "https://exemple.fr/",
    );
    expect(broken.jsonLdTypes).toEqual([]);
  });
});
