import { eq } from "drizzle-orm";
import { db } from "@/db";
import { geoSiteChecks } from "@/db/schema";

// Hand-ticked site-level GEO controls. Every query filters on project_id.

async function list(projectId: string): Promise<Record<string, boolean>> {
  const rows = await db
    .select({ checkId: geoSiteChecks.checkId, done: geoSiteChecks.done })
    .from(geoSiteChecks)
    .where(eq(geoSiteChecks.projectId, projectId));
  return Object.fromEntries(rows.map((row) => [row.checkId, row.done]));
}

// updatedAt is stamped here: the column defaults differ between dialects.
async function setCheck(params: {
  projectId: string;
  checkId: string;
  done: boolean;
}): Promise<void> {
  const now = new Date().toISOString();
  await db
    .insert(geoSiteChecks)
    .values({
      id: crypto.randomUUID(),
      projectId: params.projectId,
      checkId: params.checkId,
      done: params.done,
      updatedAt: now,
    })
    .onConflictDoUpdate({
      target: [geoSiteChecks.projectId, geoSiteChecks.checkId],
      set: { done: params.done, updatedAt: now },
    });
}

export const GeoSiteRepository = { list, setCheck } as const;
