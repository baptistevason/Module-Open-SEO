import { and, count, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { semanticDocuments } from "@/db/schema";
import type {
  SemanticDocument,
  SemanticDocumentSummary,
} from "@/types/schemas/semantic-documents";

// Every query filters on `project_id` as well as `id`: callers authorize the
// projectId they were given, not the row, so a guessed id from another project
// must not resolve.

const summaryColumns = {
  id: semanticDocuments.id,
  title: semanticDocuments.title,
  keyword: semanticDocuments.keyword,
  slug: semanticDocuments.slug,
  pageUrl: semanticDocuments.pageUrl,
  score: semanticDocuments.score,
  publishedAt: semanticDocuments.publishedAt,
  geoScore: semanticDocuments.geoScore,
  geoLlmScore: semanticDocuments.geoLlmScore,
  geoAnalyzedAt: semanticDocuments.geoAnalyzedAt,
  createdAt: semanticDocuments.createdAt,
  updatedAt: semanticDocuments.updatedAt,
};

const documentColumns = {
  ...summaryColumns,
  projectId: semanticDocuments.projectId,
  titleTag: semanticDocuments.titleTag,
  metaDescription: semanticDocuments.metaDescription,
  contentHtml: semanticDocuments.contentHtml,
  brief: semanticDocuments.brief,
  locationCode: semanticDocuments.locationCode,
  languageCode: semanticDocuments.languageCode,
  geoChecks: semanticDocuments.geoChecks,
  geoLive: semanticDocuments.geoLive,
  geoLlm: semanticDocuments.geoLlm,
};

type Fields = {
  title: string;
  keyword: string;
  titleTag: string;
  metaDescription: string;
  slug: string;
  pageUrl: string;
  contentHtml: string;
  score: number | null;
  brief: string | null;
  locationCode?: number | null;
  languageCode?: string | null;
};

async function list(projectId: string): Promise<SemanticDocumentSummary[]> {
  return db
    .select(summaryColumns)
    .from(semanticDocuments)
    .where(eq(semanticDocuments.projectId, projectId))
    .orderBy(desc(semanticDocuments.updatedAt), desc(semanticDocuments.id));
}

async function countForProject(projectId: string): Promise<number> {
  const [row] = await db
    .select({ total: count() })
    .from(semanticDocuments)
    .where(eq(semanticDocuments.projectId, projectId));
  return row?.total ?? 0;
}

async function get(
  projectId: string,
  id: string,
): Promise<SemanticDocument | null> {
  const [row] = await db
    .select(documentColumns)
    .from(semanticDocuments)
    .where(
      and(
        eq(semanticDocuments.id, id),
        eq(semanticDocuments.projectId, projectId),
      ),
    )
    .limit(1);
  return row ?? null;
}

// Timestamps are stamped here: the column defaults differ between dialects.
async function insert(params: {
  id: string;
  projectId: string;
  createdBy: string;
  fields: Fields;
}): Promise<string> {
  const now = new Date().toISOString();
  await db.insert(semanticDocuments).values({
    id: params.id,
    projectId: params.projectId,
    createdBy: params.createdBy,
    ...params.fields,
    createdAt: now,
    updatedAt: now,
  });
  return now;
}

/** The new updatedAt, or null when the id is not in this project. */
async function update(params: {
  id: string;
  projectId: string;
  fields: Fields;
}): Promise<string | null> {
  const now = new Date().toISOString();
  const updated = await db
    .update(semanticDocuments)
    .set({ ...params.fields, updatedAt: now })
    .where(
      and(
        eq(semanticDocuments.id, params.id),
        eq(semanticDocuments.projectId, params.projectId),
      ),
    )
    .returning({ id: semanticDocuments.id });
  return updated.length > 0 ? now : null;
}

/** The new publishedAt (null when taken out), or undefined when the id is not in this project. */
async function setPublished(params: {
  id: string;
  projectId: string;
  published: boolean;
}): Promise<{ publishedAt: string | null } | undefined> {
  const publishedAt = params.published ? new Date().toISOString() : null;
  const updated = await db
    .update(semanticDocuments)
    .set({ publishedAt })
    .where(
      and(
        eq(semanticDocuments.id, params.id),
        eq(semanticDocuments.projectId, params.projectId),
      ),
    )
    .returning({ id: semanticDocuments.id });
  return updated.length > 0 ? { publishedAt } : undefined;
}

/** The new analysis time, or null when the id is not in this project. */
async function saveGeoState(params: {
  id: string;
  projectId: string;
  checks: string;
  live: string | null;
  llm: string | null;
  score: number;
  llmScore: number | null;
}): Promise<string | null> {
  const now = new Date().toISOString();
  const updated = await db
    .update(semanticDocuments)
    .set({
      geoChecks: params.checks,
      geoLive: params.live,
      geoLlm: params.llm,
      geoScore: params.score,
      geoLlmScore: params.llmScore,
      geoAnalyzedAt: now,
    })
    .where(
      and(
        eq(semanticDocuments.id, params.id),
        eq(semanticDocuments.projectId, params.projectId),
      ),
    )
    .returning({ id: semanticDocuments.id });
  return updated.length > 0 ? now : null;
}

async function remove(projectId: string, id: string): Promise<boolean> {
  const deleted = await db
    .delete(semanticDocuments)
    .where(
      and(
        eq(semanticDocuments.id, id),
        eq(semanticDocuments.projectId, projectId),
      ),
    )
    .returning({ id: semanticDocuments.id });
  return deleted.length > 0;
}

export const SemanticDocumentRepository = {
  list,
  countForProject,
  get,
  insert,
  update,
  setPublished,
  saveGeoState,
  remove,
} as const;
