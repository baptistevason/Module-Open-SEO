import { z } from "zod";
import { getOptionalEnvValue } from "@/server/lib/runtime-env";

// Minimal Anthropic Messages API client for the Sémantique tools (rephrase,
// fact check, internal links). Plain fetch: no SDK dependency in the worker.
// Failures come back as data with copy safe to show: the client only ever
// receives a bare error code from server functions, never a server message.

const API_URL = "https://api.anthropic.com/v1/messages";
const API_VERSION = "2023-06-01";
// Refusal fallback handled server-side, as in Content Studio.
const BETA = "server-side-fallback-2026-07-01";
const MAX_RESUMES = 4;
const REQUEST_TIMEOUT_MS = 280_000;

export const MODEL_FAST = "claude-sonnet-5-5";
export const MODEL_ANALYSIS = "claude-opus-5-5";

export type LlmResult =
  | { ok: true; text: string; inputTokens: number; outputTokens: number }
  | { ok: false; message: string };

export type LlmRequest = {
  model: string;
  system: string;
  content: string;
  maxTokens: number;
  effort?: "low" | "medium" | "high";
  /** Server-side tools such as web search. */
  tools?: Record<string, unknown>[];
};

const responseSchema = z.object({
  content: z.array(z.record(z.string(), z.unknown())),
  stop_reason: z.string().nullable().optional(),
  usage: z
    .object({
      input_tokens: z.number().optional(),
      output_tokens: z.number().optional(),
    })
    .optional(),
});

export async function isAnthropicConfigured(): Promise<boolean> {
  return Boolean(await getOptionalEnvValue("ANTHROPIC_API_KEY"));
}

function failureForStatus(status: number): string {
  if (status === 401 || status === 403) {
    return "Clé API Claude refusée. Vérifiez le secret ANTHROPIC_API_KEY.";
  }
  if (status === 429) {
    return "Limite de débit de l’API Claude atteinte. Patientez une minute puis réessayez.";
  }
  if (status === 529 || status >= 500) {
    return "L’API Claude est momentanément indisponible. Réessayez dans un instant.";
  }
  return `L’API Claude a répondu ${status}.`;
}

export async function askClaude(request: LlmRequest): Promise<LlmResult> {
  const apiKey = await getOptionalEnvValue("ANTHROPIC_API_KEY");
  if (!apiKey) {
    return {
      ok: false,
      message:
        "Clé API Claude non configurée : ajoutez le secret ANTHROPIC_API_KEY au worker (wrangler secret put ANTHROPIC_API_KEY).",
    };
  }

  const messages: { role: "user" | "assistant"; content: unknown }[] = [
    { role: "user", content: request.content },
  ];
  let inputTokens = 0;
  let outputTokens = 0;

  for (let turn = 0; turn <= MAX_RESUMES; turn++) {
    let response: Response;
    try {
      response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": API_VERSION,
          "anthropic-beta": BETA,
        },
        body: JSON.stringify({
          model: request.model,
          fallbacks: "default",
          max_tokens: request.maxTokens,
          thinking: { type: "adaptive" },
          output_config: { effort: request.effort ?? "medium" },
          system: request.system,
          tools: request.tools,
          messages,
        }),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch {
      return {
        ok: false,
        message:
          "Impossible de joindre l’API Claude (délai dépassé ou réseau). Réessayez.",
      };
    }
    if (!response.ok) {
      return { ok: false, message: failureForStatus(response.status) };
    }

    const parsed = responseSchema.safeParse(await response.json());
    if (!parsed.success) {
      return { ok: false, message: "Réponse de l’API Claude illisible." };
    }
    const message = parsed.data;
    inputTokens += message.usage?.input_tokens ?? 0;
    outputTokens += message.usage?.output_tokens ?? 0;

    if (message.stop_reason === "refusal") {
      return {
        ok: false,
        message: "Demande refusée par les garde-fous du modèle.",
      };
    }
    if (message.stop_reason === "pause_turn") {
      // A long server-tool loop paused: send the turn back so it resumes.
      messages.push({ role: "assistant", content: message.content });
      continue;
    }
    if (message.stop_reason === "max_tokens") {
      return {
        ok: false,
        message:
          "Réponse tronquée (limite atteinte) : réessayez sur un contenu plus court.",
      };
    }

    const text = message.content
      .filter((block) => block.type === "text")
      .map((block) => (typeof block.text === "string" ? block.text : ""))
      .join("");
    return { ok: true, text, inputTokens, outputTokens };
  }
  return {
    ok: false,
    message: "L’analyse n’a pas abouti (trop de reprises). Réessayez.",
  };
}

/** The JSON inside <result>...</result>, or the first JSON array in the text. */
export function parseJsonResult(text: string): unknown {
  const tagged = /<result>([\s\S]*?)<\/result>/.exec(text);
  const raw = tagged ? tagged[1] : (/\[[\s\S]*\]/.exec(text)?.[0] ?? "");
  try {
    return JSON.parse(raw.trim());
  } catch {
    return null;
  }
}
