CREATE TABLE "geo_site_checks" (
	"id" text PRIMARY KEY NOT NULL,
	"project_id" text NOT NULL,
	"check_id" text NOT NULL,
	"done" boolean DEFAULT false NOT NULL,
	"updated_at" text DEFAULT to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') NOT NULL
);
--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_checks" text;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_live" text;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_llm" text;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_score" integer;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_llm_score" integer;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "geo_analyzed_at" text;--> statement-breakpoint
ALTER TABLE "geo_site_checks" ADD CONSTRAINT "geo_site_checks_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "geo_site_checks_project_check_idx" ON "geo_site_checks" USING btree ("project_id","check_id");