ALTER TABLE "semantic_documents" ADD COLUMN "location_code" integer;--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD COLUMN "language_code" text;