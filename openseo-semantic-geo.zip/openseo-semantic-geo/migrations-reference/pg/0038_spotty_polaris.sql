CREATE TABLE "semantic_documents" (
	"id" text PRIMARY KEY NOT NULL,
	"project_id" text NOT NULL,
	"title" text NOT NULL,
	"keyword" text DEFAULT '' NOT NULL,
	"title_tag" text DEFAULT '' NOT NULL,
	"meta_description" text DEFAULT '' NOT NULL,
	"slug" text DEFAULT '' NOT NULL,
	"content_html" text DEFAULT '' NOT NULL,
	"page_url" text DEFAULT '' NOT NULL,
	"score" integer,
	"published_at" text,
	"created_by" text NOT NULL,
	"created_at" text DEFAULT to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') NOT NULL,
	"updated_at" text DEFAULT to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') NOT NULL
);
--> statement-breakpoint
ALTER TABLE "semantic_documents" ADD CONSTRAINT "semantic_documents_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "semantic_documents_project_updated_idx" ON "semantic_documents" USING btree ("project_id","updated_at");