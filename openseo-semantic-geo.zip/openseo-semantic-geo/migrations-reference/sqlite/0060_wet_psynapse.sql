CREATE TABLE `semantic_documents` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`title` text NOT NULL,
	`keyword` text DEFAULT '' NOT NULL,
	`title_tag` text DEFAULT '' NOT NULL,
	`meta_description` text DEFAULT '' NOT NULL,
	`slug` text DEFAULT '' NOT NULL,
	`content_html` text DEFAULT '' NOT NULL,
	`page_url` text DEFAULT '' NOT NULL,
	`score` integer,
	`published_at` text,
	`created_by` text NOT NULL,
	`created_at` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')) NOT NULL,
	`updated_at` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `semantic_documents_project_updated_idx` ON `semantic_documents` (`project_id`,`updated_at`);