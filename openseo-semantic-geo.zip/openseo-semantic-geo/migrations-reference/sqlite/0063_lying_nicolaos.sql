ALTER TABLE `semantic_documents` ADD `location_code` integer;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `language_code` text;