CREATE TABLE `geo_site_checks` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`check_id` text NOT NULL,
	`done` integer DEFAULT false NOT NULL,
	`updated_at` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `geo_site_checks_project_check_idx` ON `geo_site_checks` (`project_id`,`check_id`);--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_checks` text;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_live` text;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_llm` text;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_score` integer;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_llm_score` integer;--> statement-breakpoint
ALTER TABLE `semantic_documents` ADD `geo_analyzed_at` text;