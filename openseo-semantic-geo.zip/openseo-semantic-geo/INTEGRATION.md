# Modules « Optimisation SEO (sémantique) » + « Optimisation GEO » : intégration

Extrait de `open-seo-baptiste`. Ce paquet contient **uniquement** le code des deux fonctions.
Aucun projet, aucune clé, aucune donnée. Les chemins de `files/` sont identiques à ceux du dépôt OpenSEO :
on copie `files/src/**` dans `src/` du OpenSEO de l'agence.

## 1. Copier les fichiers (99 fichiers)
- `src/client/features/semantic/`, `src/client/features/geo/` : interface (éditeur, cartes, pages GEO)
- `src/server/features/semantic/` : services + repositories (sémantique ET GEO)
- `src/shared/semantic/`, `src/shared/geo/` : analyse, scores, catalogue des contrôles GEO
- `src/serverFunctions/semantic.ts`, `src/types/schemas/semantic*.ts`
- `src/db/semantic.schema.ts` (SQLite/D1) et `src/db/pg/semantic.schema.ts` (Postgres)
- `src/routes/_app/p/$projectId/semantic/**` et `.../geo/**`
- `src/server/lib/anthropic.ts` : client Claude minimal (voir §4)

## 2. Brancher (4 petites modifications dans des fichiers existants)
1. **`src/db/schema.ts`** : ajouter
   `import * as sqliteSemantic from "./semantic.schema";` et `import * as pgSemantic from "./pg/semantic.schema";`
   puis exposer `semanticDocuments` et `geoSiteChecks` dans la liste de tables, comme les autres (ex. `reports`).
2. **`src/db/d1/schema.ts`** : `export * from "../semantic.schema";`
3. **`src/db/pg/schema.ts`** : `export * from "./semantic.schema";`
4. **Navigation `src/client/navigation/items.ts`** : ajouter les entrées
   - `{ to: "/p/$projectId/semantic", label: "Optimisation SEO", icon: ScanText }`
   - `{ to: "/p/$projectId/geo", label: "Optimisation GEO", icon: Sparkles }`
   et le groupe « Sémantique » : `items: [byPath("/p/$projectId/semantic"), byPath("/p/$projectId/geo")]`.
   Le fichier `src/routeTree.gen.ts` se régénère tout seul au prochain `pnpm dev`/build (ne pas le copier).

## 3. Base de données : créer les tables
Tables : `semantic_documents` (+ colonnes brief, geo_*, location_code, language_code) et `geo_site_checks`.
**Ne pas recopier les migrations telles quelles** : leur numérotation dépend de l'historique de ce dépôt.
Une fois le schéma branché (§2), lancer `drizzle-kit generate` dans le OpenSEO de l'agence (D1 et/ou Postgres) : il produira
les migrations avec la bonne numérotation. `migrations-reference/` ne sert qu'à vérifier le résultat attendu.

## 4. Clé API (à ajouter par l'agence, jamais dans le code)
Les fonctions IA (reformulation, fact-check, maillage interne, analyse GEO par LLM, génération) appellent l'API Anthropic :
`wrangler secret put ANTHROPIC_API_KEY` (et la même variable en local, dans `.env.local`).
Modèles utilisés (modifiables dans `src/server/lib/anthropic.ts`) : `MODEL_FAST` et `MODEL_ANALYSIS`.
Si OpenSEO de l'agence a déjà un fichier `anthropic.ts`, fusionner plutôt qu'écraser.

## 5. Dépendances npm
Déjà présentes dans OpenSEO en général : react, @tanstack/react-router, @tanstack/react-query, zod, drizzle-orm, lucide-react, htmlparser2.
**À ajouter si absentes** (éditeur riche) : `@tiptap/react`, `@tiptap/starter-kit`, `@tiptap/extension-image`, `@tiptap/extension-youtube`.

## 6. Fichiers d'OpenSEO dont ces modules dépendent (doivent exister côté agence)
Composants UI (`src/client/components/ui/*`, `PageHeader`, `QueryState`, `CopyButton`…), `src/db/index.ts`, `src/db/app.schema.ts`,
`src/server/lib/{errors,r2-cache,runtime-env}.ts`, `src/serverFunctions/middleware.ts`, `src/shared/keyword-locations.ts`,
services GSC / GA4 / audit / ai-visibility / project-context / keywords research, `src/server/billing/subscription.ts`.
Si l'agence utilise une version plus ancienne d'OpenSEO et qu'un import manque, `pnpm typecheck` listera exactement quoi.

## 7. Vérifier
`pnpm install && pnpm typecheck && pnpm test` : les tests des modules (`*.test.ts`) sont inclus.
